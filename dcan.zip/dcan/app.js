App({
	onLaunch: function () {
		//调用API从本地缓存中获取数据
		var logs = wx.getStorageSync('logs') || []
		logs.unshift(Date.now())
		wx.setStorageSync('logs', logs)
		this.getUserInfo()
	},
	//获取用户信息
	getUserInfo: function () {
		var that = this
		wx.getSystemInfo({
			success: function (re) {
				that.globalData.model = re.model
			}
		})
		wx.login({
			success: function (r) {
				wx.getUserInfo({
					success: function (res) {
						that.globalData.userInfo = res.userInfo
						var nickName = res.userInfo.nickName
						var avatarUrl = res.userInfo.avatarUrl

						wx.request({
							url: 'https://www.aftdc.com/wxapp/addUser/index',
							method: "POST",
							header: { "Content-Type": "application/x-www-form-urlencoded" },
							data: {
                                code: r.code,
								nickName: nickName,
								model: that.globalData.model,
								avatarUrl: avatarUrl,
								encryptedData: res.encryptedData,
								iv: res.iv
							},
							success: function (user) {
								that.globalData.usersInfo = user.data
								that.globalData.userId = user.data.userId
								wx.setStorageSync('usersInfo', user.data)
							}
						})
					}
				})
			}
		})
	},
	globalData: {
		userInfo: null,
		usersInfo: null,
		location: null,
		userId: null,
		model:null
	}
})