var app = getApp();
var MD5Util = require('../../utils/md5.js');
Page({
	data: {
		reason: [
			{ name: "我不想买了", circle: true },
			{ name: "下错单了", circle: false },
			{ name: "卖家缺货", circle: false },
			{ name: "其他", circle: false },
		],
		tagStr: '',
		pageTab: {
			curHdIndex: 0,
			curBdIndex: 0,
		},
		hidden: true,
		hidd: true,
		hi: true,
		tk: 0,
		choose: 0,
		taste: -1,
		wrap: -1,
		goods: 1,
		tks: 0,
		tkType: false,
		tk: 0,
		first: false,
		winHeight: "",//窗口高度
		currentTab: 0, //预设当前项的值
		scrollLeft: 0, //tab标题的滚动条位置
		onreachBottom: true,
		cur: 0,

		jxzpage: 0,//进行中
		dfkpage: 0,//待付款
		dsypage: 0,//待使用
		dpjpage: 0,//待评价
		tkpage: 0,//退款
		windowHeight: 0,//高
		num: '',//数

        waitNum:0,
        noPayNum:0,
        groupNum:0,
        pingjiaNum:0,
        refundNum:0
	},
	onLoad: function () {
		var that = this;
		wx.getSystemInfo({
			success: function (res) {
				that.setData({
					windowHeight: res.windowHeight
				})
			}
		});
	},
	chooseTag: function (e) {
		var index = e.currentTarget.dataset.index
		var tags = this.data.tags
		tags[index]['sel'] = !tags[index]['sel']
		this.setData({
			tags: tags
		})
	},

	onReady: function (option) {
		var that = this;
		wx.getSystemInfo({
			success: function (res) {
				that.setData({
					windowHeight: res.windowHeight
				})
			}
		});
		//购买团购商品成功跳转
		var buyTk = wx.getStorageSync("buyTk")
		if (buyTk) {
			wx.removeStorageSync("buyTk")
			this.setData({
				choose: 3
			})
		}
		this.getAllOrders()
	},
	onShow: function () {
		var userId = app.globalData.userId
		var allOrdersInfo = this.data.allOrdersInfo
		if (userId && !allOrdersInfo) {
			var that = this
			wx.getSetting({
				success(res) {
					if (res.authSetting['scope.userInfo']) {//如果之前没登录
						that.onPullDownRefresh()
					}
				}
			})
		}
		var first = this.data.first
		if (first) {
			this.onPullDownRefresh()
		}
	},
	//请求数据
	getAllOrders: function () {
		var userId = app.globalData.userId
		if (userId) {
			this.data.userId = userId
			var that = this
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)

			wx.request({
				url: 'https://www.aftdc.com/wxapp/Order/getAllOrders',
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				method: "POST",
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
				},
				success: function (res) {
					that.setData({
						allOrdersInfo: res.data,
						jxz: res.data.wait,//进行中
						dfk: res.data.noPay,//待付款
						dsy: res.data.group,//待使用
						dpj: res.data.pingjia,//待评价
						tk: res.data.refund,//退款
						jxzpage: res.data.wait.length,//进行中
						dfkpage: res.data.noPay.length,//待付款
						dsypage: res.data.group.length,//待使用
						dpjpage: res.data.pingjia.length,//待评价
						tkpage: res.data.refund.length,//退款
						first: true,
                        waitNum: res.data.waitNum,
                        noPayNum: res.data.noPayNum,
                        groupNum: res.data.groupNum,
                        pingjiaNum: res.data.pingjiaNum,
                        refundNum: res.data.refundNum
					})
					// that.setChoose()
				}
			})
		} else {
			var usersInfo = wx.getStorageSync('usersInfo')
			if (!usersInfo || !usersInfo.userPhone) {//如果没登录
				wx.navigateTo({
					url: '/pages/author/author',
				})
				return false
			}
		}
	},
	// 滚动切换标签样式
	switchTab: function (e) {
		this.setData({
			currentTab: e.detail.current
		});
		// this.checkCor();
		// this.setChoose();
	},
	//判断当前滚动超过一屏时，设置tab标题滚动条。
	checkCor: function () {
		if (this.data.currentTab > 6) {
			this.setData({
				scrollLeft: 300
			})
		} else {
			this.setData({
				scrollLeft: 0
			})
		}
	},
	// 点击标题切换当前页时改变样式
	swichNav: function (e) {
		// wx.showLoading({
		//   mask: true
		// })
		var cur = e.currentTarget.dataset.choose;

		if (this.data.currentTab == cur) { return false; }
		else {
			this.setData({
				currentTab: cur,
				choose: cur
			})
		}
	},
	onreachBottom: function (e) {
		var num = this.data.num;//上一个状态
		if (num != this.data.currentTab) {
			this.data.onreachBottom = true
		}
		if (this.data.onreachBottom) {
			this.setData({
				more: true,
				num: this.data.currentTab,
			})
			this.data.onreachBottom = false
			var that = this
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			var page = 0
			var currentTab = that.data.currentTab;
			var page = 0;
			if (currentTab == 0) {
				page = that.data.jxzpage;//进行中
			} else if (currentTab == 1) {
				page = that.data.dfkpage;//待付款
			} else if (currentTab == 2) {
				page = that.data.dsypage;//待使用
			} else if (currentTab == 3) {
				page = that.data.dpjpage;//待评价
			} else if (currentTab == 4) {
				page = that.data.tkpage;//退款
			}
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Order/upOrders',
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				method: "POST",
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					type: that.data.currentTab,
					page: page
				},
				success: function (res) {
					if (res.data.data != '') {
						if (currentTab == 0) {
							//进行中
							that.setData({
								jxz: that.data.jxz.concat(res.data.data),
								jxzpage: that.data.jxzpage + res.data.data.length
							})
						} else if (currentTab == 1) {
							//待付款
							that.setData({
								dfk: that.data.dfk.concat(res.data.data),
								dfkpage: that.data.dfkpage + res.data.data.length
							})
						} else if (currentTab == 2) {
							//待使用
							that.setData({
								dsy: that.data.dsy.concat(res.data.data),
								dsypage: that.data.dsypage + res.data.data.length
							})
						} else if (currentTab == 3) {
							//待评价
							that.setData({
								dpj: that.data.dpj.concat(res.data.data),
								dpjpage: that.data.dpjpage + res.data.data.length
							})
						} else if (currentTab == 4) {
							//退款
							that.setData({
								tk: that.data.tk.concat(res.data.data),
								tkpage: that.data.tkpage + res.data.data.length
							})
						}
						that.data.onreachBottom = true
					}
				}
			})
		}
	},
	//参数
	setChoose: function () {

	},

	onPullDownRefresh: function () {
		wx.hideNavigationBarLoading() //完成停止加载
		wx.stopPullDownRefresh() //停止下拉刷新
	},
	//没外卖订单
	rule: function () {
		wx.switchTab({
			url: '../../nearby/nearby',
		})
	},
	//确认收货
	confirmOrder: function (e) {
		var that = this
		var orderId = e.currentTarget.dataset.orderid
		var shopId = e.currentTarget.dataset.shopid
		var orderScore = e.currentTarget.dataset.orderscore
		var userId = app.globalData.userId
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)

		wx.request({
			url: 'https://www.aftdc.com/wxapp/Order/confirmOrder',
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			data: {
				orderId: orderId,
				orderScore: orderScore,
				shopId: shopId,
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
			},
			method: "POST",
			success: function (res) {
				if (res.data.res == 1) {
					that.onPullDownRefresh()
					wx.showModal({
						title: '提示',
						content: '已收货',
						showCancel: false
					})
				} else {
					wx.showModal({
						title: '提示',
						content: '失败，请重试',
						showCancel: false,
						success: function () {
							that.setData({
								not2: false,
							})
						}
					})
				}
			}
		})
	},
	//点击导航
	pageHdtap: function (e) {
		//点击子元素
		var _datasetId = e.target.dataset.id;
		var _leftObj = {};
		_leftObj.curHdIndex = _datasetId;
		_leftObj.curBdIndex = _datasetId;
		this.setData({
			pageTab: _leftObj
		});
	},
	record_detail: function (e) {
		var id = e.currentTarget.dataset.id
		var tk = e.currentTarget.dataset.tk
		if (!tk) {
			tk = this.data.tk
		}
		// wx.navigateTo({
		//   url: '../personal/record/record-detail/record-detail?orderId=' + id +'&tk='+tk,
		// })
		wx.navigateTo({
			url: '../order/submit/waitPay/waitPay?orderId=' + id + '&tk=' + tk,
		})
	},
	//催单
	cuidan: function (e) {
		var orderId = e.currentTarget.dataset.id
		var shopId = e.currentTarget.dataset.shopid
		var that = this
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)

		wx.request({
			url: 'https://www.aftdc.com/wxapp/Order/cuidan',
			data:
			{
				orderId: orderId,
				shopId: shopId,
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
			},
			method: 'POST',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
				if (res.data.res == 1) {
					wx.showModal({
						title: '提示',
						content: '已催单',
						showCancel: false
					})
					that.onPullDownRefresh()
				} else {
					wx.showModal({
						title: '提示',
						content: '失败，请重试',
						showCancel: false
					})
				}
			}
		})
	},
	jumpOrder: function (e) {
		var shopId = e.currentTarget.dataset.shopid

		wx.navigateTo({
			url: '../order/order?shopId=' + shopId,
		})
	},

	btnback: function (e) {
		var orderId = e.currentTarget.dataset.orderid
		var shopId = e.currentTarget.dataset.shopid
		var orderStatus = e.currentTarget.dataset.orderstatus

		wx.navigateTo({
			url: '../personal/refund/refund?orderId=' + orderId + '&shopId=' + shopId + '&orderStatus=' + orderStatus,
		})
	},

	go: function (ee) {
		var pid = ee.currentTarget.dataset.orderid;//点击的是哪件商品的评价
		var shopId = ee.currentTarget.dataset.shopid;
		var tk = ee.currentTarget.dataset.tk;
		var types = ee.currentTarget.dataset.types;
		wx.navigateTo({
			url: 'score/score?pid=' + pid + '&shopId=' + shopId + '&tk=' + tk + '&types=' + types,
		})
	},

	cancel: function () {
		this.setData({
			hidden: true
		})
	},

	//没有订单
	rule: function () {
		wx.switchTab({
			url: '../../nearby/nearby',
		})
	},
	//取消订单
	box2: function (e) {
		var rea = e.currentTarget.dataset.rea;
		var orderId = e.currentTarget.dataset.orderid;
		var index = e.currentTarget.dataset.index;
		var tks = e.currentTarget.dataset.tk
		if (tks != undefined) {
			this.setData({
				tks: 1
			})
		}
		if (rea == 1) {
			this.setData({
				show_box2: true,
			})
		} else {
			this.setData({
				show_box2: false,
			})
		}
		this.setData({
			orderId: orderId,
			index: index
		})
	},
	reason: function (e) {
		var reason = this.data.reason
		var circle = e.currentTarget.dataset.circle;
		for (var i in reason) {
			if (i == circle) {
				reason[i].circle = true;
				this.setData({
					reason_display: reason[i].name,
				})
			} else {
				reason[i].circle = false;
			}
		}
		this.setData({
			reason: reason,
		})
	},
	//确定取消订单
	box_ensure: function () {
		var that = this
		var orderId = that.data.orderId
		var index = that.data.index
		var userId = app.globalData.userId
		var tks = that.data.tks //判断是否是团购单 1是 0否
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Order/delOrder',
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			data: {
				orderId: orderId,
				tks: tks,
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
			},
			method: "POST",
			success: function (res) {
				that.onPullDownRefresh()
				that.setData({
					show_box2: false
				})
				if (tks == 1) {
					that.setData({
						grouponNum: that.data.grouponNum - 1
					})
				}
				else {
					that.setData({
						noPayNum: that.data.noPayNum - 1,
					})
				}
			}
		})
	},

	group: function (e) {
		var orderId = e.currentTarget.dataset.orderid
		var shopId = e.currentTarget.dataset.shopid
		wx: wx.navigateTo({
			url: 'group/group?orderId=' + orderId + '&shopid=' + shopId
		})
	},
	drawback: function (e) {
		var shopId = e.currentTarget.dataset.shopid
		var orderId = e.currentTarget.dataset.orderid
		wx.navigateTo({
			url: '../purchase/drawback/drawback?orderId=' + orderId + '&shopId=' + shopId,
		})
	}
})