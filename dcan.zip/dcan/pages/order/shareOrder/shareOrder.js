var app = getApp();
var MD5Util = require('../../../utils/md5.js');
Page({
	data: {
		payTrue: false,
		friendId: 0,
		boxShow: false,
		goods: true,
		goodsPrice: 0,
		dsm: 0, //配送费
		dfm: 0,
		dfmStr: 20,
		goodsmarketPrice: 0,
		friend: [],
		orderfoodArr: [],
		orderfood: '',
		userGoodsInfo: [],
		addF: false,
		partner: [],
		FriendOrderFood: [],
		delData: {},
		plength: 1,
		flength: 0,
		onshow: false
	},

	onLoad: function (options) {
		var orderType = wx.getStorageSync('orderType');
		this.setData({
			shopId: options.shopId,
			dsm: options.dsm,//配送费
			dfm: options.dfm,//起送
			shopName: options.shopName,
			dfmStr: '￥' + options.dfm + '起送',
			orderType: orderType
		})
	},
	onReady: function () {
		var shareId = wx.getStorageSync('shareId');
		if (Boolean(shareId)) {
			this.setData({
				shareId: shareId,
			})
			this.onPullDownRefresh()
		} else {
			var Num = "";
			for (var i = 0; i < 12; i++) {
				Num += Math.floor(Math.random() * 10);
			}
			this.data.shareId = Num
			wx.setStorageSync('shareId', Num)
			var that = this
      var timestamp = (Date.parse(new Date())) / 1000
      var sign = MD5Util.sign(timestamp)
			//初始化先创建一个拼单
			wx.request({
        url: 'https://www.aftdc.com/wxapp/Shop/startShare',
				data: {
          sign: sign,
          timestamp: timestamp,
          token: app.globalData.usersInfo.token,
					userId: app.globalData.userId,
					shareId: Num,
					name: app.globalData.usersInfo.userName
				},
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				method: 'post',
				success: function (res) {
					if (res.data.res == 1) {
						that.setData({
							shareOrder: [{
								name: app.globalData.usersInfo.userName,
								id: res.data.id
							}],
							onshow: true
						})
					}
				}
			})
		}

	},
	onShow: function () {
		if (this.data.onshow) {
			this.onPullDownRefresh()
		}
	},
	add: function () {
		this.setData({
			boxShow: 4
		})
	},
	noadd: function () {
		this.setData({
			boxShow: false,
		})
	},
	//帮好友点餐
	diancanF: function () {
		var shareOrder = this.data.shareOrder;
		var num = shareOrder.length + 1
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Shop/addFriend',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				userId: app.globalData.userId,
				shareId: that.data.shareId,
				name: num + '号好友'
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					that.setData({
						shareOrder: res.data.shareOrder
					})
				}
			}
		})
	},

	//删除他
	delFriend: function () {
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Shop/delFriend',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				shareId: that.data.shareId,
				id: that.data.id
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					that.setData({
						shareOrder: res.data.shareOrder,
						boxShow: false
					})
				}
			}
		})
	},
	delBox: function (e) {
		var id = e.currentTarget.dataset.id;
		this.data.id = id
		this.setData({
			boxShow: 1
		})
	},

	// 修改名字输入框
	reviseInput: function (e) {
		var reviseTxt = e.detail.value;
		this.setData({
			reviseTxt: reviseTxt
		})
	},
	//修改名字
	reviseTrue: function () {
		var that = this
		var reviseTxt = this.data.reviseTxt;
		var shareId = this.data.shareId;
		if (!reviseTxt || reviseTxt.length < 2) {
			util.aftModal({
				title: '昵称为 2-12 字',
			})
			that.setData({
				boxShow: false,
			})
			return false
		}
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Shop/editName',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				shareId: shareId,
				id: that.data.id,
				name: reviseTxt
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					that.setData({
						shareOrder: res.data.shareOrder,
						boxShow: false
					})
				}
			}
		})
	},
	reviseFn: function (e) {
		var id = e.currentTarget.dataset.id;
		this.data.id = id
		this.setData({
			boxShow: 3
		})
	},
	//下拉刷新
	onPullDownRefresh: function () {
		var shopId = this.data.shopId
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Shop/getShare',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				shareId: that.data.shareId,
				shopId: shopId
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					that.setData({
						shareOrder: res.data.shareOrder,
						num: res.data.num,
						payStatus: res.data.payStatus,
						deduction: res.data.deduction
					})
				}
				if (res.data.payStatus == -1) {
					wx.showModal({
						title: '提示',
						content: '已提交订单，去付款',
						showCancel: false,
						success: function (res) {
							if (res.confirm) {
								wx.switchTab({
									url: '/pages/purchase/purchase',
								})
							}
						}
					})
				}
				if (res.data.payStatus == 1) {
					wx.showModal({
						title: '提示',
						content: '已提交订单',
						showCancel: false,
						success: function (res) {
							if (res.confirm) {
								wx.switchTab({
									url: '/pages/purchase/purchase',
								})
							}
						}
					})
				}
				if (that.data.dfm - res.data.num.allPrice > 0) {
					that.setData({
						dfmStr: '差￥' + Number(that.data.dfm - res.data.num.allPrice) + '起送',
						payTrue: false
					})
				} else if (that.data.dfm - res.data.num.allPrice == 0) {
					if (res.data.num.gNum == 0) {
						that.setData({
							dfmStr: '0元起送',
							payTrue: false
						})
					} else {
						that.setData({
							dfmStr: '0元起送',
							payTrue: true
						})
					}
				} else {
					that.setData({
						dfmStr: '去结算',
						payTrue: true
					})
				}
				wx.hideNavigationBarLoading() //完成停止加载
				wx.stopPullDownRefresh() //停止下拉刷新
			}
		})
	},
	// 弹出框隐藏
	boxhide: function () {
		this.setData({
			boxShow: false,
		})
	},
	//去店铺选购
	addGoods: function (e) {
		wx.navigateTo({
			url: '../order?shopId=' + this.data.shopId + '&id=' + e.currentTarget.dataset.id
		})
	},
	// 用户点击右上角分享
	onShareAppMessage: function (res) {
		var that = this
		if (res.from === 'button') {
			return {
				title: '要一起点外卖吗',
				path: '/pages/order/goShare/goShare?shopId=' + this.data.shopId + '&shareId=' + this.data.shareId,
				success: function (res) {
					that.setData({
						boxShow: 2,
					})
				},
				fail: function (res) {
					util.aftModal({
						title: '分享失败',
						icon: 'loading'
					})
				}
			}
		}
	},
	//结算
	pay: function () {
		
		var shopId = this.data.shopId
		var dsm = this.data.dsm
		var dfm = this.data.dfm
		var shopName = this.data.shopName
		if (this.data.orderType == 3) {
			wx.navigateTo({
				url: '../desk/desk?shopId=' + shopId + '&shopName=' + shopName,
			})
			return false
		}
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		//从数据库获取最新的商品数据
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Shop/getNewShare',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				shareId: that.data.shareId,
				shopId: shopId
			},
			method: 'POST',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
				wx.setStorageSync('orderfood', res.data.food)
				wx.navigateTo({
					url: '../submit/submit?shareId=' + that.data.shareId + '&deduction=' + res.data.deduction,
				})
			}
		})
	},
	//关闭拼单
	closeShare: function () {
		var that = this;
		wx.showModal({
			title: '确定关闭拼单',
			content: '关闭后，拼单中包含的好友以及商品信息将无法恢复',
			confirmColor: '#53beb7',
			success: function (res) {
				if (res.confirm) {
          var timestamp = (Date.parse(new Date())) / 1000
          var sign = MD5Util.sign(timestamp)
          
					//用户点击确定
					wx.request({
            url: 'https://www.aftdc.com/wxapp/Shop/delShare',
						data: {
              sign: sign,
              timestamp: timestamp,
              token: app.globalData.usersInfo.token,
							shareId: that.data.shareId
						},
						header: {
							"Content-Type": "application/x-www-form-urlencoded"
						},
						method: 'post',
						success: function (res) {
							if (res.data.res == 1) {
								wx.removeStorageSync("shareId")
								wx.navigateBack({
									delta: 1
								})
							}
						}
					})
				}
			},
		})

	},
	//监听页面卸载
	onUnload: function () {

	}
})