var MD5Util = require('../../../utils/md5.js');
var app = getApp()
Page({
	data: {
		page:0,
		nothing:true
	},

	onLoad: function (options) {
		this.setData({ shopId: options.shopId })
		this.cutArticle(0)
		var that = this
	},

	//返回上一页
	back: function (e) {
		wx.navigateBack({
			delta: 1
		})
	},

	//切换文章
	cutArticle: function (cur) {
		var userId = app.globalData.userId
		if (!userId) {
			userId = ''
		}
		var that = this;
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Article/NewsTo',
			header: {
				'content-type': 'application/x-www-form-urlencoded'
			},
			data: {
				userId: userId,
				shopId: that.data.shopId,
				cur: 0,
				page:0
			},
			method: "POST",
			success: function (res) {
				wx.setNavigationBarTitle({
					title: res.data.shopInfo.shopName
				})

				that.setData({
					article: res.data.data,
					page: that.data.page + res.data.data.length,
					count: res.data.count,
					shopInfo: res.data.shopInfo
				})
				if(res==0){
					this.data.nothing = true
				}
			}
		})
	},
	/*上拉加载*/
	onReachBottom: function () {
		if (this.data.nothing) {
			this.setData({
				more: true
			})
			this.data.nothing=false
			var userId = ''
			if (app.globalData.usersInfo)
				var userId = app.globalData.userId
			var that = this;
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Article/NewsTo',
				header: {
					'content-type': 'application/x-www-form-urlencoded'
				},
				data: {
					userId: userId,
					cur: 0,
					page: that.data.page
				},
				method: "POST",
				success: function (res) {
					if (res.data.res == 1) {
						that.setData({
							article: that.data.article.concat(res.data.data),
							page: that.data.page + res.data.data.length,
							nothing:true
						})
					}
					that.setData({
						more: false
					})
				}
			})
		}
	},
	seeDetail: function (e) {
		var id = e.currentTarget.dataset.id
		wx.navigateTo({
			url: '../../direct/article/article?article_id=' + id,
		})
	},
	onShareAppMessage: function () {
		var that = this
		var shopname = that.data.shopInfo.shopName
		var shopId = that.data.shopInfo.shopId
		return {
			title: shopname,
			path: '/pages/shopdetail/shopdetail?shopId=' + shopId,
			success: function (res) {
				// 分享成功
			}
		}
	}
})