Page({
  data: {
     maxSrc:'',
     maxSrcBox:false,
  },

  onLoad: function (options) {
    var shopId = options.shopId;
    var that = this;
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
    if (shopId){
      wx.request({
        url: 'https://www.aftdc.com/wxapp/Shop/supervision',
        data:{
          sign: sign,
          timestamp: timestamp,
          token: app.globalData.usersInfo.token,
          shopId:shopId
          },
        method:'post',
        header: { "Content-Type": "application/x-www-form-urlencoded" },
        success:function(res){
          var all = res.data;//食品安全的数据
          all.unitImg = "https://www.aftdc.com/" + all.unitImg;//门脸照
          if (all.allowImg){
            all.allowImg = "https://www.aftdc.com/" + all.allowImg;//门脸照
          }
          console.log(all)
          that.setData({
            info:all,
          })
        }
      })
    }
  },

 //点击放大图片
  enlargeImg: function (e) {
    var src = e.currentTarget.dataset.src;
    this.setData({
      maxSrcBox:true,
      maxSrc: src,
    })
  },

  hide:function(){
    this.setData({
      maxSrcBox: false,
    })
  },
})










