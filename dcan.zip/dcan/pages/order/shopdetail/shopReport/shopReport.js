var app = getApp()
Page({
	data: {
		upload: [],
		choose: 1,
		reType: '选择举报类型',
		report: [
			{ 'w': '餐厅刷单', 'q': '餐厅刷单' },
			{ 'w': '商家资质', 'q': '商家缺少相关从业资质证书' },
			{ 'w': '商家价格问题', 'q': '外卖商品价格高于店内实际价格,恶意设置高满减' },
			{ 'w': '商家品类', 'q': '商家未设置品类或品类设置错误' },
			{ 'w': '商家logo问题', 'q': '商家logo错误或未上传logo' },
			{ 'w': '商家配送问题', 'q': '商家起送价、配送费或餐盒费过高' },
			{ 'w': '其他问题', 'q': '其他您认为影响了市场秩序公正的行为' },
		],
		text: ''
	},

	onLoad: function (options) {
		var shopName = options.shopName
		var shopImg = options.shopImg
		var shopId = options.shopId
		shopName = decodeURI(shopName)
		this.setData({
			shopName: shopName,
			shopImg: shopImg,
			shopId: shopId
		})
	},
	uploadimage: function (e) {
		var upload = this.data.upload
		var that = this
		wx.chooseImage({
			count: 3,
			success: function (res) {
				var tempFilePaths = res.tempFilePaths
				for (var i in tempFilePaths) {
					upload.push(tempFilePaths[i])
				}

				if (upload.length > 3) {
					var index = tempFilePaths.length
					upload.splice(0, index)

				}
				that.setData({
					upload: upload,
					uploadsrc: true
				})
			}
		})
	},
	reportType: function () {
		this.setData({
			choose: 2
		})
	},
	selReport: function (e) {
		var index = e.currentTarget.dataset.index
		var indexs = index
		var reType = this.data.report[index].w
		this.setData({
			indexs: indexs,
			choose: 1,
			reType: reType
		})
		console.log(e)
	},
	back: function () {
		this.setData({
			choose: 1
		})
	},
	getText: function (e) {
		this.setData({
			text: e.detail.value
		})
	},
	comfir: function () {
		var that = this
		var shopId = that.data.shopId
		var upload = that.data.upload
		var reType = that.data.reType
		var text = that.data.text
		var length = upload.length
		var q = 0
		if (length == 0) {
			wx.showModal({
				title: '提示',
				content: '请上传图片',
				showCancel: false
			})
			return false
		}
		if (reType == '选择举报类型') {
			wx.showModal({
				title: '提示',
				content: '请选择举报类型',
				showCancel: false
			})
			return false
		}
    var f = {};//----------------------------  后缀名
    for (var p in upload) {
      var filename = upload[p];
      var index1 = filename.lastIndexOf(".");
      var index2 = filename.length;
      f[p] = filename.substring(index1, index2);//后缀名  
    }
    var q = JSON.stringify(f)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Shop/shopReport',
			data:
			{
				shopId: shopId,
				reType: reType,
				text: text,
				userId: app.globalData.userId,
        q:q,
			},
			method: 'POST',
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			success: function (res) {
        console.log(res)
				if (res.data.isDisable == 1) {
					wx.showModal({
						title: '提示',
						content: '含有敏感字符',
						showCancel: false
					})
					return false
				}
				if (res.data.isUse == 0) {
					wx.showModal({
						title: '提示',
						content: '你的账号已被封停！无法进行该操作',
						showCancel: false
					})
					return false
				}
				if (res.data.res == 1) {
          var q = 0;
					for (var i in upload) {
            var img = res.data.oss.dir + res.data.name[i];
            console.log(img)
						wx.uploadFile({
              url: res.data.oss.host,
							filePath: upload[i],
							name: 'file',
              formData: {
                "key": res.data.oss.dir + res.data.name[i],//图片的路径
                "policy": res.data.oss.policy,
                "OSSAccessKeyId": res.data.oss.accessid,
                'success_action_status': '200',
                'signature': res.data.oss.signature
              },
							header: { "Content-Type": "multipart/form-data" },
							success: function (ress) {
                console.log(ress)
                if (ress.statusCode == 200) {
                  wx.request({
                    url: 'https://www.aftdc.com/wxapp/Shop/reImg',
                    method: 'POST',
                    data: {
                      id: res.data.id,
                      file: res.data.oss.dir + res.data.name[i],
                    },
                    success: function (b) {
                      console.log(b)
                      if (b.data.res == 1) {
                        q++
                        console.log(q, length)
                        if (q == length) {
                          wx.showModal({
                            title: '提示',
                            content: '提交成功',
                            showCancel: false,
                            success: function () {
                              wx.navigateBack()
                            }
                          })
                        }
                      }
                    }
                  })
                }
							}
						})
					}
				}
			}
		})
	}
})