var app = getApp();
var MD5Util = require('../../utils/md5.js');
var time = null
var start = 0;
var util = require('../../utils/util.js');
var zanTime
Page({
	data: {
		spec: {},
		car: [],
		toView: '',
		foodname: '',
		totalprice: 0,
		totalnumb: 0,
		boxshow: false,//详情显示
		conpouBox: false,//优惠券弹出框
		hongbaoBox: false,   //是否显示红包弹出框
		hongbaoBox2: false,
		hongbaoStatus: false, //红包是否已经领取过
		hongbaoSum: 0,//红包总额
		hongbaoCount: 0,//红包数
		hongbaoList: '',//获得的红包列表
		conpouIdArr: '',
		deskNum: -1,//外卖
		hidden: true,
		shopcar: false,
		ordersHeight: 50,
		showPrice: 0,
		boxFees: 0,
		languageScoll: false,
		zkshow: true,
		lenOrder: 100,
		shareIdD: false,
		shopType: 0,
		pid: 0,
		bargain: [],//砍价缓存
		bargainBox: {},//砍价的数据
		bargainIndex: false,
		bargainTogle: false,
		model: { togle: false, txt: '力道虽好，技术欠佳', price: '0.06' },
		attentionType: 0,
		discount: true,//是否享受优惠
		options: [],//实现下拉刷新需要的options
		shareId: false,//拼单
		more: false,
		currentTab: 0, //预设当前项的值
		plindex: 1,
		plPage: 0,
		plScrolltolower: true, //评论上拉加载
		changepl: [],//点赞
		add: [],
		deletes: [],
		Von: [],
		hongbao: ''
	},
	onLoad: function (options) {
		var userId = app.globalData.userId
		if (!userId) userId = -1
		var orderType = options.orderType
		var shops_coupon_id = options.shops_coupon_id
		if (shops_coupon_id) {
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Shop/shops_coupon',
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				data: {
					shops_coupon_id: shops_coupon_id,
					userId: userId,
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
				},
				method: "POST",
				success: function (res) {
					console.log(res)
				}
			})
		}
		this.setData({ pid: options.pid, options: options })//分销数据
		if (orderType) {//扫码进来
			wx.setStorageSync('orderType', orderType)
			this.setData({
				orderType: orderType
			})
		} else {//从首页进来
			var orderType = wx.getStorageSync('orderType')
			this.setData({
				orderType: orderType
			})
		}
		var shopId = options.shopId
		this.setData({ "shopId": shopId })
		//有id即拼单进来
		var id = options.id

		if (app.globalData.usersInfo) {
			var userId = app.globalData.userId
		} else {
			var userId = 0
		}
		var that = this
		that.setData({
			options: options,
			shopId: shopId,
			id: id,
			shareOrderId: options.shareOrderId
		})
		//否则清除订座缓存
		// wx.removeStorageSync('orderfood')
		if (options.deskNum != undefined && options.deskName != undefined) {//有座位号和桌位名称，堂食扫码点餐进来
			var deskName = options.deskName
			// unicode 转成 中文
			var str = deskName.replace(/\\/g, "%");
			deskName = unescape(str);
			this.setData({
				deskNum: options.deskNum,
				deskName: deskName,
				orderType: 2
			})
		}

		wx.getLocation({
			type: 'gcj02',
			success: function (res) {
				var latitude = res.latitude
				var longitude = res.longitude
				var timestamp = (Date.parse(new Date())) / 1000
				var sign = MD5Util.sign(timestamp)
				wx.request({
					url: 'https://www.aftdc.com/wxapp/Shop/index',
					header: {
						"Content-Type": "application/x-www-form-urlencoded"
					},
					data: {
						shopId: shopId,
						userId: userId,
						deskNum: that.data.deskNum,
						latitude: latitude,
						longitude: longitude
					},
					method: "POST",
					success: function (res) {
						var shopInfo = res.data.info
						//单位换算
						if (parseFloat(shopInfo.distance) > 0 && parseFloat(shopInfo.distance) < 1000) {
							shopInfo.distances = shopInfo.distance + 'm'
						} else if (parseFloat(shopInfo.distance) == 0) {
							shopInfo.distances = '1m'
						} else {
							shopInfo.distances = parseFloat(shopInfo.distance / 1000).toFixed(1) + 'km'
						}
						that.setData({
							arr: res.data,
							shopInfo: shopInfo,
							attentionType: res.data.info.attentionType,

						})
						//轮播订单 
						var orders = res.data.orders
						var orders = util.shijian(new Date, orders)
						var len = orders.length
						if (Boolean(len)) {
							that.setData({
								lenOrder: 10,
							})
						}
						that.setData({
							orders: orders
						})
						//评价
						var pinglun = res.data.pinglun.all
						if (pinglun) {
							that.setData({
								plPage: res.data.pinglun.all.length
							})
						} else {
							that.setData({
								plScrolltolower: false
							})
						}

						//如果该店铺有菜单
						var orders = res.data[0]
						if (orders) {
							that.setData({
								languageTxt: res.data[0].language
							})
							var arr = res.data[0].dishes
							that.setData({
								Von: arr,
							})
							//....
							var foodAdd = wx.getStorageSync('foodAdd')
							wx.removeStorageSync('foodAdd')
							var Von = arr
							if (foodAdd) {
								if (foodAdd.length > 0) {
									for (var z in foodAdd) {
										for (var i in Von) {
											for (var j in Von[i].distop) {
												if (foodAdd[z].goodsId == Von[i].distop[j].goodsId) {
													var numb = foodAdd[z].numb
													that.foodAdd(i, j, numb)
												}
											}
										}
									}
								}
							}
						}

						//砍价---
						that.bargainOnload()

						// 截取优惠信息
						var youh = res.data.info.youhui
						youh = youh.replace(/，/g, ',')
						var str = youh.split(",")
						var lenstr = str.length
						var tipsIfor = []
						for (var i = 0; i < lenstr; i++) {
							var cond = str[i].substring(str[i].indexOf("满") + 1, str[i].indexOf("减"));
							var result = str[i].substring(str[i].indexOf("减") + 1);
							var obj = { m: cond, j: result }
							tipsIfor.push(obj)
						}
						that.setData({
							distance_price: shopInfo.deliveryFreeMoney,    //差多少钱起送
							loading: true,
							tipsIfor: tipsIfor,//满减的数据
						})
						wx.setNavigationBarTitle({
							title: shopInfo.shopName
						})
						//缓存店铺信息
						wx.setStorageSync('shopInfo', shopInfo)
						//判定优惠券
						var conpou = res.data.coupon
						var conpouIdArr = that.data.conpouIdArr

						if (conpou) {
							var orderCoupon = true
							var conpoulen = conpou.length
							//计算优惠券总金额
							var couponSum = 0
							for (var i in conpou) {
								couponSum += Number(conpou[i].couponMoney)
								conpouIdArr += conpou[i].couponId + ","
								if (!conpou[i].type) {
									var conpouState = true;
								} else {
									var conpouState = false;
								}
							}
							that.setData({
								couponSum: couponSum,
								conpouIdArr: conpouIdArr,
								conpouState: conpouState,
							})
							//优惠券长度
							if (conpoulen > 1) {
								that.setData({
									presentNub: true,
								})
							} else {
								var OnespendMoney = conpou[0].spendMoney
								that.setData({
									presentNub: false,
									OnespendMoney: OnespendMoney
								})
							}
						} else {
							var orderCoupon = false
						}

						if (!conpou == '') {
							that.setData({
								conpou: conpou.reverse(),
							})
						}
						//获取信息
						that.setData({
							vip: res.data.vip,
							conpoulen: conpoulen,
							orderCoupon: orderCoupon
						})
					}
				})
			}
		})
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Shop/putInHistory',
			data: {
				// sign: sign,
				// timestamp: timestamp,
				// token: app.globalData.usersInfo.token,
				shopId: shopId,
				userId: userId,
				action: 0
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: "POST",
			success: function (res) {

			}
		})
		//查询设备信息 
		wx.getSystemInfo({
			success: function (res) {
				that.setData({
					ordersContent: res.windowHeight - res.windowWidth / 750 * (350 - that.data.lenOrder),
				})
			}
		})
	},
	onShow: function () {
		//获取是否有拼单
		var shareId = wx.getStorageSync('shareId');
		this.setData({
			shareId: shareId
		})
		var route = this.data.route
		var that = this
		wx.getSetting({
			success(res) {
				if (res.authSetting['scope.userInfo']) {//登录了
					if (route == 'price') {
						that.price()
					} else if (route == 'shareOrder') {
						that.shareOrder()
					} else if (route == 'touchAttention') {
						that.touchAttention()
					}
					that.data.route = null
				}
			}
		})
	},

	// 下拉加载
	// onPullDownRefresh: function (e) {
	// 	var options = this.data.options
	// 	this.onLoad(options);
	// 	wx.hideNavigationBarLoading() //完成停止加载
	// 	wx.stopPullDownRefresh()
	// },
	//初始化砍价信息
	bargainOnload: function () {
		var all = this.data.Von;
		var lenall = all.length;
		var kan = 666;//随便预定义，如果没获取到新值，证明没有砍价活动
		for (var i = 0; i < lenall; i++) {
			if (all[i].catId == 1) {
				kan = i;
				break;
			}
		}
		if (kan != 666) {
			var goods = all[kan].distop;
			var len = goods.length;
			for (var i = 0; i < len; i++) {
				goods[i].percent = 100;//插入控制砍价的长度比
			}
			//获得缓存
			var bargain = wx.getStorageSync("bargain");
			if (!Boolean(bargain)) {
				bargain = [];
			} else {
				var bars = bargain.length
				var datas = false;
				var shopId = this.data.shopId
				for (var z = 0; z < bars; z++) {
					if (bargain[z].shopId == shopId) {
						datas = bargain[z].datas
					}
				}
				if (Boolean(bars)) {
					var datasL = datas.length
					for (var i = 0; i < len; i++) {
						var goodsId = goods[i].goodsId;
						for (var j = 0; j < datasL; j++) {
							var id = datas[j].goodsId;
							if (id == goodsId) {
								goods[i].percent = datas[j].percent;
								goods[i].result = datas[j].result;
								goods[i].shopPrice = datas[j].result;

							}
						}
					}
				}
			}
			all[kan].distop = goods
			this.setData({
				Von: all,
				bargain: bargain, //缓存
			})
		}
	},
	//店铺详情
	shopdetail: function () {
		var that = this;
		wx.navigateTo({
			url: '../order/shopdetail/shopdetail?shopId=' + that.data.shopId + '&attentionType=' + that.data.attentionType,
		})
	},
	//选择菜品分类
	selectMenu: function (e) {
		var index = e.currentTarget.dataset.index;
		this.setData({
			toView: 'order' + index.toString(),
			foodindex: -1,
		})
	},
	selectfood: function (e) {
		var index = e.currentTarget.dataset.index;
		this.setData({
			foodname: 'name' + index.toString(),
			foodindex: index
		})
	},
	sub: function (e) {//减
		var index = e.currentTarget.dataset.index;
		var foodindex = e.currentTarget.dataset.foodindex;
		var Von = this.data.Von
		Von[index].distop[foodindex].numb--
		this.setData({
			Von: Von
		})
		var mark = 'a' + index + 'b' + foodindex
		var arr = Von[index].distop[foodindex]
		var boxFee = this.data.boxFee
		var deskNum = this.data.deskNum
		if (deskNum == -1) {
			if (arr['boxFee'] == '1') {
				start--
				var boxFees = start * boxFee
				this.setData({
					boxFees: boxFees
				})
			}
		}
		var car = this.data.car
		var obj = { arr: arr, mark: mark };
		var car1 = car.filter(item => item.mark != mark)
		if (Von[index].distop[foodindex].numb > 0) {
			car1.push(obj)
			this.setData({
				car: car1
			})
		} else {
			for (var i in car) {
				if (mark == car[i].mark) {
					car.splice(i, 1)
					this.setData({
						car: car
					})
					this.sum()
					return
				}
			}
		}
		this.sum()
	},

	add: function (e) {//加
		var index = e.currentTarget.dataset.index;
		var foodindex = e.currentTarget.dataset.foodindex;
		var Von = this.data.Von
		var that = this
		if ((parseInt(Von[index].distop[foodindex].goodsStock) == 0) || ((parseInt(Von[index].distop[foodindex].goodsStock) <= Von[index].distop[foodindex].numb) && (parseInt(Von[index].distop[foodindex].goodsStock) != -1))) {
			wx.showToast({
				title: '没有库存了',
				content: '该订单部分商品库存不足',
				icon: 'loading',
				duration: 2000,
				success: function () {
					Von[index].distop[foodindex].numb = Von[index].distop[foodindex].numb
					that.setData({
						Von: Von
					})
					return false
				}
			})
			return false
		}

		if (parseInt(Von[index].distop[foodindex].isSale) == 0) {
			wx.showToast({
				title: '商品已下架',
				content: '该订单部分商品已下架',
				icon: 'loading',
				duration: 2000,
				success: function () {
					Von[index].distop[foodindex].numb = Von[index].distop[foodindex].numb
					that.setData({
						Von: Von
					})
					return false
				}
			})
			return false
		}


		if (!Boolean(Von[index].distop[foodindex].numb)) {
			Von[index].distop[foodindex].numb = 0
		}
		Von[index].distop[foodindex].numb++

		this.setData({
			Von: Von
		})
		var car = this.data.car
		var arr = Von[index].distop[foodindex]
		var boxFee = this.data.boxFee
		var deskNum = this.data.deskNum
		if (deskNum == -1) {
			if (arr['boxFee'] == '1') {
				start++
				var boxFees = start * boxFee
				this.setData({
					boxFees: boxFees
				})
			}
		}
		var mark = 'a' + index + 'b' + foodindex
		var obj = { arr: arr, mark: mark };
		var car1 = car.filter(item => item.mark != mark)
		if (obj.arr.type == 2) {
			if (car1.length > 0) {
				wx.showToast({
					title: '团购商品不可与其他商品同时购买',
					icon: 'loading',
					duration: 1500
				})
				Von[index].distop[foodindex].numb = 0
				this.setData({
					Von: Von
				})
			} else {
				car1.push(obj)
				this.setData({
					car: car1
				})
				this.price()
			}
		} else {
			car1.push(obj)
			this.setData({
				car: car1
			})
		}


		var cars = this.data.car
		this.sum()
	},
	//总数
	sum: function (index, foodindex) {
		var totalprice = 0
		var totalnumb = 0
		var totalMarketPrice = 0
		var car = this.data.car
		var zkNumb = this.data.zkNumb
		this.setData({
			zkshow: true,
		})
		var types = true
		for (var i = 0; i < car.length; i++) {
			//商品存在 type=1为不享受活动
			if (Boolean(car[i].arr.type) && types) {
				types = false;
			}
			totalprice += car[i].arr.shopPrice * car[i].arr.numb;
			totalMarketPrice += car[i].arr.marketPrice * car[i].arr.numb;
			totalnumb += car[i].arr.numb
			if (Boolean(zkNumb)) {
				var mark = car[i].mark
				var a = mark.substring(mark.indexOf("a") + 1, mark.indexOf("b"))
				if (a == Number(zkNumb) - 1) {
					this.setData({
						zkshow: false,
					})
					zkNumb = false
				}
			}
		}
		totalprice = Number(totalprice + this.data.boxFees).toFixed(2)
		totalMarketPrice = Number(totalMarketPrice).toFixed(2)
		this.setData({
			totalprice: totalprice,
			totalnumb: totalnumb,
			discount: types,//是否能享受优惠
		})
		//判断起送价
		if (this.data.id == undefined) {
			var dfm = this.data.shopInfo.deliveryFreeMoney
			var distance_price = parseInt(dfm * 100 - totalMarketPrice * 100) / 100

			if (distance_price > 0) {
				this.setData({
					distance_price: distance_price,
					shopcar: false,
				})
			} else if (car.length < 1) {
				this.setData({
					shopcar: false
				})
			} else {
				this.setData({
					distance_price: false,
					shopcar: true,
				})
			}
		} else {
			this.setData({
				shareIdD: true,
				shopcar: true
			})
		}
		//不能享受优惠就不走下面的计算
		if (types) {

			//满减
			var tipsIfor = this.data.tipsIfor
			var lenTips = tipsIfor.length
			var tipsIforEnd = -1
			var tipsIforData = {}
			for (var i = 0; i < lenTips; i++) {
				var m = Number(tipsIfor[i].m)
				if (m <= totalprice) {
					tipsIforEnd = i
				}
			}
			var Ends = tipsIforEnd + 1
			if (tipsIforEnd < 0) {
				var againM = parseInt(tipsIfor[0].m * 100 - totalprice * 100) / 100
				tipsIforData.againM = againM;
				tipsIforData.againJ = tipsIfor[0].j;
				var deduction = 0 //优惠金额
			} else if (tipsIforEnd >= 0 && Ends < lenTips) {     //有立减，而且后面还存在金额更大的立减
				var againM = parseInt(tipsIfor[Ends].m * 100 - totalprice * 100) / 100
				tipsIforData.againM = againM;
				tipsIforData.againJ = tipsIfor[Ends].j;
				tipsIforData.resultJ = tipsIfor[tipsIforEnd].j;
				var deduction = tipsIfor[tipsIforEnd].j;//优惠金额
			} else if (tipsIforEnd == lenTips - 1) {
				tipsIforData.endM = tipsIfor[tipsIforEnd].m;
				tipsIforData.endJ = tipsIfor[tipsIforEnd].j;
				var deduction = tipsIfor[tipsIforEnd].j;//优惠金额
			}
			this.setData({
				tipsIforData: tipsIforData,
				deduction: deduction
			})
		}
	},
	//获取点击的规格
	size: function (e) {
		var size = e.target.dataset.size
		var val = e.target.dataset.val
		var box = this.data.box //获取弹出盒子的数据 
		var goodsId = box.goodsId
		box.decide.size = size //点击变色
		var mark = box.mark;
		var a = mark.substring(mark.indexOf("a") + 1, mark.indexOf("b"))
		var b = mark.substring(mark.indexOf("b") + 1)
		var Von = this.data.Von
		box.shopPrice = Von[a].distop[b].size[size].price
		this.setData({
			box: box,
		})
		box.spec_size = val
	},
	taste: function (e) {
		var taste = e.target.dataset.taste
		var val = e.target.dataset.val
		var box = this.data.box //获取弹出盒子的数据
		var decide = this.data.decide
		box.decide.taste = taste //点击变色
		box.spec_taste = val
		this.setData({
			box: box,
		})
	},
	//隐藏详情弹出框
	hidden: function (e) {
		this.setData({
			boxshow: false
		})
	},
	//详情弹出框
	boxshow: function (e) {
		var index = e.currentTarget.dataset.index;
		var foodindex = e.currentTarget.dataset.foodindex;
		var goodsType = e.currentTarget.dataset.type;
		//对应左边类目
		var Von = this.data.Von
		//如果为砍价
		if (Von[index].catId == 1) {
			this.bargainBoxShow(index, foodindex);
			return false
		}

		// 
		var box = Von[index].distop[foodindex]
		var mark = 'a' + index + 'b' + foodindex
		box.mark = mark
		if (box.size) {
			var index = box.decide.size
			box.spec_size = box.size[index].name
		}
		if (box.taste) {
			var index2 = box.decide.taste
			box.spec_taste = box.taste[index2].name
		}
		//规格
		this.setData({
			box: box,
			boxshow: true,
			goodsType: goodsType
		})
	},
	killshow: function (e) {
		var index = e.currentTarget.dataset.index;
		var box = this.data.goodsKill[index]
		this.setData({
			box: box,
			boxshow: true
		})
	},
	//选好了
	ok: function () {
		var box = this.data.box
		var mark = box.mark //获取弹出盒子的弹出哪件商品标识
		var a = mark.substring(mark.indexOf("a") + 1, mark.indexOf("b"))
		var b = mark.substring(mark.indexOf("b") + 1)
		var Von = this.data.Von
		Von[a].distop[b].shopPrice = box.shopPrice
		Von[a].distop[b].spec_size = box.spec_size
		Von[a].distop[b].spec_taste = box.spec_taste
		Von[a].distop[b].goodsAttrName = (Von[a].distop[b].spec_size ? Von[a].distop[b].spec_size : "") + " "
		Von[a].distop[b].goodsAttrName += Von[a].distop[b].spec_taste ? Von[a].distop[b].spec_taste : ""
		Von[a].distop[b].decide = box.decide
		this.setData({
			Von: Von,
			boxshow: false,
			bargainTogle: false,//砍价弹出框
		})
		var Von = this.data.Von

		var that = this
		if ((parseInt(Von[a].distop[b].goodsStock) == 0) || ((parseInt(Von[a].distop[b].goodsStock) <= Von[a].distop[b].numb) && (parseInt(Von[a].distop[b].goodsStock) != -1))) {

			wx.showToast({
				title: '没有库存了',
				content: '该订单部分商品库存不足',
				icon: 'loading',
				duration: 2000,
				success: function () {
					Von[a].distop[b].numb = Von[a].distop[b].numb
					that.setData({
						Von: Von
					})
					//要延时执行的代码
					return false
				}
			})
			return false
		}

		if (parseInt(Von[a].distop[b].isSale) == 0) {
			wx.showToast({
				title: '商品已下架',
				content: '该订单部分商品已下架',
				icon: 'loading',
				duration: 2000,
				success: function () {
					Von[a].distop[b].numb = Von[a].distop[b].numb
					that.setData({
						Von: Von
					})
					return false
				}
			})
			return false
		}
		if (isNaN(Von[a].distop[b].numb))
			Von[a].distop[b].numb = 0
		Von[a].distop[b].numb++
		this.setData({
			Von: Von
		})
		var car = this.data.car
		var arr = Von[a].distop[b] //也可以是  var arr=box
		//var car2 = car.filter(item => item.arr.spec_size == arr.spec_size && item.arr.spec_taste == arr.spec_taste)

		//	if (car2.length > 0) {
		//	arr.numb = car2[0].arr.numb + 1
		//} else {
		//		arr.numb = 1
		//	}
		var car1 = car//.filter(item => item.arr.spec_size != arr.spec_size || item.arr.spec_taste != arr.spec_taste)

		if (car1.filter(item => item.arr.goodsId == arr.goodsId && item.arr.spec_size == arr.spec_size && item.arr.spec_taste == arr.spec_taste).length > 0) {
			car1.filter(item => item.arr.goodsId == arr.goodsId && item.arr.spec_size == arr.spec_size && item.arr.spec_taste == arr.spec_taste)[0].arr.numb++;
		}
		else {
			arr.numb = 1;
			var obj = { arr: arr, mark: mark };
			car1.push(obj)
		}
		this.setData({
			car: car1
		})
		this.sum()
	},
	//购物总数弹出框
	shopp: function (e) {
		var car = this.data.car
		if (car.length > 0) {
			this.setData(
				{
					tipss: true,
				});
			var animation = wx.createAnimation({
				duration: 300,
				timingFunction: "linear",
				delay: 0,
			})
			this.animation = animation
			animation.translateY(300).step()
			setTimeout(function () {
				this.setData(
					{
						tipss: false,
					});
			}.bind(this), 600)
			this.setData({
				animationData: animation.export()
			})
			if (e.currentTarget.dataset.serve == 1) {
				this.setData(
					{
						goods: true
					});
			}
			setTimeout(function () {
				animation.translateY(0).step()
				this.setData({
					animationData: animation.export()
				})
				if (e.currentTarget.dataset.serve == 0) {
					this.setData(
						{
							tipss: false,
							goods: false
						});
				}
			}.bind(this), 300)
		} else {
			this.setData(
				{
					tipss: false,
					goods: false
				});
		}
	},
	//购物总数弹出框的·减
	buysub: function (e) {
		var i = e.currentTarget.dataset.i;
		var car = this.data.car
		car[i].arr.numb--
		var mark = car[i].mark
		var a = mark.substring(mark.indexOf("a") + 1, mark.indexOf("b"))
		var b = mark.substring(mark.indexOf("b") + 1)

		var Von = this.data.Von
		Von[a].distop[b].numb--
		var arr = Von[a].distop[b]
		var deskNum = this.data.deskNum
		if (deskNum == -1) {
			var boxFee = this.data.boxFee
			if (arr['boxFee'] == '1') {
				start--
				var boxFees = start * boxFee
				this.setData({
					boxFees: boxFees
				})
			}
		}
		this.setData({
			car: car,
			Von: Von,
		})
		if (car[i].arr.numb <= 0) {
			car.splice(i, 1)
			this.setData({
				car: car,
			})
		}
		this.sum()
	},
	//购物总数弹出框的·加
	buyadd: function (e) {
		var i = e.currentTarget.dataset.i;
		var car = this.data.car
		car[i].arr.numb++

		var mark = car[i].mark
		var a = mark.substring(mark.indexOf("a") + 1, mark.indexOf("b"))
		var b = mark.substring(mark.indexOf("b") + 1)

		var Von = this.data.Von
		Von[a].distop[b].numb++
		var arr = Von[a].distop[b]
		var boxFee = this.data.boxFee
		var deskNum = this.data.deskNum
		if (deskNum == -1) {
			if (arr['boxFee'] == '1') {
				start++
				var boxFees = start * boxFee
				this.setData({
					boxFees: boxFees
				})
			}
		}
		this.setData({
			car: car,
			Von: Von,
		})
		this.sum()
	},
	//优惠券
	conpouShow: function (e) {
		// var show = e.currentTarget.dataset.show;
		var presentNub = this.data.presentNub
		var userId = app.globalData.userId
		var receiveSum = 0
		var conpou = this.data.conpou
		for (var i in conpou) {
			if (!conpou[i].type) {
				receiveSum += Number(conpou[i].couponMoney)
			}
		}
		this.setData({
			receiveSum: receiveSum
		})
		var that = this
		var conpouIdArr = that.data.conpouIdArr
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Shop/addCou',
			method: "POST",
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				conpouIdArr: conpouIdArr,
				userId: userId
			},
			success: function (res) {
				if (res.data == 1) {
					that.setData({
						conpouState: false
					})
				}
			}
		})
		if (presentNub) {
			this.setData({
				conpouBox: true
			})
		}
	},
	close: function () {
		this.setData({
			conpouBox: false
		})
	},

	hongBaoShow: function () {
		var userId = app.globalData.userId
		var shopId = this.data.shopId
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			return false
		} else {
			var that = this
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Shop/hongbao',
				method: "POST",
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					shopId: shopId,
					userId: userId
				},
				success: function (res) {
					//  if (res.data == 1) {
					that.setData({
						hongbaoState: 0,
						hongbaoList: res.data,
						hongbaoBox2: 1
					})
					//   }
				}
			})
		}
	},
	closeRed: function () {
		this.setData({
			hongbaoBox: false,
		})
	},

	close: function () {
		this.setData({
			conpouBox: false
		})
	},

	hongBaoClose: function () {
		this.setData({
			hongbaoBox2: false
		})
	},

	//下单购买
	price: function () {
		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			that.data.route = 'price'
			return false
		} else {
			var shopId = that.data.shopId
			var deskNum = that.data.deskNum
			var deskName = that.data.deskName
			var userId = app.globalData.userId
			wx.removeStorageSync('orderfood')
			var car = that.data.car
			var orderfood = []
			var orderType = that.data.orderType
			for (var i in car) {
				orderfood[i] = car[i].arr
				orderfood[i].mark = car[i].mark
			}
			wx.setStorageSync('orderfood', orderfood)

			if (app.globalData.userId) {
				wx.request({
					url: 'https://www.aftdc.com/wxapp/Shop/putInHistory',
					data: {
						// sign: sign,
						// timestamp: timestamp,
						// token: app.globalData.usersInfo.token,
						shopId: that.data.shopId,
						userId: app.globalData.userId,
						action: 1,
						goodsId: JSON.stringify(orderfood)
					},
					header: {
						"Content-Type": "application/x-www-form-urlencoded"
					},
					method: "POST",
					success: function (res) {

					}
				})
			}

			if (orderType == 2) {//扫码点餐进来
				wx.navigateTo({
					url: 'submit/submit?deskNum=' + deskNum + '&deskName=' + deskName + '&deduction=' + that.data.deduction + '&pid=' + that.data.pid
				})
			} else if (deskNum == -1) {
				wx.navigateTo({
					url: 'submit/submit?deduction=' + that.data.deduction + '&pid=' + that.data.pid,
				})
			}
		}
	},
	//分享设置
	onShareAppMessage: function () {
		var that = this
		var shopname = that.data.arr.info.shopName
		var shopId = that.data.shopId
		var userId = app.globalData.userId
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)

		if (userId) {

			return {
				title: shopname,
				path: '/pages/order/order?shopId=' + shopId + '&pid=' + userId,
				success: function (res) {

					if (that.data.hongbao.hongbao_count > 0) {
						that.setData({
							hongbaoBox: true,
							hongbaoSum: that.data.hongbao.sum_money,
							hongbaoCount: that.data.hongbao.hongbao_count,
							hongbaoState: that.data.hongbao.get,
						})
						if (that.data.hongbao.get == 0 && that.data.hongbao.hongbao_count > 0)
							that.hongBaoShow()
					}
					else {
						that.setData({
							hongbaoBox: false
						})
					}


				}
			}
		} else {
			return {
				title: shopname,
				path: '/pages/order/order?shopId=' + shopId
			}
		}
	},
	foodAdd: function (i, j, numb) {//加 
		var index = i
		var foodindex = j
		var Von = this.data.Von
		Von[index].distop[foodindex].numb = numb
		this.setData({
			Von: Von
		})
		var car = this.data.car
		var arr = Von[index].distop[foodindex]
		var boxFee = this.data.boxFee
		var deskNum = this.data.deskNum
		if (deskNum == -1) {
			if (arr['boxFee'] == '1') {
				start = numb + start
				var boxFees = start * boxFee
				this.setData({
					boxFees: boxFees
				})
			}
		}
		var mark = 'a' + index + 'b' + foodindex
		var obj = { arr: arr, mark: mark, };
		var car1 = car.filter(item => item.mark != mark)
		car1.push(obj)
		this.setData({
			car: car1
		})
		var cars = this.data.car
		this.sum()
	},

	closeCar: function (i, nub) {
		var i = i;
		var car = this.data.car
		car[i].arr.numb = 0
		var mark = car[i].mark
		var a = mark.substring(mark.indexOf("a") + 1, mark.indexOf("b"))
		var b = mark.substring(mark.indexOf("b") + 1)

		var Von = this.data.Von
		Von[a].distop[b].numb = 0
		var arr = Von[a].distop[b]
		var deskNum = this.data.deskNum
		if (deskNum == -1) {
			var boxFee = this.data.boxFee
			if (arr['boxFee'] == '1') {
				start = start - nub;

				var boxFees = start * boxFee
				this.setData({
					boxFees: boxFees
				})
			}
		}
		this.setData({
			car: car,
			Von: Von,
		})

		if (car[i].arr.numb <= 0) {
			car.splice(i, 1)
			this.setData({
				car: car,
			})
		}
		this.sum()
	},
	allpj: function () {
		wx.navigateTo({
			url: './shopdetail/allpj/allpj?shopId=' + this.data.shopId,
		})
	},

	//堂食预订
	reserveDesk: function (e) {
		var shopId = this.data.shopId
		var shopName = this.data.shopInfo.shopName
		wx.navigateTo({
			url: './desk/desk?shopId=' + shopId + '&shopName=' + shopName,
		})
	},

	languageChoi: function () {
		var lan = !this.data.languageScoll
		this.setData({
			languageScoll: lan,
		})
	},
	shareOrder: function () {
		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			that.data.route = 'shareOrder'
			return false
		} else {
			var shopId = that.data.shopId
			var dsm = that.data.shopInfo.deliveryStartMoney
			var dfm = that.data.shopInfo.deliveryFreeMoney
			var shopName = that.data.shopInfo.shopName
			wx.navigateTo({
				url: './shareOrder/shareOrder?shopId=' + shopId + '&dsm=' + dsm + '&dfm=' + dfm + '&shopName=' + shopName,
			})
		}
	},
	//清空购物车
	closeCars: function (e) {
		var car = this.data.car
		var Von = this.data.Von
		var a = Von.length;
		for (var i = 0; i < a; i++) {
			if (Boolean(Von[i].distop)) {
				var b = Von[i].distop.length
				for (var j = 0; j < b; j++) {
					Von[i].distop[j].numb = 0
				}
			}
		}
		this.setData({
			car: [],
			Von: Von,
			tipss: false,
			goods: false,
			boxFees: 0,
		})
		start = 0;
		this.sum()
	},
	//改为外卖模式
	checkShopType: function () {
		this.setData({
			shopType: 0
		})
	},
	//-- 砍价
	bargainBoxFn: function (e) {
		var index = e.currentTarget.dataset.index;
		var foodindex = e.currentTarget.dataset.foodindex;
		var bargainGood = this.data.Von[index].distop[foodindex];
		var bargainIndex = 'a' + index + "b" + foodindex
		var datas = bargainGood;
		this.setData({
			bargainBox: datas,
			bargainIndex: bargainIndex,
			bargainTogle: true,
		})
	},
	//点击图片详情进入
	bargainBoxShow: function (index, foodindex) {

		var bargainGood = this.data.Von[index].distop[foodindex];
		var bargainIndex = 'a' + index + "b" + foodindex
		var datas = bargainGood;
		var box = bargainGood
		box.mark = bargainIndex
		this.setData({
			bargainBox: datas,
			bargainIndex: bargainIndex,
			bargainTogle: true,
			box: box,
		})
	},
	bargainTogleFn: function () {
		var bargainTogle = !this.data.bargainTogle;
		this.setData({
			bargainTogle: bargainTogle,
		})
	},
	bargainBut: function (e) {
		var bari = this.data.bargainIndex
		var random = Math.random();

		var a = bari.substring(bari.indexOf("a") + 1, bari.indexOf("b"))
		var b = bari.substring(bari.indexOf("b") + 1)
		var Von = this.data.Von
		var bargainGood = Von[a].distop[b];
		var re = bargainGood.result;
		var start = bargainGood.start;
		var end = bargainGood.end;
		var poor = parseInt(end * 100 - start * 100) / 100;
		var money = poor * random;
		var percent = Math.round(random * 100);//比例长度
		var prans = {};
		prans.index = bari;
		prans.percent = percent;
		prans.money = money

		var model = this.data.model;
		model.togle = true;
		model.txt = "力道虽好，技术欠佳",
			model.price = parseInt(poor * 100 - money * 100) / 100;
		this.setData({
			prans: prans,
			model: model,
		})
	},

	modelClose: function () {
		var model = this.data.model;
		model.togle = false;
		var bargainBox = this.data.bargainBox
		var Von = this.data.Von

		var prans = this.data.prans;
		var bari = prans.index;
		var a = bari.substring(bari.indexOf("a") + 1, bari.indexOf("b"))
		var b = bari.substring(bari.indexOf("b") + 1)
		var percent = prans.percent;
		var money = prans.money;
		var start = bargainBox.start;

		var numb = parseInt((money * 100) + (start * 100)) / 100
		bargainBox.result = numb;
		bargainBox.shopPrice = numb;
		bargainBox.percent = percent;//百分比
		bargainBox.mark = bari

		Von[a].distop[b] = bargainBox

		this.setData({
			model: model,
			Von: Von,
			bargainBox: bargainBox,
			box: bargainBox
		})
		//添加缓存
		var shopId = this.data.shopId,
			bargain = this.data.bargain,
			goodsId = bargainBox.goodsId,
			lenb = bargain.length,
			state = true;

		var content = { goodsId: goodsId, result: numb, percent: percent }
		if (lenb > 0) {
			for (var i = 0; i < lenb; i++) {
				if (shopId == bargain.shopId) {
					state = false;
					bargain[i].datas.push(content);
					break
				}
			};
		}
		if (state) {
			var datas = [];
			datas.push(content);
			var obj = { shopId: shopId, datas: datas };
			bargain.push(obj)
		}
		wx.setStorageSync('bargain', bargain)
		this.setData({
			bargain: bargain,
		})
	},

	//选好拼单商品
	shareAdd: function () {
		var car = this.data.car
		var id = this.data.id
		var shareFood = []
		for (var i in car) {
			shareFood[i] = car[i].arr
			shareFood[i].mark = car[i].mark
		}
		var goodsInfo = JSON.stringify(shareFood)
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Shop/addGoods',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				id: id,
				goodsInfo: goodsInfo
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					wx.navigateBack({
						delta: 1
					})
				}
			}
		})
	},
	//关闭拼单
	closeShare: function (shareId) {
		var that = this;
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Shop/delShare',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				shareId: shareId
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					wx.removeStorageSync("shareId")
				}
			}
		})
	},
	onUnload: function () {//退出和隐藏页面时再执行关注和取消关注动作
		//执行关注或取消关注的方法
		var attentionType = this.data.attentionType
		var touchAttention = this.data.touchAttention
		if (touchAttention == 1) {
			if (attentionType == 1) {
				this.attention()
			} else {
				this.cancelAttention()
			}
		}
		//清除拼单
		var shareId = wx.getStorageSync('shareId')
		if (shareId) {
			this.closeShare(shareId)
		}
		this.changeZan()
	},
	// onHide: function () {
	// 	this.onUnload()
	// },
	//formId
	formnextBut: function (e) {
		var that = this;
		var shopId = that.data.shopId;
		var formId = e.detail.formId;
		var attentionType = that.data.attentionType
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			that.data.route = 'formnextBut'
			return false
		} else {
			var userId = app.globalData.userId;
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			if (attentionType == 0) {
				wx.request({
					url: 'https://www.aftdc.com/wxapp/Index/formId',
					method: 'post',
					header: { "Content-Type": "application/x-www-form-urlencoded" },
					data: {
						timestamp: timestamp,
						token: app.globalData.usersInfo.token,
						sign: sign,
						formId: formId,
						userId: userId,
						shopId: shopId,
					},
					success: function (res) {
					}
				})
			}
			that.touchAttention();
		}
	},
	//
	icon: function (e) {
	},
	//触发了关注和取消关注的操作
	touchAttention: function () {
		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			that.data.route = 'touchAttention'
			return false
		} else {
			var hobbyTip = that.data.hobbyTip
			that.data.touchAttention = 1
			var attentionType = that.data.attentionType
			if (attentionType == 1) {
				that.setData({
					hobbyTip: true,
					attentionType: 0,
					hobbyTipTitle: '已取消关注'
				})
			} else {
				that.setData({
					hobbyTip: true,
					attentionType: 1,
					hobbyTipTitle: '你关注的商家发布新的动态时将会推送给你'
				})
			}
			if (hobbyTip) {
				return false
			} else {
				var times = setTimeout(function () {
					that.setData({
						hobbyTip: false,
						timeout: true
					})
				}, 5000)
			}
		}
	},
	//关注
	attention: function () {
		var that = this
		var shopId = that.data.shopId
		var userId = app.globalData.userId
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Shop/attention',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				userId: userId,
				shopId: shopId,
				action: 4
			},
			method: "POST",
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
			}
		})
	},
	//取消关注
	cancelAttention: function () {
		var that = this
		var shopId = that.data.shopId
		var userId = app.globalData.userId
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Shop/cancelAttention',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				userId: userId,
				shopId: shopId
			},
			method: "POST",
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
			}
		})
	},
	// 滚动切换标签样式
	switchTab: function (e) {
		this.setData({
			currentTab: e.detail.current
		});
	},
	// 点击标题切换当前页时改变样式
	swichNav: function (e) {
		var cur = e.target.dataset.current;
		if (this.data.currentTaB == cur) { return false; }
		else {
			this.setData({
				currentTab: cur
			})
		}
	},
	phone: function () {
		var that = this
		wx.makePhoneCall({
			phoneNumber: that.data.shopInfo.shopTel,
		})
	},
	//点击评论标签
	plindex: function (e) {
		//1 全部 2有图 3最新
		var plindex = e.currentTarget.dataset.plindex;
		this.setData({
			plindex: plindex
		})
		this.getPl(plindex)
	},
	//获取评论
	getPl: function (plindex) {
		var that = this
		that.data.plPage = 0
		var userId = app.globalData.userId
		if (!userId) { userId = 0 }
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Index/getpl',
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				shopId: that.data.shopId,
				page: 0,
				id: plindex,
				userId: userId
			},
			method: "POST",
			success: function (res) {
				that.data.arr.pinglun.all = res.data.data
				that.setData({
					arr: that.data.arr
				})
			}
		})
	},
	//评论下拉加载
	plScrolltolower: function () {
		if (this.data.plScrolltolower) {
			this.data.plScrolltolower = false
			var that = this
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Index/getpl',
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					shopId: that.data.shopId,
					page: that.data.plPage,
					id: that.data.plindex
				},
				method: "POST",
				success: function (res) {
					if (res.data.res == 1) {
						that.data.plPage = that.data.arr.pinglun.all.concat(res.data.data).length
						that.data.arr.pinglun.all = that.data.arr.pinglun.all.concat(res.data.data)
						that.setData({
							arr: that.data.arr,
							plScrolltolower: true
						})
					} else {
						that.setData({
							plScrolltolower: false
						})
					}
				}
			})
		}
	},
	//填写预订信息
	book: function () {
		var that = this
		var orderfood = []
		var car = that.data.car
		for (var i in car) {
			orderfood[i] = car[i].arr
			orderfood[i].mark = car[i].mark
		}
		wx.setStorageSync('orderfood', orderfood)
		wx.navigateTo({
			url: '../order/desk/desk?shopId=' + that.data.shopId + '&shopName=' + that.data.shopInfo.shopName,
		})
	},
	//点赞
	Praise: function (e) {
		var index = e.currentTarget.dataset.index
		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			return false
		} else {
			that.setData({
				dzan: false
			})
			clearTimeout(zanTime);
			var id = e.currentTarget.dataset.id
			var pinglun = that.data.arr.pinglun.all
			var isDZ = pinglun[index]['isDZ']
			pinglun[index]['isDZ'] = isDZ == 0 ? 1 : 0;

			var zanshow = pinglun[index]['isDZ'];
			var numb = Number(pinglun[index]['numbs']);

			var changepl = that.data.changepl;

			if (zanshow == 0) {
				pinglun[index]['numbs'] = Number(numb - 1);
			} else if (zanshow == 1) {
				that.setData({
					dzan: true,
				})
				clearTimeout(zanTime);
				zanTime = setTimeout(function () {
					that.setData({
						dzan: false
					})
					clearTimeout(zanTime);
				}, 1100)
				pinglun[index]['numbs'] = Number(numb + 1)
			}
			var len = changepl.length
			for (var i = 0; i < len; i++) {
				if (changepl[i].id == id) {
					changepl.splice(i, 1)
					break
				}
			}
			var obj = { id: id, isDZ: zanshow }
			changepl.push(obj)
			that.data.arr.pinglun.all = pinglun
			that.setData({
				arr: that.data.arr,
				changepl: changepl,
			})
		}
	},
	//上传点赞
	changeZan: function () {
		var that = this
		var changepl = that.data.changepl;
		var add = that.data.add;
		var deletes = that.data.deletes;
		var userId = app.globalData.userId;
		var len = changepl.length
		for (var i = 0; i < len; i++) {
			var id = changepl[i].id
			if (changepl[i].isDZ == 1) {
				add.push(id)
			} else if (changepl[i].isDZ == 0) {
				deletes.push(id);
			}
		}
		//改变过 点赞 状态的评论id
		if (add.length > 0 || deletes.length > 0) {
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Appraises/updDz',
				method: "POST",
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				data:
				{
					add: JSON.stringify(add),
					deletes: JSON.stringify(deletes),
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					shopId: that.data.shopId
				},
				success: function (res) {

				}
			})
		}
	},

	zan: function (e) {
		var that = this
		var animation = wx.createAnimation({
			duration: 60,
			timingFunction: "linear",
			delay: 0,
		})
		this.animation = animation

		animation.scale(2, 2).opacity(1).step({ duration: 260 })
		animation.rotate(10).step()
		animation.rotate(0).step()
		animation.rotate(-10).step()

		animation.rotate(10).step()
		animation.rotate(0).step()
		animation.rotate(-10).step()
		animation.rotate(0).scale(1, 1).opacity(0).step({ duration: 260 })
		this.setData({
			animationData: animation.export(),
		})
	},
	//关闭图片
	enlargeClose: function (e) {
		this.setData({
			enlargeBox: false,
		})
	},
	//去收藏页面
	gotoCollect: function () {
		wx.navigateTo({
			url: '/pages/personal/collect/collect',
		})
	},
	formId: function (formId, shopId) {
		var that = this;
		// var userId = app.globalData.userId;
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Index/formId',
			method: 'post',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			data: {
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				sign: sign,
				formId: formId,
				// userId: userId,
				shopId: shopId,
			},
			success: function (res) {
			}
		})
	},
	//收藏
	collect: function (e) {
		var that = this
		var formId = e.detail.formId;
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			that.data.route = 'collect'
			return false
		} else {
			var shopId = that.data.shopId
			that.formId(formId, shopId)
			var userId = app.globalData.userId
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Index/collect',
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					userId: userId,
					shopId: shopId,
					action: 3
				},
				method: "POST",
				header: { "Content-Type": "application/x-www-form-urlencoded" },
				success: function (res) {
					if (res.data.res == 1) {
						wx.showModal({
							title: '提示',
							content: '已收藏',
							showCancel: false,
							success: function () {
								that.data.shopInfo.colType = 1
								var shopInfo = that.data.shopInfo
								that.setData({
									shopInfo: shopInfo
								})
							}
						})
					}
				}
			})
		}
	},
	//查看认证页
	seeAttestation: function () {
		var shopId = this.data.shopId
		wx.navigateTo({
			url: './shopdetail/macher/macher?shopId=' + shopId,
		})
	},
	//显示营业执照和餐饮许可证
	qualifications: function () {
		var shopId = this.data.shopId
		wx.navigateTo({
			url: './shopdetail/qualifications/qualifications?shopId=' + shopId,
		})
	},
	//点击放大图片
	enlargeImg: function (e) {
		var src = e.currentTarget.dataset.src;
		var index = e.currentTarget.dataset.index;
		var txt = e.currentTarget.dataset.txt;
		if (txt != 'img') {
			var srcs = []
			for (var i in src) {
				var img = src[i][txt]
				var obj = { img: img }
				srcs.push(obj)
			}
			src = srcs
		}
		this.setData({
			enlargeSrc: src,
			enlargeBox: true,
			enlargeNumb: index,
		})
	},
	address: function () {
		var latitude = parseFloat(this.data.shopInfo.latitude)
		var longitude = parseFloat(this.data.shopInfo.longitude)
		wx.openLocation({
			latitude: latitude,
			longitude: longitude,
			fail: function (err) {
			}
		})
	},
	//举报
	report: function () {
		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			that.data.route = 'report'
			return false
		} else {
			var shopName = that.data.shopInfo.shopName
			var shopImg = that.data.shopInfo.shopImg
			var shopId = that.data.shopId
			wx.navigateTo({
				url: './shopdetail/shopReport/shopReport?shopName=' + shopName + '&shopImg=' + shopImg + "&shopId=" + shopId,
			})
		}
	},
	//充值
	recharge: function () {
        var timestamp = (Date.parse(new Date())) / 1000
        var sign = MD5Util.sign(timestamp)
        var that = this
        var shopName = that.data.shopInfo.shopName
        var shopImg = that.data.shopInfo.shopImg
        wx.request({
            url: 'https://www.aftdc.com/wxapp/Mine/isInfoFull',
            data: {
                sign: sign,
                timestamp: timestamp,
                token: app.globalData.usersInfo.token,
            },
            method: "POST",
            header: { "Content-Type": "application/x-www-form-urlencoded" },
            success: function (res) {
                if (res.data.res == 1) {
                    wx.navigateTo({
                        url: './shopdetail/charge/charge?shopId=' + that.data.shopId,
                    })
                }
                else if (res.data.res == -1) {
                    wx.navigateTo({
                        url: '/pages/personal/vip/vip?shopId=' + that.data.shopId +'&shopName='+ shopName + '&shopImg=' + shopImg,
                    })
                }
              
            }
        })

	
	},
})
