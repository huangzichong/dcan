var app = getApp();
var MD5Util = require('../../../utils/md5.js');
var util = require('../../../utils/util.js')
var authorization = require('../../../utils/authorization.js')
Page({
	data: {
		showImg: true,
		showTime: true,
		datacolor: 0,
		gett: -1,
		pick: true,
		pickNumb: "请选择",
		reserveTime: "请选择",
		inputs: {},
		deskChild: [],
		deskTypeOk: 1,
		orderFoodStatus: true,
		isYu: 0,
		isBj: false,
		sex: 2,
		baojian: 2,//值 1 只包间，2 可接受大厅
		enlargeBox: false,
	},
	onLoad: function (options) {
		var that = this
		var shopId = options.shopId
		var shopName = options.shopName
		var userId = app.globalData.userId
		var isYus = wx.getStorageSync('orderfood') != '' ? '1' : '0'
		that.setData({
			shopName: shopName,
			shopId: shopId,
			userId: userId,
			isYu: isYus,
			isYus: isYus
		})
		//三天日期
		var das = util.formatTime(new Date)
		var HM = das.substring(das.indexOf("-") + 1)
		var dataThree = {}
		dataThree.today = HM
		for (var i = 1; i < 3; i++) {
			var today = "today" + i
			var HMs = util.addDay(das, i)
			HMs = HMs.substring(HMs.indexOf("-") + 1)
			dataThree[today] = HMs
		}

		var dateN = util.formatTime(new Date)
		//获取可选预计的时间
		that.today()
		var requireTime = dateN + " " + that.data.reTime + ":00";
		that.setData({
			today: dateN,
			serviceStartTime: "09:00", //开店时间
			serviceEndTime: "23:00",  //关店时间
			dataThree: dataThree,
		})
		that.today()
	},
	deskTop: function (e) {
		var id = e.target.dataset.index
		this.setData({
			deskTypeOk: id,
		})
		this.desks(id)
	},
	desks: function (id) {
		var deskChild = []
		var desk = this.data.desk
		if (id == 1) {
			var txt = "散台"
		} else if (id == 2) {
			var txt = "包厢"
		}
		for (var i in desk) {
			if (desk[i].deskType == txt) {
				deskChild.push(desk[i])
			}
		}
		this.setData({
			deskChild: deskChild,
		})
	},
	goon: function () {
		this.setData({
			isclose: 0
		})
		wx.navigateBack({
			delta: 1
		})
	},
	//时间选择
	instant: function (e) {
		var time = e.currentTarget.dataset.str
		this.setData({
			showTime: true,
			gett: -1,
			reserveTime: this.data.today + " " + time,//用餐时间
		})
	},
	comTime: function (e) {
		var index = e.currentTarget.dataset.number
		var time = e.currentTarget.dataset.time
		this.setData({
			showTime: true,
			requireTime: this.data.today + " " + time,
			reserveTime: this.data.today + " " + time,//用餐时间
			gett: index
		})
	},
	today: function () {
		var that = this
		var dateN = util.formatTime(new Date)

		var addTime = util.formatData(new Date)
		//获取可选预计的时间
		var timearr = [];
		for (var i = 0; i < 50; i++) {
			var datestr = util.formateIOS(dateN + ' ' + addTime + ":00")
			var addTime = util.addMinutes(datestr, 30)
			if (datestr < util.formateIOS(dateN + ' ' + that.data.serviceEndTime + ":00")) {
				timearr.push(addTime)
			}
			else {
				break;
			}
		}
		var today = util.formatTime(new Date)
		timearr.pop()
		that.setData({
			timearr: timearr,
			today: today,
			datacolor: 0,
		})
	},
	toTime: function (e) {
		var days = e.currentTarget.dataset.id
		var dateN = util.formatTime(new Date)
		var addTime = this.data.serviceStartTime
		//获取可选预计的时间
		var timearr = [];
		for (var i = 0; i < 50; i++) {
			var datestr = util.formateIOS(dateN + ' ' + addTime + ":00")
			var addTime = util.addMinutes(datestr, 30)
			if (datestr >= util.formateIOS(dateN + ' ' + this.data.serviceEndTime + ":00")) {
				break;
			}
			else {
				timearr.push(addTime)
			}
		}
		var datestr = util.formateIOS(dateN + ' ' + "00:00:00")
		var today = util.addDay(datestr, days)
		timearr.pop()
		this.setData({
			timearr: timearr,
			today: today,
			datacolor: days
		})
	},
	selTime: function () {
		var that = this
		var showTime = !that.data.showTime
		that.setData({
			showTime: showTime,
			pick: true
		})
	},
	quxiao: function () {
		var that = this
		that.setData({
			showTime: true
		})
	},
	ReserveClose: function () {
		var that = this
		that.setData({
			isbuy: 0,
			isYus: 0
		})
		var options = [];
		options.shopId = that.data.shopId
		options.shopName = that.data.shopName
		that.onLoad(options)
	},
	pickshow: function () {
		var pick = !this.data.pick
		this.setData({
			pick: pick,
			showTime: true,
		})
	},
	picks: function (e) {
		var numb = e.currentTarget.dataset.numb
		this.setData({
			pick: true,
			pickNumb: numb + "人 ",
			sbNumb: numb
		})
	},
	//获取input值

	names: function (e) {
		var inputName = e.detail.value
		this.setData({
			inputName: inputName,
		})
	},

	//   phones: function (e) {
	//     var inputPhone = e.detail.value
	//     this.setData({
	//       inputPhone: inputPhone,
	//     })
	//   },
	remarks: function (e) {
		var inputRemark = e.detail.value
		this.setData({
			inputRemark: inputRemark,
		})
	},

	Reserves: function (e) {
		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			return false
		} else {
			var isYu = that.data.isYu
			var sex = that.data.sex
			var baojian = that.data.baojian
			if (!that.data.isBj) {
				baojian = 0
			}
			var fromId = e.detail.formId
			var numb = that.data.sbNumb;//人数
			var reachTime = that.data.reserveTime;//时间
			var inputName = that.data.inputName//姓名
			var inputPhone = app.globalData.usersInfo.userPhone
			if (!inputPhone) {//没有电话号码时中断弹出设置框
				that.setData({
					noPhone: true
				})
				return false
			}
			var inputRemark = that.data.inputRemark//备注
			var oid = app.globalData.usersInfo.openid
			var timestamp = (Date.parse(new Date()) / 1000).toString();
			timestamp = timestamp + Math.floor(9999 * Math.random());;
			if (inputRemark == '' || inputRemark == undefined) {
				inputRemark = ''
			}

			if (numb == "请选择" || reachTime == "请选择" || inputName == undefined || inputName == "" || inputPhone == "" || inputPhone == undefined) {
				util.aftModal({
					title: '请填写完整',
					icon: 'loading',
					duration: 1000,
				})
				return false
			}
			var shopName = that.data.shopName
			var id = that.data.id
			var money = that.data.money
			var date = that.data.date;
			var isYu = that.data.isYu
			var userId = app.globalData.userId
			if (isYu == 1) {
				var arr = new Object();
				arr.numb = numb;
				arr.reachTime = reachTime;
				arr.inputName = inputName;
				arr.inputPhone = inputPhone;
				arr.inputRemark = inputRemark;
				arr.id = id;
				arr.shopId = that.data.shopId;
				arr.userId = userId;
				arr.shopName = shopName;
				arr.money = money;
				arr.fromId = fromId;
				arr.openid = oid;
				arr.baojian = baojian;
				arr.isYu = isYu;
				arr.orderNo = timestamp;
				arr.sex = sex
				//缓存订座数据
				wx.setStorageSync('deskArr', arr)
				wx.navigateTo({
					url: '../submit/submit',
				})
				// wx.showModal({
				// 	title: '提示',
				// 	content: '前往预订菜单',
				// 	showCancel: false,
				// 	success: function () {
				// 		wx.navigateTo({
				// 			url: '../order?shopId=' + that.data.shopId + '&orderType=3',
				// 		})
				// 	}
				// })
				return false;
			}
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Desk/reserve',
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					numb: numb,
					reachTime: reachTime,
					inputName: inputName,
					inputPhone: inputPhone,
					inputRemark: inputRemark,
					id: id,
					shopId: that.data.shopId,
					userId: userId,
					shopName: shopName,
					money: 0,
					fromId: fromId,
					openid: oid,
					sex: sex,
					isYu: isYu,
					orderNo: timestamp,
					baojian: baojian
				},
				method: "POST",
				success: function (res) {
					if (res.data.isUse == 0) {
						util.aftModal({
							title: '你的账号已被封停！无法进行该操作',
							icon: 'loading'
						})
						return false
					}
					if (res.data.status == 1) {
						that.payment(money, shopName, numb, reachTime, inputName, inputPhone, inputRemark, id, timestamp)
					}
					if (res.data.status == 2) {
						var isYus = that.data.isYu
						that.setData({
							isbuy: 1,
							isYus: isYus
						})
						wx.navigateTo({
							url: 'deskSubmit/deskSubmit?id=' + res.data.id,
						})
					}
					else {
						util.aftModal({
							title: res.data.tip,
							icon: 'loading',
							duration: 1000,
							success: function (res) {
								var options = [];
								options.shopId = that.data.shopId
								options.shopName = that.data.shopName
								that.onLoad(options)
							}
						})
					}
				}
			})
		}
	},
	//需要包间
	switch1Change: function (e) {
		var isBj = e.detail.value
		if (isBj) {
			this.setData({
				isBj: true,
			})
		} else {
			this.setData({
				isBj: false,
			})
		}
	},
	//是否接受大厅
	radioChanges: function () {
		if (this.data.baojian == 1) {
			this.setData({
				baojian: 2
			})
		} else {
			this.setData({
				baojian: 1
			})
		}
	},
	//获取是否要预定菜单
	radioChange: function (e) {
		var isYu = e.detail.value
		this.setData({
			isYu: isYu
		})
	},
	//性别选择
	sexChoose: function (e) {
		var sex = e.detail.value
		this.setData({
			sex: sex
		})
	},
	onShow: function () {
		//返回删除缓存
		wx.removeStorageSync('deskArr')
	},
	seeDesk: function () {
		var shopId = this.data.shopId
		var that = this
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Desk/shopImg',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				shopId: shopId
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'POST',
			success: function (res) {
				var src = res.data;
				var index = 0;
				var txt = 'ImgUrl';
				if (txt != 'img') {
					var srcs = []
					for (var i in src) {
						var img = src[i][txt]
						var obj = { img: img }
						srcs.push(obj)
					}
					src = srcs
				}
				that.setData({
					enlargeSrc: src,
					enlargeBox: true,
					enlargeNumb: index,
				})
			}
		})
	},
	enlargeClose: function (e) {
		this.setData({
			enlargeBox: false,
		})
	},
	//获取手机号
	getPhoneNumber: function (e) {
		this.setData({
			noPhone: false
		})
		authorization.getPhone(e)
	},
})
