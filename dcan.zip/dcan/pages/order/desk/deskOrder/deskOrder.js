// pages/order/desk/deskOrder/deskOrder.js
var MD5Util = require('../../../../utils/md5.js');
var app=getApp()
Page({


  data: {
    isOrder:false
  },

  onLoad: function (options) {
    var userId = app.globalData.userId
    this.setData({
      userId: userId
    })
    var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
    wx.request({
      url: 'https://www.aftdc.com/wxapp/Desk/getUserDesk',
      data: {
        userId: userId,
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token
      },
      method: 'POST',
      header: { "Content-Type": "application/x-www-form-urlencoded" },
      success: function (res) {
        if(res.data.length>0)
        that.setData({
          arr: res.data
        })
        else
        {
          that.setData({
            isOrder:true
          })
        }
      }
    })
  },



})