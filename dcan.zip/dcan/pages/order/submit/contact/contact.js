var app = getApp()
var MD5Util = require('../../../../utils/md5.js');
var util = require('../../../../utils/util.js')
var authorization = require('../../../../utils/authorization.js')
Page({

	data: {
		write: true,
		add: false,
		content: '',
		contact: [],
		q: [],
		business_id: 0,
		InvervalPage: 0,
		page: 0,
		intervalis: '',
		onReachUpper: 1,
		timeRange: 0
	},

	onLoad: function (options) {
		this.data.shopId = options.shopId
		var that = this
		wx.getSystemInfo({
			success: function (res) {
				that.setData({
					windowHeight: res.windowHeight - 60,
				})
			}
		})
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Kufu/contactList',
			header: {
				'content-type': 'application/x-www-form-urlencoded'
			},
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				shopId: that.data.shopId,    //店铺的id
				userId: app.globalData.userId,
				page: that.data.page
			},
			method: "POST",
			success: function (res) {
				that.setData({ contact: res.data.data, business_id: res.data.business_id, id: res.data.id })
				if (res.data.data != '') {
					that.setData({
						index: res.data.data.length - 1,
						page: that.data.page + 8,
						timeRange: res.data.timeRange
					})
				}
			}
		})


		that.data.intervalis = setInterval(function () {
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			if (that.data.business_id) {
				wx.request({
					url: 'https://www.aftdc.com/wxapp/Kufu/gu',
					header: {
						'content-type': 'application/x-www-form-urlencoded'
					},
					data: {
						sign: sign,
						timestamp: timestamp,
						token: app.globalData.usersInfo.token,
						business_id: that.data.business_id,    //店铺的id
						id: that.data.id
					},
					method: "POST",
					success: function (res) {
						if (res.data.res) {
                            that.data.contact = that.data.contact.concat(res.data.data)

							that.setData({
								contact: that.data.contact,
								content: '',
								id: res.data.id,
								index: res.data.data.concat(that.data.contact).length - 1,
							})
						}
					}
				})
			}
		}, 30000);
	},

	getTest: function (e) {
		this.setData({
			content: e.detail.value
		})
	},

	del: function (e) {
		var that = this
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		var index = e.currentTarget.dataset.index
		wx.request({
			url: 'https://www.aftdc.com/wxapp/KuFu/del_KuFu',
			header: {
				'content-type': 'application/x-www-form-urlencoded'
			},
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				id: e.currentTarget.dataset.kufu_id,    //客服的id
			},
			method: "POST",
			success: function (res) {
				that.data.contact.splice(index, 1);
				that.setData({ contact: that.data.contact })
			}
		})
	},

	//留言
	send: function (e) {
		if (!this.data.content) {
			wx.showModal({
				title: '提示',
				content: '请输入内容',
				showCancel: false
			})
			return false
		}

		var that = this
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/KuFu/KuFuImg',
			header: {
				'content-type': 'application/x-www-form-urlencoded'
			},
			data: {
				business_id: that.data.business_id,    //店铺的id
				userId: app.globalData.userId,
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				content: that.data.content,
			},
			method: "POST",
			success: function (res) {
				that.data.contact.push(res.data.data)
				that.setData({
					contact: that.data.contact,
					content: '',
					index: that.data.contact.length - 1
				})
			}
		})
	},
	add: function () {
		var add = !this.data.add
		this.setData({
			add: add
		})
	},
	chooseImg: function () {
		var that = this;
		wx.chooseImage({
			count: 1,
			sizeType: ['compressed'],
			sourceType: ['album', 'camera'],
			success: function (res) {
				var imgPaths = res.tempFilePaths
				var index1 = imgPaths[0].lastIndexOf(".");
				var index2 = imgPaths[0].length;
				var q = new Array()
				q[0] = (imgPaths[0].substring(index1, index2));//后缀名 
				that.setData({ imgPaths: imgPaths, q: q })

				var imgPaths = that.data.imgPaths
				if (imgPaths) {
					var timestamp = (Date.parse(new Date())) / 1000
					var sign = MD5Util.sign(timestamp)
					wx.request({
						url: 'https://www.aftdc.com/wxapp/KuFu/KuFuImgToken',
						data: {
							sign: sign,
							timestamp: timestamp,
							token: app.globalData.usersInfo.token,
							q: JSON.stringify(that.data.q)
						},
						header: {
							'content-type': 'application/x-www-form-urlencoded'
						},
						method: "POST",
						success: function (res) {
							var name = res.data.oss.name[0]
							wx.uploadFile({
								url: res.data.oss.host,
								filePath: imgPaths[0],
								name: 'file',
								formData: {
									"key": res.data.oss.name[0],//图片的路径
									"policy": res.data.oss.policy,
									"OSSAccessKeyId": res.data.oss.accessid,
									'success_action_status': '200',
									'signature': res.data.oss.signature
								},
								header: { "Content-Type": "multipart/form-data" },
								success: function (res) {
									if (res.statusCode == 200) {
										var timestamp = (Date.parse(new Date())) / 1000
										var sign = MD5Util.sign(timestamp)
										wx.request({
											url: 'https://www.aftdc.com/wxapp/KuFu/KuFuImg',
											data: {
												business_id: that.data.business_id,    //店铺的id
												userId: app.globalData.userId,
												sign: sign,
												timestamp: timestamp,
												token: app.globalData.usersInfo.token,
												img: name
											},
											method: 'POST',
											header: {
												"Content-Type": "application/x-www-form-urlencoded"
											},
											success: function (res) {
												that.data.contact.push(res.data.data)
												that.setData({
													contact: that.data.contact,
													add: false,
													img: ''
												})
											}
										})
									}
								}
							})
						}
					})
				}
			}
		})
	},

	onUnload: function () {
		clearInterval(this.data.intervalis)
	},
	onReachUpper: function () {
		if (this.data.onReachUpper) {
			this.data.onReachUpper = 0
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			var that = this
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Kufu/contactList',
				header: {
					'content-type': 'application/x-www-form-urlencoded'
				},
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					shopId: that.data.shopId,    //店铺的id
					userId: app.globalData.userId,
					page: that.data.page,
					timeRange: that.data.timeRange
				},
				method: "POST",
				success: function (res) {
					if (res.data.data != '') {
						that.data.onReachUpper = 1;
						var temp = that.data.contact
						var tempMain = res.data.data


						that.setData({
							page: that.data.page + 8,
							contact: res.data.data.concat(that.data.contact),
							timeRange: res.data.timeRange
						})
					}
				}
			})
		}
	}

})