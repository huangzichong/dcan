var MD5Util = require('../../../../utils/md5.js');
var util = require('../../../../utils/util.js')
var authorization = require('../../../../utils/authorization.js')
var app = getApp();
Page({
	data: {
		countDown: '',
		pid: 0
	},

	onLoad: function (options) {
		var that = this
		var orderId = options.orderId
		var tk = options.tk
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		this.setData({ pid: options.pid })
		wx.showLoading()
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Orderinfo/getOneOrder',
			data: {
				orderId: orderId,
				tk: tk,
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				that.setData({
					order: res.data
				})
				console.log(res.data)
				var order = res.data
				if (order.orderType == 3) {
					var deskArr = JSON.parse(order.deskArr)
					that.setData({
						desk: deskArr
					})
				}
				//判断订单当前状态
				that.orderStatus(order.orderStatus, order.orderType);
				//等待付款倒计时
				if (order.orderStatus == -2) {
					that.countDownFn(order.createTime)
				}
				wx.hideLoading()
			}
		})
	},
	//判断订单当前状态
	orderStatus: function (orderStatus, orderType) {
		if (orderStatus == 3 && orderType != 3) {
			this.setData({
				orderStatus: "订单正在配送中"
			})
		} else if (orderStatus == 3 && orderType == 3) {
			this.setData({
				orderStatus: "已受理,等候您的到来"
			})
		} else if (orderStatus == 3 && orderType == 1) {
			this.setData({
				orderStatus: "备餐中"
			})
		} else if (orderStatus == 0) {
			this.setData({
				orderStatus: "等待商家受理"
			})
		} else if (orderStatus == -2) {
			this.setData({
				orderStatus: "等待付款"
			})
		} else if (orderStatus == 4) {
			this.setData({
				orderStatus: "订单已完成"
			})
		} else if (orderStatus == -1) {
			this.setData({
				orderStatus: "申请退款中"
			})
		} else if (orderStatus == -4) {
			this.setData({
				orderStatus: "商家已同意退款"
			})
		} else if (orderStatus == -7) {
			this.setData({
				orderStatus: "商家取消订单"
			})
		}
	},

	//等待付款倒计时
	countDownFn: function (createTime) {
		var that = this;
		var d3 = util.subTime(createTime, new Date)
		console.log(d3)
		if (d3 >= 900) {
			this.setData({
				countDown: false,
				orderStatus: '订单已失效'
			})
		} else {
			var time = setInterval(function () {
				var sub = 900 - d3
				var min = Math.floor(sub / 60);
				min = min > 9 ? min : '0' + min
				var sec = sub % 60;
				sec = sec > 9 ? sec : '0' + sec
				var t = min + ":" + sec
				that.setData({
					countDown: t
				})
				d3++;
				if (d3 > 900 || sub < 0) {
					that.setData({
						countDown: false,
						orderStatus: '订单已失效'
					})
					clearInterval(time)
				}

			}, 1000)

		}

	},

	//联系商家
	call: function (e) {
		var phone = e.currentTarget.dataset.phone
		wx.makePhoneCall({
			phoneNumber: phone
		})
	},
	//跳转去店铺
	gotoShop: function () {
		var shopId = this.data.order.shopId
		wx.navigateTo({
			url: '../../order?shopId=' + shopId,
		})
	},
	//提交订单购买
	pay: function (e) {
		wx.showNavigationBarLoading()
		var true_pay = this.data.order.realTotalMoney
		var shopName = this.data.order.shopInfo.shopName
		var orderNo = this.data.order.orderNo
		var pay_money = parseInt(true_pay * 100) / 100
		var userId = app.globalData.userId
		var shopId = this.data.order.shopId
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		//查看会员信息，选择支付方式
		var that = this
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Order/payType',
			method: "POST",
			data: {
				userId: userId,
				shopId: shopId,
				true_pay: true_pay,
				orderNo: orderNo,
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
			},
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
				if (res.data.res == 1) {
					if (res.data.type == 2) {//微信支付
						that.payment(pay_money, shopName, orderNo);
					} else {//余额支付
						that.userMoneyPay(true_pay, shopName, orderNo)
					}
				} else if (res.data.res == -1) {
					wx.showModal({
						title: '提示',
						content: '该商品已售罄',
						showCancel: false,
						success: function () {
							wx.navigateBack({ changed: true });
						}
					})
					return false
				} else if (res.data.res == -2) {
					wx.showModal({
						title: '提示',
						content: '该商品已下架',
						showCancel: false,
						success: function () {
							wx.navigateBack({ changed: true });
						}
					})
					return false
				} else {
					that.payment(pay_money, shopName, orderNo);
				}
			}
		})
	},
	//微信付款
	payment: function (true_pay, shopName, orderNo) {
		var that = this
		var oid = app.globalData.usersInfo.openid
		var userId = app.globalData.userId
		var true_pay = true_pay.toFixed(2)
		var p_name = shopName + "外卖订单"
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Order/Wxpay',
			method: 'POST',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				p_name: p_name,
				openid: oid,
				paid_amount: true_pay,
				orderNo: orderNo,
				pid: that.data.pid,
				userId: userId,
				shopId: that.data.order.shopId
			},
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
				if (res.data.res == 'err') {
					wx.showModal({
						title: '提示',
						content: '该商品已售罄',
						showCancel: false,
						success: function () {
						}
					})
					return false
				}

				var deskArr = JSON.stringify(that.data.deskArr)//获取缓存
				wx.requestPayment({
					timeStamp: res.data.timestamp,
					nonceStr: res.data.nonce_str,
					package: res.data.pkg,
					signType: 'MD5',
					paySign: res.data.signc,
					success: function (res) {
						console.log(res)
						//支付成功删除缓存
						wx.removeStorageSync('deskArr')
						wx.showModal({
							title: '提示',
							content: '购买成功，将跳转至阿凡提运动',
							success: function () {
								wx.getSetting({
									success(r) {
										if (!r.authSetting['scope.werun']) {//如果没授权微信运动
											authorization.getSport()
										} else {
											authorization.getSport()
										}
									}
								})
							},
							fail: function () {
								wx.navigateBack()
							}
						})
					},
				})
			}
		})
	},
	//余额支付
	userMoneyPay: function (true_pay, shopName, orderNo) {
		var that = this

		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.showModal({
			title: '提示',
			content: '确定使用余额' + true_pay + '元付款？',
			success: function (res) {
				if (res.confirm) {
					wx.showNavigationBarLoading()
					wx.request({
						url: 'https://www.aftdc.com/wxapp/Desk/updGoods',
						method: "POST",
						data: {
							orderNo: orderNo,
							pid: that.data.pid,
							userId: app.globalData.userId,
							shopId: that.data.shopId,
							sign: sign,
							timestamp: timestamp,
							token: app.globalData.usersInfo.token,
						},
						header: { "Content-Type": "application/x-www-form-urlencoded" },
						success: function (conn) {
							//支付成功删除缓存
							wx.removeStorageSync('deskArr')
							if (conn.data.res == 1) {
								wx.showModal({
									title: '提示',
									content: '购买成功，将跳转至阿凡提运动',
									success: function () {
										wx.getSetting({
											success(r) {
												if (!r.authSetting['scope.werun']) {//如果没授权微信运动
													authorization.getSport()
												} else {
													authorization.getSport()
												}
											}
										})
									},
									fail: function () {
										wx.navigateBack()
									}
								})
							} else if (conn.data.res == 2) {//余额不足
								wx.showToast({
									title: '余额不足',
									icon: 'loading',
									duration: 1000,
									success: function (res) {
										that.onReady()
									}
								})
							}
						}
					})
				}
			}
		})
	},
	toPtkf:function(){
        var that=this
		wx.navigateTo({
            url: '/pages/order/submit/service/service?shopId=' + that.data.order.shopId,
		})
	}
})