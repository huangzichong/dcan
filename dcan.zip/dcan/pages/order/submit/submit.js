var MD5Util = require('../../../utils/md5.js');
var util = require('../../../utils/util.js')
var authorization = require('../../../utils/authorization.js')
var app = getApp();
Page({
	data: {
		yhqId: 0,//优惠券选取使用id
		deskNum: -1,
		showTime: true,
		datacolor: 0,
		gett: -1,
		billShow: true,
		back: false,
		billText: '商家支持开发票 >',
		billId: 0,
		closeFoodIndex: [],
		dsm: 0,
		deskArr: 0,
		isclose: 0,
		array: ["1", "2", "3"],
		storage: { billId: 0, orderRemarks: '', pickNumb: -1, pickTxt: -1 },
		pickNumb: -1, //需要用餐的人数
		pickTxt: -1,
		pick: true,
		remarkNumb: 0,
		remarkBox: true,
		remarkLabel: ["不要辣", "不吃辣", "不需要餐具", "要冰的"],
		orderRemarks: '',
		addressText: '添加收货地址',
		isTostore: 0, //是否支持到店自取
		shareId: 0,
		killId: 0,
		bargainId: 0,
		orderType: 0,
		zkGoodsId: 0,
		isFrist: 0,
		pid: 0,
		storeType: 0,//配送方式，1商家配送 2到店自取 3堂食，无需配送
		submit:'pay', //提交订单按钮的状态 ，空为不能点击

        discount: 0,
        kill: 0,
        bargin: 0,
        discomjunt: 0,
        discount: 0,
        newCou: 0,
        Memberdiscount: 0,
        hongbaoDeduction:0,
        scoreIntoMoney:0,
        useScore:0
	},
	onLoad: function (options) {
		this.orderType(options) //判断订单类型
		if (options.shareId != undefined) {
			this.setData({
				shareId: options.shareId
			})
		}
		if (options.orderNo != undefined) {
			this.setData({
				orderNo: options.orderNo
			})
		}
		this.setData({ pid: options.pid })
		//获得缓存·购买的商品
		var options = options
        var shopInfo = wx.getStorageSync('shopInfo')

		var reserveTime = util.reserveTime(new Date, shopInfo.deliveryCostTime) //当前时间加上商家的配送时间
		var dateN = util.formatTime(new Date)
		var requireTime = dateN + ' ' + reserveTime + ':00' //默认的请求送达时间

		this.setData({
			options: options,
			shopInfo: shopInfo,
			dlvService: shopInfo.dlvService,
			isTostore: shopInfo.isTostore,
			deductions: options.deduction, //优惠金额
			reserveTime: "尽快到达|预计" + reserveTime,
			requireTime: requireTime,
			reTime: reserveTime,
            userPhone: app.globalData.usersInfo.userPhone,       
		})
	},
	//获取用户的信息
	onReady: function () {
		var shopInfo = wx.getStorageSync('shopInfo')
		var shopId = shopInfo.shopId
		var userId = app.globalData.userId
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Desk/userOfshop',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			method: 'POST',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				shopId: shopId,
				userId: userId
			},
			success: function (res) {
				if (res.data.res == 1) {
					that.setData({
						userOfshop: res.data.userOfshop
					})
					var userOfshop = res.data.userOfshop
					if (userOfshop.is_one == 1) {
						that.setData({
							is_one: userOfshop.is_one
						})
					}
					that.calculate()//算出需要支付的价格					
					that.today()		//当前时间
				}
			}
		})
	},
	//算出需要支付的价格
	calculate: function () {
        var couponIndex = wx.getStorageSync('couponIndex')
        var hongbaoIndex = wx.getStorageSync('hongbaoIndex')
        wx.removeStorageSync('couponIndex')
        wx.removeStorageSync('hongbaoIndex')
        if (!couponIndex)
            couponIndex = 0;
        if (!hongbaoIndex)
            hongbaoIndex = 0;
		var orderfood = wx.getStorageSync('orderfood') || []
		var shopInfo = wx.getStorageSync('shopInfo');//店铺信息
        var that = this
		var totalprice = 0;
		var totalnumb = 0;
		var totalmarket = 0;//原价总金额
		var deduction = this.data.deductions  //满减的优惠金额，或其他活动商品的优惠

		var dsm = shopInfo.deliveryStartMoney
		var shopId = shopInfo.shopId
		var userId = app.globalData.userId
		var dfm = shopInfo.deliveryFreeMoney
		var yhq = this.data.userOfshop.yhq //用户优惠券
		var canUseYhq = [] //可用优惠券
        var hongbao = [] //可用红包
		var yhqId = 0 //优惠券id
		var vip = this.data.userOfshop.vip //用户vip和余额信息
		var orderType = this.data.orderType //orderType订单类型 0外卖 2扫码点餐 3订座点餐 4团购单 5自取单
        var discount = 0
        var kill = 0
        var bargin = 0;

		if (orderfood.length <= 0 || orderType == 2 || orderType == 3 || orderType == 5) {//配送费
			dsm = 0
		}
		var boxFees = 0
		for (var i = 0; i < orderfood.length; i++) {//餐盒费
			totalprice = (parseFloat(totalprice) + parseFloat(parseFloat(orderfood[i].shopPrice) * Number(orderfood[i].numb))).toFixed(2);           
			totalnumb = parseFloat(totalnumb) + parseInt(orderfood[i].numb)
			boxFees = parseFloat(boxFees) + parseFloat(Number(orderfood[i].boxFee) * Number(orderfood[i].numb))
			totalmarket = parseFloat(totalmarket) + parseFloat(parseFloat(orderfood[i].marketPrice) * Number(orderfood[i].numb));
            if (orderfood[i].bargainId) { this.data.bargainId = orderfood[i].bargainId; bargin += (orderfood[i].marketPrice - orderfood[i].shopPrice) * orderfood[i].numb}//活动商品 
            if (orderfood[i].zkGoodsId) { this.data.zkGoodsId = orderfood[i].zkGoodsId; discount += (orderfood[i].marketPrice - orderfood[i].shopPrice) * orderfood[i].numb }
            if (orderfood[i].killId) { this.data.bargainId = orderfood[i].killId; kill += (orderfood[i].marketPrice - orderfood[i].shopPrice) * orderfood[i].numb }
		}
        if (discount || kill || bargin)
            this.setData({ mj:0})
        this.setData({ discount: discount.toFixed(2), kill: kill.toFixed(2), bargin: bargin.toFixed(2)})

		if (this.data.zkGoodsId || this.data.bargainId || this.data.killId) {//活动的商品不能使用满减
			var diff = (totalmarket - totalprice).toFixed(2);

		} else {
			var youhui = shopInfo.youhui
			youhui = youhui.replace(/，/g, ',')
			var str = youhui.split(",")
			var lenstr = str.length

			var diff = 0;
			var max = 0;
			for (var i = 0; i < lenstr; i++) {
				var cond = str[i].substring(str[i].indexOf("满") + 1, str[i].indexOf("减"));//满多少钱

                if (totalprice >= parseFloat(cond) && parseFloat(cond) > parseFloat(max)) {
					max = cond
					diff = str[i].substring(str[i].indexOf("减") + 1);//减多少钱
				}
			}
            this.setData({ mj: diff, mjTemp: diff })

		}

		deduction = diff;//满减优惠金额
		var true_pay = totalprice

		if (orderType == 2 || orderType == 3) {
			boxFees = 0
		}

		if (this.data.is_one == 1 && parseFloat(shopInfo.newCou) > 0) {//1为新用户 2为老用户,且店铺有新客立减的活动
			true_pay = parseFloat(totalprice) - parseFloat(shopInfo.newCou)
			deduction = parseFloat(shopInfo.newCou)
			this.setData({
                newCou: deduction,
                mj:0,
				isFrist: 1
			})
		} else {
			if (this.data.zkGoodsId || this.data.bargainId || this.data.killId) {//活动的商品不能使用满减
                true_pay = parseFloat(totalprice)
			} else if (this.data.userOfshop.yhq) {//如果有优惠券          
				for (var i in yhq) {
					if (parseFloat(totalprice) >= parseFloat(yhq[i]['spendMoney'])) {
						canUseYhq[i] = yhq[i]
						deduction = parseFloat(yhq[i]['couponMoney'])                    
						yhqId = yhq[i]['id']
                        that.setData({ 'mj': 0 })  //使用优惠券不支持满减
					}
				}
                if (couponIndex >= 0 && canUseYhq[0]) { //选择优惠券
                    deduction = parseFloat(yhq[couponIndex]['couponMoney'])
                    yhqId = yhq[couponIndex]['id']
                    that.setData({ 'mj': 0, Coupon: deduction})  //使用优惠券不支持满减
                } else if (couponIndex == -1) {//不使用优惠券
					deduction = that.data.mjTemp //满减优惠的金额  
                    that.setData({ 'mj': that.data.mjTemp, Coupon: 0})  //不使用优惠券则支持满减                
					yhqId = 0
				}
                
				true_pay = parseFloat(totalprice) - parseFloat(deduction)
			} else {             
				true_pay = parseFloat(totalprice) - parseFloat(deduction)	
            }
		}
        var hongbaoDeduction = 0;
        var hongbao = this.data.userOfshop.hongbao
        var hongbaoTemp = [];
        var hongbaoId = 0;
        var scoreIntoMoney = 0;
        var useScore = 0;
        if (hongbao) {
            for (var i in hongbao) {
                hongbaoTemp[i] = hongbao[i]
                hongbaoDeduction = parseFloat(hongbaoTemp[i]['money'])
                hongbaoId = hongbao[i]['hongBaoId']
            }
            if (hongbaoIndex >= 0) { //选择红包
                hongbaoDeduction = parseFloat(hongbao[hongbaoIndex]['money'])
                hongbaoId = hongbao[hongbaoIndex]['hongBaoId']

            } else if (hongbaoIndex == -1) {//不使用红包
                hongbaoDeduction = 0            
                hongbaoId = 0
            }
            this.setData({'hongbaoDeduction':hongbaoDeduction})
            this.setData({ 'hongbaoId': hongbaoId })
            true_pay = true_pay - parseFloat(hongbaoDeduction)

        }
        if(vip.scoreIntoMoney)
        {
            true_pay = parseFloat(true_pay - vip.scoreIntoMoney).toFixed(2)
            scoreIntoMoney = vip.scoreIntoMoney
        }


		if (vip.zk) {//如果是店铺会员，进行打折
			var vipZk = parseFloat(vip.zk) / 10
            var Memberdiscount = true_pay - (true_pay * vipZk)
            this.setData({ Memberdiscount: Memberdiscount}) //会员折扣
			true_pay = parseFloat(true_pay * vipZk).toFixed(2)

		} else {
			var vipZk = 0
		}
		if (parseFloat(true_pay) < 0) { true_pay = 0 }
		var true_pay = parseFloat(parseFloat(true_pay) + Number(dsm) + Number(boxFees)).toFixed(2) //付款总和
		if (parseFloat(totalprice) >= dfm||this.data.orderType==3) {
			var payYes = true
		} else {
			var payYes = false
		}
		this.setData({
            scoreIntoMoney:scoreIntoMoney,
			orderfood: orderfood,
			boxFees: boxFees,
			totalprice: totalprice,
			totalnumb: totalnumb,
			deduction: deduction,
			shopId: shopId,
			shopName: shopInfo.shopName,
			dsm: dsm,
			newTip: "",
			payYes: payYes,
			true_pay: true_pay,
			canUseYhq: canUseYhq,
            hongbaoTemp: hongbaoTemp,
			yhqId: yhqId,
            hongbaoId: hongbaoId,
			vipZk: vipZk,
            useScore:vip.useScore
		})
	},
	//订单类型和配送方式
	orderType: function (options) {
		if (options.orderType) {//拼单，订单 页面进来
			wx.setStorageSync('orderType', options.orderType)
			this.setData({
				orderType: orderType
			})
		} else {//从首页一路进来
			var orderType = wx.getStorageSync('orderType')
			this.setData({
				orderType: orderType
			})
		}
		if (orderType == 0) {//外卖
			this.setData({
				storeType: 1
			})
		} else if (orderType == 2) {//扫码堂食
			this.setData({
				storeType: 3,
				deskNum: options.deskNum,
				deskName: options.deskName
			})
		} else if (orderType == 3) {//堂食预订
			var deskArr = wx.getStorageSync('deskArr')
			this.setData({
				storeType: 3,
				deskArr: deskArr,
			})
		} else if (orderType == 5) {//到店
			this.setData({
				storeType: 2
			})
		}
	},
	//选择送达时间
	instant: function (e) {
		var time = e.currentTarget.dataset.str
		this.setData({
			requireTime: this.data.today + " " + time,
			showTime: true,
			reserveTime: this.data.today + " " + time,
		})
	},
	comTime: function (e) {
		var index = e.currentTarget.dataset.number
		var time = e.currentTarget.dataset.time
		this.setData({
			showTime: true,
			requireTime: this.data.today + " " + time,
			reserveTime: this.data.today + " " + time,
			gett: index
		})
	},
	today: function () {
		var dateN = util.formatTime(new Date)
		var addTime = this.data.reTime
		var shopInfo = wx.getStorageSync('shopInfo')
		//获取可选预计的时间
		var timearr = [];
		for (var i = 0; i < 50; i++) {
			var datestr = util.formateIOS(dateN + ' ' + addTime + ":00")
			var addTime = util.addMinutes(datestr, 15)
			if (datestr < util.formateIOS(dateN + ' ' + shopInfo.serviceEndTime + ":00")) {
				timearr.push(addTime)
			}
			else {
				break;
			}
		}
		timearr.pop()
		this.setData({
			timearr: timearr,
			today: dateN,
			datacolor: 0
		})
	},
	toTime: function (e) {
		var days = e.currentTarget.dataset.id
		var dateN = util.formatTime(new Date)
		var shopInfo = wx.getStorageSync('shopInfo')
		var addTime = shopInfo.serviceStartTime
		//获取可选预计的时间
		var timearr = [];
		for (var i = 0; i < 50; i++) {
			var datestr = util.formateIOS(dateN + ' ' + addTime + ":00")
			var addTime = util.addMinutes(datestr, 30)
			if (datestr >= util.formateIOS(dateN + ' ' + shopInfo.serviceEndTime + ":00")) {
				break;
			}
			else {
				timearr.push(addTime)
			}
		}
		var datestr = util.formateIOS(dateN + ' ' + "00:00:00")
		var today = util.addDay(datestr, days)
		timearr.pop()
		this.setData({
			timearr: timearr,
			today: today,
			datacolor: days
		})
	},
	selTime: function () {
		this.setData({
			showTime: false
		})
	},
	quxiao: function () {
		var that = this
		that.setData({
			showTime: true
		})
	},
	goon: function () {
		this.setData({
			isclose: 0
		})
	},

	//提交订单购买
	pay: function (e) {
		this.setData({//标志按下提交订单
			submit: ''
		})
        var that = this
        var orderfood = wx.getStorageSync('orderfood')
        orderfood = JSON.stringify(orderfood)
        if (app.globalData.userId) {
            wx.request({
                url: 'https://www.aftdc.com/wxapp/Shop/putInHistory',
                data: {
                    // sign: sign,
                    // timestamp: timestamp,
                    // token: app.globalData.usersInfo.token,
                    shopId: that.data.shopId,
                    userId: app.globalData.userId,
                    action: 2,
                    goodsId: orderfood
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function (res) {

                }
            })
        }

		wx.showNavigationBarLoading()
		if (this.data.orderNo) {//如果有单号，直接付款
			var true_pay = this.data.true_pay
			var shopName = this.data.shopInfo.shopName
			var orderNo = this.data.orderNo
			var pay_money = parseInt(true_pay * 100) / 100
			this.payment(pay_money, shopName, orderNo)
		} else { //添加数据到后台
			this.addGoods(e)
		}
	},
	//添加数据到后台
	addGoods: function (e) {
		var that = this
		var deskArr = wx.getStorageSync('deskArr') || []
		if (!that.data.address && that.data.storeType == 1 && that.data.orderType == 0) {
			wx.showToast({
				title: '请选择收货地址',
				icon: 'loading',
				duration: 1000
			})
			return false;
		}
		if (that.data.orderType == 3) {
			var userName = that.data.deskArr.inputName
			var userPhone = that.data.deskArr.inputPhone
			var address = '堂内'
			var lat = 0
			var lng = 0
		} else if (that.data.orderType == 2) {
			var userName = app.globalData.usersInfo.userName
			var userPhone = app.globalData.usersInfo.userPhone
			var address = that.data.deskNum + '号桌'
			var lat = 0
			var lng = 0
		} else if (that.data.orderType == 5) {
			var userName = app.globalData.usersInfo.userName
			var userPhone = app.globalData.usersInfo.userPhone
			var address = '到店自取'
			var lat = 0
			var lng = 0
		} else {
			var userName = that.data.address.userName
			var userPhone = that.data.address.userPhone
			var address = that.data.address.address
			var lat = that.data.address.latitude
			var lng = that.data.address.longitude
		}
		if (!userPhone) {
			wx.showToast({
				title: '请设置手机号',
				icon: 'loading',
				duration: 1000,
			})
			return false
		}
		var payYes = that.data.payYes
		if (!payYes) {
			wx.showToast({
				title: '购买金额不够',
				icon: 'loading',
				duration: 1000,
			})
			return false
		}
		var yhqId = that.data.yhqId
        var hongbaoId = that.data.hongbaoId
        var hongbaoDeduction = that.data.hongbaoDeduction
		var true_pay = that.data.true_pay
		var shopName = that.data.shopInfo.shopName
		var totalprice = that.data.totalprice
		var orderfood = JSON.stringify(that.data.orderfood)
		var shopId = that.data.shopId
		var userId = app.globalData.userId
		var deduction = that.data.deduction
		var orderRemarks = that.data.orderRemarks
		var fromId = e.detail.formId;
		var orderType = that.data.orderType
		var requireTime = that.data.requireTime;//送达时间
		var billId = that.data.billId //发票Id
		var deskArr = JSON.stringify(that.data.deskArr)
        var scoreIntoMoney = that.data.scoreIntoMoney
		if (orderType == 0) {
			var deskNum = -1
		} else {
			var deskNum = that.data.deskNum
		}
		var openid = app.globalData.usersInfo.openid
		var pay_money = parseInt(true_pay * 100) / 100
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Desk/addGoods',
			method: "POST",
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
        kill: that.data.kill,
        bargin: that.data.bargin ,
        mj: that.data.mj,
        discount: that.data.discount,
        newCou: that.data.newCou,
        Memberdiscount: that.data.Memberdiscount,
        Coupon: that.data.Coupon,
        redpacketId:hongbaoId,
        redbag:hongbaoDeduction,
				true_pay: true_pay,
				orderfood: orderfood,
				userName: userName,
				userPhone: userPhone,
				address: address,
				shopId: shopId,
				userId: userId,
				totalprice: totalprice,
				pay_money: pay_money,
				yhqId: yhqId,
				deduction: deduction,
				dsm: that.data.dsm,
				orderRemarks: orderRemarks,
				orderType: orderType,
				deskNum: deskNum,
				requireTime: requireTime,
				billId: billId,
				lat: lat,
				lng: lng,
				fromId: fromId,
				deskArr: deskArr,
				shareId: that.data.shareId,
				killId: that.data.killId,
				bargainId: that.data.bargainId,
				zkGoodsId: that.data.zkGoodsId,
				isFrist: that.data.isFrist,
				boxFee: that.data.boxFees,
				vipZk: that.data.vipZk * 10,
                scoreIntoMoney:scoreIntoMoney,
                useScore: that.data.useScore
			},
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
				if (res.data.isUse == 0) {
					wx.showToast({
						title: '你的账号已被封停！无法进行该操作',
						icon: 'loading'
					})
					return false
				}
				if (res.data.isOnload == 1) {
					wx.showToast({
						title: '优惠券被占用',
						icon: 'loading'
					})
					wx.navigateBack()
					return false;
				}
				if (res.data == 3) {
					wx.showToast({
						title: '不在配送范围',
						icon: 'loading',
						duration: 1500
					})
				}

				if (res.data.res == -1) {
					wx.showToast({
						title: '该商品已售罄',
						icon: 'loading',
						duration: 1500
					})
					return false
				}
				if (res.data.res == -2) {
					wx.showToast({
						title: '该商品已下架',
						icon: 'loading',
						duration: 1500
					})
					return false
				}
				var orderNo = res.data.orderNo
				var orderId = res.data.orderId
				that.data.orderNo = orderNo
				that.data.orderId = orderId
				if (res.data.type == 2) {//微信支付
					that.payment(pay_money, shopName, orderNo);
				} else {//余额支付
					that.userMoneyPay(true_pay, shopName, orderNo)
				}
			}
		})
	},
	//微信付款
	payment: function (true_pay, shopName, orderNo) {
		var that = this
		var oid = app.globalData.usersInfo.openid
		var userId = app.globalData.userId
		var true_pay = true_pay.toFixed(2)
		var p_name = shopName + "外卖订单"
		var shopInfo = wx.getStorageSync('shopInfo')
		var shopId = shopInfo.shopId

    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Order/Wxpay',
			method: 'POST',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				p_name: p_name,
				openid: oid,
				paid_amount: true_pay,
				orderNo: orderNo,
				pid: that.data.pid,
				userId: userId,
				shopId: shopId
			},
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
				if (res.data.res == -1) {
					wx.showModal({
						title: '提示',
						content: '该商品已售罄',
						showCancel: false,
						success: function () {
							wx.navigateBack()
						}
					})
					return false
				}
				if (res.data.res == -2) {
					wx.showModal({
						title: '提示',
						content: '该商品已下架',
						showCancel: false,
						success: function () {
							wx.navigateBack()
						}
					})
					return false
				}


				var deskArr = JSON.stringify(that.data.deskArr)//获取缓存
				wx.requestPayment({
					timeStamp: res.data.timestamp,
					nonceStr: res.data.nonce_str,
					package: res.data.pkg,
					signType: 'MD5',
					paySign: res.data.signc,
					success: function (res) {
						//支付成功删除缓存
						wx.removeStorageSync('deskArr')
						wx.showModal({
							title: '提示',
							content: '购买成功',
							showCancel:false,
							success:function(){
								wx.getSetting({
									success(r) {
										if (!r.authSetting['scope.werun']) {//如果没授权微信运动
											authorization.getSport()
										} else {
											authorization.getSport()
										}
									}
								})
							}
						})
					},
					fail: function (res) {
						wx.redirectTo({
							url: './waitPay/waitPay?orderId=' + that.data.orderId + '&tk=0&pid=' + that.data.pid,
						})
					}
				})
			}
		})
	},
	//余额支付
	userMoneyPay: function (true_pay, shopName, orderNo) {
		var that = this
		var userId = app.globalData.userId


		wx.showModal({
			title: '提示',
			content: '确定使用余额' + true_pay + '元付款？',
			success: function (res) {
				if (res.confirm) {
                    var timestamp = (Date.parse(new Date())) / 1000
                    var sign = MD5Util.sign(timestamp)
					wx.showNavigationBarLoading()
					wx.request({
            url: 'https://www.aftdc.com/wxapp/Desk/updGoods',
						method: "POST",
						data: {
              sign: sign,
              timestamp: timestamp,
              token: app.globalData.usersInfo.token,
							orderNo: orderNo,
							pid: that.data.pid,
							userId: userId,
							shopId: that.data.shopInfo.shopId
						},
						header: { "Content-Type": "application/x-www-form-urlencoded" },
						success: function (conn) {
							//支付成功删除缓存
							wx.removeStorageSync('deskArr')
							if (conn.data.res == 1) {
								wx.showModal({
									title: '提示',
									content: '购买成功',
									showCancel: false,
									success: function () {
										wx.getSetting({
											success(r) {
												if (!r.authSetting['scope.werun']) {//如果没授权微信运动
													authorization.getSport()
												} else {
													authorization.getSport()
												}
											}
										})
									}
								})
							} else if (conn.data.res == 2) {//余额不足
								that.setData({//标志按下提交订单
									submit: 'pay'
								})
								wx.showModal({
									title: '提示',
									content: '余额不足',
									showCancel: false,
									success: function () {
										that.onReady()
									}
								})
							}
						}
					})
				} else {
					wx.redirectTo({
						url: './waitPay/waitPay?orderId=' + that.data.orderId + '&tk=0&pid=' + that.data.pid,
					})
				}
			}
		})
	},
	//备注的内容
	bindblur: function (e) {
		var orderRemarks = e.detail.value;
		var that = this
		that.setData({
			orderRemarks: orderRemarks
		})
	},
	//选择地址
	checkaddr: function () {
		wx.navigateTo({
			url: '../../personal/address/address?shopId=' + this.data.shopInfo.shopId,
		})
	},
	//弹出优惠券选择框
	docoupon: function (e) {
		this.setData({
			couponshow: true,
		})
	},

    //弹出红包选择框
    dohongbao: function (e) {
        this.setData({
            hongbaoshow: true,
        })
    },
	//不使用优惠券
	closeYhq: function () {
		var index = -1
        wx.setStorageSync('couponIndex', index)
		this.calculate()
		this.setData({
			couponshow: false,
		})
	},
    //不使用红包
    closeHongbao: function () {
        var index = -1
        wx.setStorageSync('hongbaoIndex', index)
        this.calculate()
        this.setData({
            hongbaoshow: false,
        })
    },
	//选择优惠券
	couponChoice: function (e) {
		var index = e.currentTarget.dataset.index
        wx.setStorageSync('couponIndex', index)
		this.calculate()
		this.setData({
			couponshow: false,
		})
	},
    //选择红包
    hongbaoChoice: function (e) {
        var index = e.currentTarget.dataset.index
        wx.setStorageSync('hongbaoIndex', index)
        this.calculate()
        this.setData({
            hongbaoshow: false,
        })
    },
	//选择发票
	gotoInvoice: function () {
		var userId = app.globalData.userId
		wx.navigateTo({
			url: '../../personal/invoice/invoice?userId=' + userId,
		})
	},

	//继续购买   返回上一页
	shopContinue: function (e) {
		if (this.data.orderType==3){
			wx.navigateBack({
				delta: 2
			})
		}else{
			wx.navigateBack({
				delta: 1
			})
		}
	},
	againContinue: function (e) {
		var shopId = this.data.shopId
		var orderfood = this.data.orderfood
		if (orderfood) {
			if (orderfood.length > 0) {
				var foodAdd = []
				for (var i in orderfood) {
					var obj = { goodsId: orderfood[i].goodsId, numb: orderfood[i].numb }
					foodAdd.push(obj)
				}
				wx.setStorageSync('foodAdd', foodAdd)
			}
		}
		wx.redirectTo({
			url: '../order?shopId=' + shopId
		})
	},
	//删除商品
	closeFood: function (e) {
		var index = e.currentTarget.dataset.index
		var orderfood = this.data.orderfood
		var closeFoodIndex = this.data.closeFoodIndex
		closeFoodIndex.push(orderfood[index].goodsId)
		wx.setStorageSync('closeFoodIndex', closeFoodIndex)
		orderfood.splice(index, 1)
		wx.setStorageSync('orderfood', orderfood)

		this.calculate()
		this.setData({
			orderfood: orderfood,
			closeFoodIndex: closeFoodIndex,
		})
	},

	onShow: function () {
		// var submit = this.data.submit
		// if (!submit){//已下单则返回上一次
		// 	wx.navigateBack()
		// }
		var address = wx.getStorageSync('address')
		this.setData({
			billShow: true,
			back: false,
			tipss: 0,
			address: address,
		})
	},
	pickshow: function () {
		var pick = !this.data.pick
		this.setData({
			pick: pick,
			showTime: true,
		})
	},
	picks: function (e) {
		var numb = e.currentTarget.dataset.numb
		var pickTxt
		if (numb == 0) {
			pickTxt = numb + "(不需要餐具)"
		} else {
			pickTxt = numb + "人 "
		}
		this.setData({
			pick: true,
			pickTxt: pickTxt,
			pickNumb: numb,
		})
	},

	bindtext: function (e) {
		var val = e.detail.value;
		if (val.length >= 50) {
			wx.showToast({
				title: '最大长度为50',
				icon: 'loading',
				duration: 1200,
			})
		}
		this.setData({
			remarkNumb: val.length,
			orderRemarks: val
		})
	},
	//打开和确定备注发票框
	invoiceRemark: function (e) {
		var remarkBox = !this.data.remarkBox
		var storage = this.data.storage
		var billId = app.globalData.billId
		if (billId) {
			this.data.billId = billId
		} else {
			storage.billId = this.data.billId
		}
		storage.orderRemarks = this.data.orderRemarks
		storage.pickNumb = this.data.pickNumb
		storage.pickTxt = this.data.pickTxt

		this.setData({
			remarkBox: remarkBox,
			storage: storage,
		})
	},

	remarkLabelItem: function (e) {
		var index = e.currentTarget.dataset.index
		var remarkLabel = this.data.remarkLabel
		var orderRemarks = this.data.orderRemarks //备注框内容 
		var val = orderRemarks + remarkLabel[index]

		if (val.length >= 50) {
			wx.showToast({
				title: '最大长度为50',
				icon: 'loading',
				duration: 1200,
			})
			val.length = 50;
		}
		this.setData({
			orderRemarks: val,
			remarkNumb: val.length,
		})
	},
	//返回就不获取数据
	remarkBack: function () {
		var storage = this.data.storage
		this.setData({
			billId: storage.billId,
			orderRemarks: storage.orderRemarks,
			pickNumb: storage.pickNumb, //需要用餐的人数
			pickTxt: storage.pickTxt,
			remarkBox: true,
		})
	},
	//点击配送方式
	takeout: function (e) {//点击外卖配送
		var storeType = e.currentTarget.dataset.storetype
		if (storeType == 1) {//点击外卖配送
			this.setData({
				storeType: 1,
				orderType: 0
			})
		} else {//到店自取
			this.setData({
				storeType: 2,
				orderType: 5
			})
		}
		this.calculate()
	},
	//获取手机号
	getPhoneNumber: function (e) {
		authorization.getPhone(e)
		var userPhone = app.globalData.usersInfo.userPhone
		if (userPhone) {
			this.setData({
				userPhone: userPhone
			})
		} else {
			return this.setPhone()
		}
	},
	setPhone: function () {
		var userPhone = app.globalData.usersInfo.userPhone
		if (userPhone) {
			this.setData({
				userPhone: userPhone
			})
		} else {
			var that = this
			setTimeout(function () {
				return that.setPhone()
			}, 200)
		}
	}

})
