var app = getApp();
var MD5Util = require('../../../utils/md5.js');
Page({

  data: {
    isShare:1,
		onshow:false
  },

  onLoad: function (options) {
		this.data.shopId = options.shopId
		this.data.shareId = options.shareId
		this.setData({
			userId: app.globalData.userId
		})
  },
	onShow:function(){
		if (this.data.onshow){
			this.onPullDownRefresh()
		}
	},
  onReady:function(){
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Shop/addWxFriend',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				shareId: that.data.shareId,
				userId: app.globalData.userId,
				name: app.globalData.usersInfo.userName,
				shopId: that.data.shopId
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					that.setData({
						shareOrder: res.data.shareOrder,
						friendName: res.data.friendName,
						shop: res.data.shop,
						num: res.data.num,
						id: res.data.id,
						onshow:true,
						payStatus: res.data.payStatus						
					})
				}else{
					that.setData({
						isShare:0,
						payStatus: res.data.payStatus
					})
				}
			}
		})
  },
	//不拼了
  noShare: function () {
    var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
    wx.showModal({
      title: '提示',
      content: '确定要推出该拼单吗',
      success: function (res) {
        if (res.confirm) {
					wx.request({
            url: 'https://www.aftdc.com/wxapp/Shop/delFriend',
						data: {
              sign: sign,
              timestamp: timestamp,
              token: app.globalData.usersInfo.token,
							id: that.data.id
						},
						header: {
							"Content-Type": "application/x-www-form-urlencoded"
						},
						method: 'post',
						success: function (res) {
							if (res.data.res == 1) {
								wx.navigateBack({
									delta: 1
								})
							}
						}
					})
        }
      }
    })
  },
	//和他一样
	sameFood:function(e){
		var friendId = e.currentTarget.dataset.friendid;
		var id = this.data.id
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Shop/sameFood',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				shareId: that.data.shareId,
				friendId: friendId,
				id: id
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					that.onPullDownRefresh()
				}
			}
		})
	},
	//去店铺选购
	addGoods: function () {
		wx.navigateTo({
			url: '../order?shopId=' + this.data.shopId + '&id=' + this.data.id
		})
	},
	//下拉刷新
	onPullDownRefresh: function () {
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Shop/getShare',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				shareId: that.data.shareId
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: 'post',
			success: function (res) {
				if (res.data.res == 1) {
					that.setData({
						shareOrder: res.data.shareOrder,
						num: res.data.num,
						payStatus: res.data.payStatus
					})
				}
				wx.hideNavigationBarLoading() //完成停止加载
				wx.stopPullDownRefresh() //停止下拉刷新
			}
		})
	}
})