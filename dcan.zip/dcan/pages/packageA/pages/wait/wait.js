var app = getApp();
var MD5Util = require('../../../../utils/md5.js');
// pages/league/wait/wait.js
Page({

	data: {
		choice: 0,// 0为未填写，1为已填写
		two: 0,// 0为未填写，1为已填写
		three: 0,// 0为未填写，1为已填写
		disabled: '',//点击注销
		hidden: '',//点击支付
		flag: true,//设置密码
		password: '',//设置密码按钮
		pwdone: '',//设置密码
		pwdtwo: '',//确定密码
		shopId: '',//用户的shopId
		popup: true,//注销弹出
		cause: '',//内容
		activate: '',//激活店铺
		phone: '',//上一页填写跳转的号码
	},


	onLoad: function (options) {
		var phone = options.phone;//上一页填写跳转的号码
		this.setData({
			phone: phone,
		})
		var phone = this.data.phone;
		// var userId = app.globalData.userId;
		var that = this;
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: "https://www.aftdc.com/wxapp/Service/enrol_state",
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				phone: phone,
			},
			header: {
				'content-type': 'application/json',
			},
			success: function (res) {
				var all = res.data.data;
				console.log(res.data)
				if (all.shopStatus == 0 || all.shopStatus == 2 || all.shopStatus == 3) {
					var disabled = '';
				}
				if (all.shopStatus == -2) {
					var disabled = 'true';
				}
				if (all.shopStatus == -1) {
					var userId = app.globalData.userId;
					var one = '拒接入驻';
					var three = '注销重试';
					wx.request({
						url: 'https://www.aftdc.com/wxapp/Service/check_tuisong',
						data: {
							timestamp: timestamp,
							token: app.globalData.usersInfo.token,
							sign: sign,
							userId: userId,
							one: one,
							three: three,
						},
						method: 'post',
						header: {
							'content-type': 'application/json',
						},
						success: function (res) {
							console.log(res)
						}
					})
				}
				if (all.shopStatus == 2) {
					var userId = app.globalData.userId;
					var one = '待付款';
					var three = '修改密码';
					wx.request({
						url: 'https://www.aftdc.com/wxapp/Service/check_tuisong',
						data: {
							timestamp: timestamp,
							token: app.globalData.usersInfo.token,
							sign: sign,
							userId: userId,
							one: one,
							three: three,
						},
						method: 'post',
						header: {
							'content-type': 'application/json',
						},
						success: function (res) {
							console.log(res)
						}
					})
				}
				that.setData({
					info: all,
					choice: res.data.shop_message.res,
					two: res.data.oneself_message.res,
					three: res.data.distribution.res,
					// flag: flag,
					shopId: all.shopId,
					disabled: disabled,
				})
				//.....
				if (all.shopStatus == 3) {
					var userId = app.globalData.userId;
					var one = '设置密码';
					var three = '查看';
					wx.request({
						url: 'https://www.aftdc.com/wxapp/Service/check_tuisong',
						data: {
							timestamp: timestamp,
							token: app.globalData.usersInfo.token,
							sign: sign,
							userId: userId,
							one: one,
							three: three,
						},
						method: 'post',
						header: {
							'content-type': 'application/json',
						},
						success: function (res) {
							console.log(res)
						}
					})
					that.infoFn();
				}
			}
		})
	},
	//支付完成后执行该方法
	infoFn: function () {
		var phone = this.data.phone;//手机号码
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: "https://www.aftdc.com/wxapp/Service/enrol_payment",
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				phone: phone,
			},
			header: {
				'content-type': 'application/json',
			},
			success: function (rest) {
				console.log(rest)
			}
		})
	},

	// 下拉加载
	onPullDownRefresh: function (e) {
		var phone = this.data.phone;
		var opa = { phone: phone }
		this.onLoad(opa);
		wx.hideNavigationBarLoading() //完成停止加载
		wx.stopPullDownRefresh()
	},
	//退款
	refund: function (e) {
		this.setData({
			disabled: "true",//点一次就不能在点了
		})
		var that = this;
		var applyMoney = that.data.info.applyMoney;//当前该店铺的注册金额
		var shopId = that.data.info.shopId;//当前该店铺的shopId
		var cause = that.data.cause;//注销原因
		var tranId = that.data.info.tranId;//当前该店铺的支付订单
		var timeend = Date.parse(new Date());//注销时间
		var createTime = that.data.info.createTime;//当前该店铺的修改时间
		var shopName = that.data.info.shopName;//当前该店铺的店铺名称
		wx.showModal({
			title: '提示',
			content: '确定要删除吗？',
			success: function (sm) {
				if (sm.confirm) {
					var timestamp = (Date.parse(new Date())) / 1000
					var sign = MD5Util.sign(timestamp)
					wx.request({
						url: 'https://www.aftdc.com/wxapp/Service/enrol_cancel',
						data: {
							sign: sign,
							timestamp: timestamp,
							token: app.globalData.usersInfo.token,
							cause: cause,
							applyMoney: applyMoney,
							shopId: shopId,
							tranId: tranId,
							timeend: timeend,
							createTime: createTime,
							shopName: shopName,
						},
						method: 'post',
						header: { "Content-Type": "application/x-www-form-urlencoded" },
						success: function (res) {
							var data = res.data;
							console.log(data)
							if (data.apply_shop == 'apply_shop表修改成功') {
								wx.showToast({
									title: data.info,
									icon: '12',
									duration: 1500,
									success: setTimeout(function () {
										that.setData({
											popup: true,
										})
										var phone = that.data.phone;
										var opa = { phone: phone }
										that.onLoad(opa)
									}, 1500)
								})
							} else {
								wx.showToast({
									title: data.info,
									icon: '12',
									duration: 1500,
									success: setTimeout(function () {
										that.setData({
											popup: true,
										})
										var phone = that.data.phone;
										var opa = { phone: phone }
										that.onLoad(opa)
									}, 1500)
								})
							}
						}
					})
				} else if (sm.cancel) {
					wx.showToast({
						title: '谨慎选择',
						icon: '12',
						duration: 1000,
						success: setTimeout(function () {
							that.setData({
								disabled: false,//点一次就不能在点了
							})
						}, 1500)
					})
				}
			}
		})
	},
	//出现
	show: function () {
		var that = this
		wx.showModal({
			title: '提示',
			content: '要注销店铺吗',
			success: function (q) {
				if (q.confirm) {
					wx.showToast({
						title: '说明原因',
						icon: '12',
						duration: 1000,
						success: setTimeout(function () {
							that.setData({ popup: false })
						}, 1500)
					})
				}
			}
		})
	},
	//内容
	cause: function (e) {
		var val = e.detail.value;
		this.setData({
			cause: val
		})
	},
	//确定退款
	formcause: function (e) {
		var cause = this.data.cause;
		var that = this;
		if (cause) {
			that.refund()
		} else {
			wx.showToast({
				title: '请说明原因',
				icon: 'loading',
				duration: 1200
			})
			return false;
		}
	},
	//支付
	formnextBut: function (e) {
		var formId = e.detail.formId;
		this.setData({
			hidden: 'true',
		})
		var choice = this.data.choice;// 0为未填写，1为已填写
		var two = this.data.two;// 0为未填写，1为已填写
		var three = this.data.three;// 0为未填写，1为已填写
		var info = this.data.info;//当前该店铺所有数据

		if (choice == 0 || two == 0 || three == 0) {
			wx.showToast({
				title: '请把信息填写完整',
				icon: 'loading',
				duration: 1200
			})
			return false
		}
		var that = this
		var oid = app.globalData.usersInfo.openid;
		var phone = that.data.phone;
		var true_pay = info.applyMoney;
		var shopId = info.shopId;
		var p_name = '阿凡提点餐商家入驻费用';
		wx.showModal({
			title: '提示',
			content: '确定要支付吗？',
			success: function (re) {
				if (re.confirm) {
					var timestamp = (Date.parse(new Date())) / 1000
					var sign = MD5Util.sign(timestamp)
					wx.request({
						url: 'https://www.aftdc.com/wxapp/Service/enrol_money',
						method: 'POST',
						data: {
							sign: sign,
							timestamp: timestamp,
							token: app.globalData.usersInfo.token,
							p_name: p_name,
							openid: oid,
							paid_amount: true_pay,
							shopId: shopId
						},
						header: { "Content-Type": "application/x-www-form-urlencoded" },
						success: function (res) {
							console.log(res)
							// console.log(paySign);
							wx.requestPayment({
								timeStamp: res.data.timestamp,
								nonceStr: res.data.nonce_str,
								package: res.data.pkg,
								signType: 'MD5',
								paySign: res.data.signc,
								success: function (res) {
									that.formId(formId)
									// console.log(res)
									var userId = app.globalData.userId
									wx.showToast({
										title: '支付成功,等待管理员最后审核',
										icon: '12',
										duration: 1500,
										success: setTimeout(function () {
											// that.onLoad()
											wx.navigateTo({
												url: '../wait/wait?phone=' + phone,
											})
										}, 1500)
									})
								}
							})
						}
					})
				} else if (re.cancel) {
					wx.showToast({
						title: '谨慎选择',
						icon: '12',
						duration: 1000,
						success: setTimeout(function () {
							that.setData({
								hidden: false,//点一次就不能在点了
							})
						}, 1500)
					})
				}
			}
		})
	},
	formId: function (formId) {
		var that = this;
		var userId = app.globalData.userId;
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Service/formId',
			method: 'post',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			data: {
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				sign: sign,
				formId: formId,
				userId: userId,
			},
			success: function (res) {
				console.log(res)
				that.submitBut();
			}
		})
	},
	password: function (e) {
		this.setData({
			flag: false,//点一次就不能在点了
		})
	},
	// 保存密码
	detaone: function (e) {
		var val = e.detail.value;
		this.setData({
			pwdone: val
		})
	},
	detatwo: function (e) {
		var val = e.detail.value;
		this.setData({
			pwdtwo: val
		})
	},
	formSubmit: function (e) {
		// var formData = e.detail.value;//-------------------提交表单数据
		var pwdone = this.data.pwdone;
		var pwdtwo = this.data.pwdtwo;
		var phone = this.data.phone;
		var that = this;
		if (!/^[a-zA-Z][a-zA-Z0-9_]{5,15}$/.test(pwdtwo)) {
			wx.showToast({
				title: '密码不安全',
				icon: 'loading',
				duration: 2100
			});
			return false
		}
		if (pwdone == '' || pwdtwo == '') {
			wx.showToast({
				title: '请填写密码',
				icon: 'loading',
				duration: 2100
			});
			return false
		}
		if (pwdone != pwdtwo) {
			wx.showToast({
				title: '两次密码不一致',
				icon: 'loading',
				duration: 2100
			});
			return false
		}
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Service/enrol_password',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				login_password: pwdtwo,
				phone: phone
			},
			method: 'post',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (data) {
				if (data.data.res == 1) {
					wx.showToast({
						title: "保存成功",
						mask: true,
						icon: 'loading',
						success: setTimeout(function () {
							wx.switchTab({
								url: '../../../index/index',
							})
						}, 1000)
					})
				} else {
					wx.showToast({
						title: '设置密码失败',
						icon: 'loading',
						duration: 2100
					});
				}
			}
		})
	},
	//删除门店
	activate: function (e) {
		var that = this;
		var shopId = this.data.shopId;
		var phone = this.data.phone;
		that.setData({
			activate: 'true',
		})
		wx.showModal({
			title: '提示',
			content: '确定要删除吗？',
			success: function (ac) {
				if (ac.confirm) {
					var timestamp = (Date.parse(new Date())) / 1000
					var sign = MD5Util.sign(timestamp)
					wx.request({
						url: 'https://www.aftdc.com/wxapp/Service/enrol_delete',
						data: {
							sign: sign,
							timestamp: timestamp,
							token: app.globalData.usersInfo.token,
							shopId: shopId,
							phone: phone
						},
						method: 'post',
						header: { "Content-Type": "application/x-www-form-urlencoded" },
						success: function (act) {
							if (act.data.res == 1) {
								wx.switchTab({
									url: '/pages/personal/personal',
								})
							} else {
								wx.showToast({
									title: '删除失败',
									icon: 'loading',
									duration: 1000
								});
								that.setData({
									activate: false,
								})
							}
						}
					})
				} else if (ac.cancel) {
					that.setData({
						activate: false,
					})
				}
			}
		})
	}
})