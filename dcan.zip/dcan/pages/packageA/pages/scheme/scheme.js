var app = getApp();
var MD5Util = require('../../../../utils/md5.js');
Page({

	data: {
		serveData: ['顾客在线支付', '在线结算', '享受优质商家排名', '专享活动'],
		choice: 0,//配送选择 1为商家配送，2为阿凡提配送

		choiceTxt: [
			{
				name: '商家配送', per: '收取提现手续费0.06%',
				//  { name: '商家配送', per: '堂食、外卖每单收取3%服务费', 
				//    shili: ['假设今日在线支付营业额4000元', '应收服务费4000*3.00%=120.00元']
				shili: ['假设今日在线支付营业额4000元', '应收手续费为4000*0.06%=2.4元']
			},
			//  {
			//    name: '阿凡提配送', per: '堂食每单收取3%服务费，外卖每单收取13%服务费',
			//    shili: ['假设今日堂食支付营业额4000元', '应收服务费4000*3.00%=120.00元',
			//           '假设今日外卖支付营业额3000元', '应收服务费4000*13.00%=90.00元'
			//    ]
			//  }
		],
		modealTxt: {},
		togle: false,
		phone: '',
	},


	onLoad: function (options) {
		var phone = options.phone;//上一页填写跳转的号码
		this.setData({
			phone: phone,
		})
		var phone = this.data.phone;
		console.log(phone)
	},
	choiceFn: function (e) {
		var index = e.currentTarget.dataset.index;
		this.setData({
			choice: index,
		})
	},

	datailFn: function (e) {
		var index = e.currentTarget.dataset.index;
		var modealTxt = this.data.choiceTxt[index]
		this.setData({
			togle: true,
			modealTxt: modealTxt,
		})
	},

	closeModeal: function (e) {
		this.setData({
			togle: false,
		})
	},
	//提交
	formSubmit: function (e) {
		var that = this;
		var formId = e.detail.formId;
		// wx.showToast({
		//   title: '请选择位置',
		//   icon: 'loading',
		//   duration: 2100
		// });
		var choice = this.data.choice;// 1为商家配送，2为阿凡提配送
		console.log(choice)
		if (choice == 0) {
			wx.showToast({
				title: '请选择合作方案',
				icon: 'loading',
				duration: 1200
			})
			return false
		}
		var phone = this.data.phone;
		var createTime = Date.parse(new Date());
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: "https://www.aftdc.com/wxapp/Service/enrol_distribution",
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				dlvService: choice,
				phone: phone,
				createTime: createTime,
			},
			method: 'post',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
				if (res.data.res == 1) {
					that.formId(formId);
					wx.hideLoading()
					wx.showToast({
						title: '已提交,请留意手机短信',
						mask: true,
						success: setTimeout(function () {
							wx.navigateTo({//跳转方法
								url: '../wait/wait?phone=' + res.data['phone'],
							})
						}, 2000)
					})
				} else {
					wx.showToast({
						title: res.data,
						icon: 'loading',
						duration: 2100
					});
				}
			}
		})
	},
	formId: function (formId) {
		var userId = app.globalData.userId;
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Service/formId',
			method: 'post',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			data: {
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				sign: sign,
				formId: formId,
				userId: userId,
			},
			success: function (res) {
				console.log(res)
			}
		})
	}
})