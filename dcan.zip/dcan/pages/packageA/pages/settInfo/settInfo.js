var app = getApp();
var MD5Util = require('../../../../utils/md5.js');
Page({

	data: {
		infoData: [
			{
				txt: '门店名称',
				types: 'text',
				name: 'shopName',//input的name
				place: '请与门脸照上名称一致',
				val: '',
			},
			{
				txt: '门店电话',
				types: 'number',
				name: 'shopPhone',//input的name
				place: '请填写门店电话',
				val: '',
			},
			{
				txt: '联系人姓名',
				types: 'text',
				name: 'name',//input的name
				place: '请填写联系人姓名',
				val: '',
			},
			{
				txt: '联系人电话',
				types: 'text',
				name: 'phone',//input的name
				place: '联系人电话',
				val: '12345678910',
			},
		],
		//门店照片显示数据
		imgData: [
			{
				txt: '门脸照',
				word: '一张真实美观的门脸照可以提升店铺形象',
				exampleImg: 'https://image.aftdc.com/images/packageA/shopImg2.jpg',
				exampleTxt: '门脸照需拍出完整牌匾，门框，需在餐厅开门营业状况下完成拍摄（建议正对门店2米处拍摄）',
				upImg: '',//上传的图片---
				name: 'frontImg'
			},
			{
				txt: '店内照',
				word: '简洁干净的店内照片可以让用户放心点单',
				exampleImg: 'https://image.aftdc.com/images/packageA/shopImg1.jpg',
				exampleTxt: '门脸照需拍出完整牌匾，门框',
				upImg: '',
				name: 'insideImg'

			},
			{
				txt: '门店LOGO',
				word: '上传与店铺配的logo，能提升店铺的概率（支持JPG、JPEG、PNG格式，大小不超过500k）',
				exampleImg: 'https://image.aftdc.com/images/packageA/logo.png',
				exampleTxt: '门脸照需拍出完整牌匾，门框',
				upImg: '',
				name: 'logo'

			},
		],
		//分类数据
		clasifyData: [
			{ name: '异国料理', child: [{ name: '披萨意面', id: 1 }, { name: '披萨意面', id: 2 }, { name: '披萨意面', id: 3 },] },
			{ name: '美食', child: [{ name: '炸鸡', id: 1 }, { name: '炸鸡', id: 2 }, { name: '炸鸡', id: 3 },] },
		],


		upIndex: '',//记录点击的上传图片
		//  uploadImg: { door: '', inside: '', logo: '' },//上传的图片数据 door 门脸，inside 店内，logo 门店logo

		exampleData: {},//示例弹出框数据,上传弹出框数据

		shopClas: '单店',//店铺类型
		rankTab: 1,//主次营选择导航
		rankData: { main: '', next: '' },//主次营选择的索引
		rankId: { mainid: '', nextid: '' },
		rankDataTxt: { main: '', next: '' },//主次营选择的文字,
		// rankActive: { a: -1, b: -1 },//选中的索引
		rankActive: -1,
		clasify: '',//分类

		switchs: true, //是否24小时营业
		times: [{ start: '', end: '' }], //自定义时间    
		time: '',//营业时间

		address: [],//省市区
		addressVal: '',//input 的显示文本
		location: {},//地图选择经纬度
		detailAddress: '',//详细地址

		togle: false,//1为门店分类 2为营业弹框，3为上传图片，4为门店照片示例弹框，
		ok: '',
	},


	onLoad: function (options) {
		var phone = options.phone;//上一页填写跳转的号码
		var infoData = this.data.infoData;
		infoData[3].val = phone;
		this.setData({
			infoData: infoData,
			ok: options.ok,
			phone: phone
		})
		//---
		var ok = options.ok;
		var that = this
	},
	onReady: function () {
		var that = this;
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Service/cuisine',
      data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token
        },
			header: {
				'content-type': 'application/json',
			},
			success: function (res) {
				//将请求的后台数据赋值new_list
				that.setData({
					clasifyData: res.data,
				})
			}
		})
	},
	// ------------------------------------------ 门店分类-----------------------------------------

	clasifyTogle: function () {
		this.setData({
			togle: 1
		})
	},
	//店铺类型
	radioChange: function (e) {
		this.setData({
			shopClas: e.detail.value
		})
	},

	rankTabFn: function (e) {
		var index = e.currentTarget.dataset.index;
		var rankId = this.data.rankId;
		var active = index == 1 ? rankId['mainid'] : rankId['nextid'];

		var rankActive = active
		this.setData({
			rankTab: index,
			rankActive: rankActive,
		})
	},
	rankChoiceFn: function (e) {
		var index = e.currentTarget.dataset.index;//大分类
		var idx = e.currentTarget.dataset.idx;  //小分类
		var rankTab = this.data.rankTab;
		var numb = 'a' + index + 'b' + idx;
		var rankData = this.data.rankData;//主次营的选择索引
		var rankDataTxt = this.data.rankDataTxt
		var clasifyData = this.data.clasifyData
		var txt = clasifyData[index].child[idx].name
		var rankId = this.data.rankId
		if (rankTab == 1) {
			var cid = rankId['nextid'];
			if (Boolean(cid) && clasifyData[index].child[idx].id == cid) {
				return false;
			}
			rankId['mainid'] = clasifyData[index].child[idx].id
			rankData['main'] = numb;
			rankDataTxt['main'] = txt;
		} else {
			var cid = rankId['mainid'];
			if (Boolean(cid) && clasifyData[index].child[idx].id == cid) {
				return false;
			}
			rankId['nextid'] = clasifyData[index].child[idx].id
			rankData['next'] = numb;
			rankDataTxt['next'] = txt;
		}
		var rankActive = clasifyData[index].child[idx].id
		this.setData({
			rankData: rankData,
			rankDataTxt: rankDataTxt,
			rankActive: rankActive,
			rankId: rankId
		})
	},
	//选择分类 确定
	clasifySure: function () {
		var rankDataTxt = this.data.rankDataTxt;
		if (!Boolean(rankDataTxt['main'])) {
			wx.showToast({
				title: '请选择主营分类',
				icon: 'loading',
				duration: 1200
			})
			return false
		} else if (!Boolean(rankDataTxt['next'])) {
			rankDataTxt['next'] = '无'
		}
		var clasify = '主营:' + rankDataTxt['main'] + '/次营:' + rankDataTxt['next']

		this.setData({
			togle: false,
			clasify: clasify,
		})
	},

	// ------------------------------------------ 营业时间-----------------------------------------
	//  营业时间弹出
	timeTogle: function (e) {
		this.setData({
			togle: 2
		})
	},
	switchChange: function (e) {
		this.setData({
			switchs: e.detail.value
		})
	},
	// 时间选择
	timeCharge: function (e) {
		var index = e.currentTarget.dataset.index;
		var name = e.currentTarget.dataset.name; //选择的是开始时间还是结束时间
		var times = this.data.times;
		times[index][name] = e.detail.value
		this.setData({
			times: times
		})
	},
	//删除时间
	closeTime: function (e) {
		var index = e.currentTarget.dataset.index;
		var times = this.data.times;
		times.splice(index, 1)
		this.setData({
			times: times,
		})
	},
	//添加时间
	addTime: function (e) {
		var times = this.data.times;
		var obj = { start: '开始时间', end: '结束时间' }
		times.push(obj);
		this.setData({
			times: times
		})
	},

	timeBut: function (e) {
		var switchs = this.data.switchs;
		if (switchs) {
			this.setData({
				time: '00:00-23:59',
				togle: false,
			})
		} else {
			var times = this.data.times[0];//现在自定义只有一个时间段
			var start = times.start;
			var end = times.end;
			if (!Boolean(start)) {
				wx.showToast({
					title: '请选择开始时间',
					icon: 'loading',
					duration: 1200
				})
				return false
			}
			if (!Boolean(end)) {
				wx.showToast({
					title: '请选择结束时间',
					icon: 'loading',
					duration: 1200
				})
				return false
			}

			this.setData({
				time: start + '-' + end,
				togle: false,
			})

		}


	},

	// ------------------------------------------ 地图-----------------------------------------
	addressChange: function (e) {
		var val = e.detail.value
		var addressVal = val[0] + '-' + val[1] + '-' + val[2]
		this.setData({
			address: val,
			addressVal: addressVal
		})
	},
	detailFn: function (e) {
		var val = e.detail.value;
		this.setData({
			detailAddress: val
		})
	},
	mapFn: function () {
		var that = this
		var r = that.data.address;
		var a = that.data.detailAddress;
		if (r == '' || a == '') {
			wx.showToast({
				title: '完善区域和地址',
				icon: 'loading',
				duration: 2200
			})
			return false;
		}
		wx.chooseLocation({
			success: function (res) {
				var location = {};
				location.longitude = res.longitude
				location.latitude = res.latitude
				that.setData({
					mapsTxt: res.name,
					location: location,
				})
			}
		})
	},
	// ------------------------------------------ 上传图片-----------------------------------------
	uploadTogle: function (e) {
		var index = e.currentTarget.dataset.index;
		var exampleData = this.data.imgData[index]
		this.setData({
			upIndex: index,
			exampleData: exampleData,
		})
		this.uploadFn()
	},
	uploadFn: function () {
		var that = this
		wx.chooseImage({
			count: 1, // 默认9
			sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
			sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
			success: function (res) {
				// 返回选定照片的本地文件路径列表， res.tempFilePaths可以作为img标签的src属性显示图片
				var imgData = that.data.imgData;
				var upIndex = that.data.upIndex;
				imgData[upIndex].upImg = res.tempFilePaths[0]
				that.setData({
					togle: false,
					imgData: imgData,
				})
			}
		})
	},


	// ------------------------------------------ 示例图片-----------------------------------------
	exampleFn: function (e) {
		var index = e.currentTarget.dataset.index;
		var val = this.data.imgData[index];
		this.setData({
			exampleData: val,
			togle: 4,
		})
	},

	//-------------- 关闭弹框 -----------
	togleFn: function () {
		this.setData({
			togle: false,
		})
	},

	//--------------- 下一步 ---------------
	formSubmit: function (e) {
		//如果要改变上传数据的名字，改变data对应数据中的 name 
		var infoData = this.data.infoData;//页面数据
		var formData = e.detail.value;//-------------------提交表单数据
		for (var i in formData) {
			var txt = formData[i]
			if (txt.length == 0) {
				//获取缺少是哪个数据
				var len = infoData.length;
				var tsTile = '请完善信息';
				for (var j = 0; j < len; j++) {
					if (infoData[j].name == i) {
						var t = infoData[j].txt;
						tsTile = '请填写' + t
						break
					}
				}
				wx.showToast({
					title: tsTile,
					icon: 'loading',
					duration: 1200
				})
			}
		}
		//检测图片
		var imgData = this.data.imgData;
		var ok = this.data.ok;
		var imgs = {};//----------------------------  提交图片
    var postf = {};//----------------------------  后缀名
		for (var k in imgData) {
			var img = imgData[k].upImg
			if (img.length == 0) {
				var tsimg = imgData[k].txt
				wx.showToast({
					title: '请上传' + tsimg,
					icon: 'loading',
					duration: 1200
				})
				return false
			}
			var name = imgData[k].name
			imgs[name] = img
      var filename = img;
      var index1 = filename.lastIndexOf(".");
      var index2 = filename.length;
      postf[name] = filename.substring(index1, index2);//后缀名  
		}
		//其他数据 rankId
		var rankId = this.data.rankId;//"主营:1/次营:2"
		var latitude = this.data.location.latitude;//经纬度
		var longitude = this.data.location.longitude;//经纬度
		var shopClas = this.data.shopClas;// 店铺类型
		if (shopClas == '单店') {
			shopClas = 2;
		} else {
			shopClas = 1;
		}
		var province = this.data.address[0]; //"北京市-北京市-东城区"
		var city = this.data.address[1]; //"北京市-北京市-东城区"
		var county = this.data.address[2]; //"北京市-北京市-东城区"
		if (province == '') {
			wx.showToast({
				title: '请选择店铺地址',
				icon: 'loading',
				duration: 2100
			});
			return false;
		}
		var cuisineId = rankId['mainid'];//"主营"
		var secondary = rankId['nextid'];//"次营
		if (!secondary) {
			var secondary = -1;//"次营
		}
		if (cuisineId == '') {
			wx.showToast({
				title: '请选择门店分类',
				icon: 'loading',
				duration: 2100
			});
			return false;
		}
		var detailAddress = formData['detailAddress'];//"详细地址"
		var mapsTxt = formData['mapsTxt'];//"三元里广州市白云区政府(广园中路南)"
		var userId = app.globalData.userId;
		if (mapsTxt == '') {
			wx.showToast({
				title: '请选择位置',
				icon: 'loading',
				duration: 1100
			});
			return false;
		}
		var name = formData['name'];//"联系人"
		if (name == '') {
			wx.showToast({
				title: '请输入联系人',
				icon: 'loading',
				duration: 1100
			});
			return false;
		}
		var phone = formData['phone'];//13845456356"
		var shopName = formData['shopName'];//"门店名称"
		if (shopName == '') {
			wx.showToast({
				title: '请填写名称',
				icon: 'loading',
				duration: 1100
			});
			return false;
		}
		if (shopName.length > 12) {
			wx.showToast({
				title: '名称限12字',
				icon: 'loading',
				duration: 1100
			});
			return false;
		}
		var shopPhone = formData['shopPhone'];//"门店电话"
		if (shopPhone == '' || !/^(0?(13[0-9]|15[012356789]|17[013678]|18[0-9]|14[57])[0-9]{8})|(400|800)([0-9\\-]{7,10})|(([0-9]{4}|[0-9]{3})(-| )?)?([0-9]{7,8})((-| |转)*([0-9]{1,4}))?$/.test(shopPhone)) {
			wx.showToast({
				title: '门店电话错误',
				icon: 'loading',
				duration: 1100
			});
			return false;
		}
		var time = formData['time'];//"00:00-23:59"
		if (time == '') {
			wx.showToast({
				title: '请选择营业时间',
				icon: 'loading',
				duration: 1100
			});
			return false;
		}
		var timeone = time.substr(0, 5);
		var timeend = time.substr(6, 10);
		var createTime = Date.parse(new Date());
		wx.showLoading({
			title: '提交中',
		})
    console.log(imgs)
    var frontImg = postf['frontImg'];//门脸图
    var insideImg = postf['insideImg'];//店内图
    var logo = postf['logo'];//logo
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Service/enrol_shop_message',
			method: 'POST',
			data: {
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				latitude: latitude,
				longitude: longitude,
				shopType: shopClas,
				province: province,
				city: city,
				county: county,
				cuisineId: cuisineId,
				secondary: secondary,
				detailAddress: detailAddress,
				shopAddress: mapsTxt,
				userId: userId,
				userName: name,
				phone: phone,
				shopName: shopName,
				stores_phon: shopPhone,
				createTime: createTime,
				serviceStartTime: timeone,
				serviceEndTime: timeend,
        frontImg: frontImg,//文件后缀
        insideImg: insideImg,//文件后缀
        logo: logo,//文件后缀
			},
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
        var shopImg = res.data.oss.dir + res.data.logo;//logo图片
        var door_img = res.data.oss.dir + res.data.frontImg;//门脸图片
        var store_img = res.data.oss.dir + res.data.insideImg;//店内图片
        var shopId = res.data.shopId;
        console.log(res)
				if (res.data.res == 1) {
					var num = 0;
					//上传logo
					if (imgs['logo']) {
						wx.uploadFile({
							url: res.data.oss.host,
							filePath: imgs['logo'],
							name: 'file',
							formData: {
                "key": res.data.oss.dir + res.data.logo,//图片的路径
								"policy": res.data.oss.policy,
								"OSSAccessKeyId": res.data.oss.accessid,
								'success_action_status': '200',
								'signature': res.data.oss.signature
							},
							header: { "Content-Type": "multipart/form-data" },
							success: function (res) {
                
								//成功返回{statusCode: 200, data: "", errMsg: "uploadFile:ok"}
								if (res.statusCode==200){
									// num++
                  //请求告诉后台图片上传成功
                  var timestamp = (Date.parse(new Date())) / 1000
                  var sign = MD5Util.sign(timestamp)
                  wx.request({
                    url:'https://www.aftdc.com/wxapp/Service/enrol_upload',
                    method:'POST',
                    header: { "Content-Type": "application/x-www-form-urlencoded" },
                    data:{
                      sign: sign,
                      timestamp: timestamp,
                      token: app.globalData.usersInfo.token,
                      type:1,
                      file: shopImg,
                      shopId: shopId,
                    },
                    success:function(res){
                      console.log(res)
                      if(res.data.res == 1){
                        num++
                      }
                      if (num == 3) {
                        wx.hideLoading()
                        wx.showToast({
                          title: '请进行下一步',
                          mask: true,
                          success: setTimeout(function () {
                            if (ok == 1) {
                              wx.navigateTo({
                                url: '../wait/wait?phone=' + that.data.phone,
                              })
                            } else {
                              wx.navigateTo({
                                url: '../aptitude/aptitude?phone=' + that.data.phone,
                              })
                            }
                          }, 2000)
                        })
                      }
                    }
                  })
								}
							}
						})
					}
					//门脸图
					if (imgs['frontImg']) {
						wx.uploadFile({
							url: res.data.oss.host,
							filePath: imgs['frontImg'],
							name: 'file',
							formData: {
                "key": res.data.oss.dir + res.data.frontImg,
								"policy": res.data.oss.policy,
								"OSSAccessKeyId": res.data.oss.accessid,
								'success_action_status': '200',
								'signature': res.data.oss.signature
							},
							header: { "Content-Type": "multipart/form-data" },
							success: function (res) {
								if (res.statusCode == 200) {
                  var timestamp = (Date.parse(new Date())) / 1000
                  var sign = MD5Util.sign(timestamp)
									// num++
                  wx.request({
                    url: 'https://www.aftdc.com/wxapp/Service/enrol_upload',
                    method: 'POST',
                    header: { "Content-Type": "application/x-www-form-urlencoded" },
                    data: {
                      sign: sign,
                      timestamp: timestamp,
                      token: app.globalData.usersInfo.token,
                      type: 2,
                      file: door_img,
                      shopId: shopId,
                    },
                    success: function (res) {
                      console.log(res)
                      if (res.data.res == 1) {
                        num++
                      }
                      if (num == 3) {
                        wx.hideLoading()
                        wx.showToast({
                          title: '请进行下一步',
                          mask: true,
                          success: setTimeout(function () {
                            if (ok == 1) {
                              wx.navigateTo({
                                url: '../wait/wait?phone=' + that.data.phone,
                              })
                            } else {
                              wx.navigateTo({
                                url: '../aptitude/aptitude?phone=' + that.data.phone,
                              })
                            }
                          }, 2000)
                        })
                      }
                    }
                  })
								}
							}
						})
					}
					//店内图
					if (imgs['insideImg']) {
						wx.uploadFile({
							url: res.data.oss.host,
							filePath: imgs['insideImg'],
							name: 'file',
							formData: {
                "key": res.data.oss.dir + res.data.insideImg,
								"policy": res.data.oss.policy,
								"OSSAccessKeyId": res.data.oss.accessid,
								'success_action_status': '200',
								'signature': res.data.oss.signature
							},
							success: function (res) {
								if (res.statusCode == 200) {
									// num++
                  var timestamp = (Date.parse(new Date())) / 1000
                  var sign = MD5Util.sign(timestamp)
                  wx.request({
                    url: 'https://www.aftdc.com/wxapp/Service/enrol_upload',
                    method: 'POST',
                    header: { "Content-Type": "application/x-www-form-urlencoded" },
                    data: {
                      sign: sign,
                      timestamp: timestamp,
                      token: app.globalData.usersInfo.token,
                      type: 3,
                      file: store_img,
                      shopId: shopId,
                    },
                    success: function (res) {
                      if (res.data.res == 1) {
                        num++
                      }
                      console.log(res)
                      if (num == 3) {
                        wx.hideLoading()
                        wx.showToast({
                          title: '请进行下一步',
                          mask: true,
                          success: setTimeout(function () {
                            if (ok == 1) {
                              wx.navigateTo({
                                url: '../wait/wait?phone=' + that.data.phone,
                              })
                            } else {
                              wx.navigateTo({
                                url: '../aptitude/aptitude?phone=' + that.data.phone,
                              })
                            }
                          }, 2000)
                        })
                      }
                    }
                  })
								}
							}
						})
					}
				} else {
					wx.showToast({
						title: res.data.info,
						icon: 'loading',
						duration: 1100
					});
				}
			}
		})
		return false;
	},

})


