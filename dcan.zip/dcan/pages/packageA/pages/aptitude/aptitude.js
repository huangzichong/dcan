// pages/league/aptitude/aptitude.js
var MD5Util = require('../../../../utils/md5.js');
var app = getApp();

Page({

	data: {
		infoData: [
			{
				txt: '证件类型',//0
				types: 'text',
				name: 'cardClasfly',//input的name 
				place: '选择',
				val: '身份证',
				moreFn: 'more',
				index: 0,
			},
			{
				txt: '真实姓名',//1
				types: 'text',
				name: 'bankUserName',//input的name 
				place: '证件上的姓名',
				val: '',
				index: 1,
				moreFn: 'not',
			},
			{
				txt: '证件号码',//2
				types: 'text',
				name: 'IdentityNo',//input的name
				place: '证件上的号码',
				val: '',
				index: 2,
				moreFn: 'not',
			},
			{
				txt: '证件类型',//3
				types: 'text',
				name: 'unitType',//input的name
				place: '选择',
				val: '营业执照',
				moreFn: 'more',
				index: 3,
			},
			{
				txt: '单位名称',//4
				types: 'text',
				name: 'unitName',//input的name
				place: '证件上的单位名称',
				val: '',
				index: 4,
				moreFn: 'not',
			},
			{
				txt: '注册号',//5
				types: 'text',
				name: 'unitNumb',//input的name
				place: '证件对应注册号',
				val: '',
				index: 5,
				moreFn: 'not',
			},
			{
				txt: '注册地址',//6
				types: 'text',
				name: 'unitAdres',//input的name
				place: '证件对应地址',
				val: '',
				index: 6,
				moreFn: 'not',
			},
			{
				txt: '法定代表人',//7
				types: 'text',
				name: 'unitPeople',//input的name
				place: '证件上的营业者',
				val: '',
				index: 7,
				moreFn: 'not',
			},
			{
				txt: '',//8
				types: 'text',
				name: 'unitFixed',//input的name
				place: '选择固定时间',
				val: '',
				moreFn: 'more',
				index: 8,
				moreFn: 'not',
			},
			//---
			{
				txt: '证件类型',//9
				types: 'text',
				name: 'allowType',//input的name
				place: '选择',
				val: '',
				moreFn: 'more',
				index: 9,
			},
			{
				txt: '单位名称',//10
				types: 'text',
				name: 'allowName',//input的name
				place: '证件上的单位名称',
				val: '',
				index: 10,
				moreFn: 'not',
			},
			{
				txt: '许可证编号',//11
				types: 'text',
				name: 'allowNumb',//input的name
				place: '证件对应编号',
				val: '',
				index: 11,
				moreFn: 'not',
			},
			{
				txt: '许可证地址',//12
				types: 'text',
				name: 'allowAdres',//input的name
				place: '证件对应地址',
				val: '',
				index: 12,
				moreFn: 'not',
			},
			{
				txt: '法定代表人',//13
				types: 'text',
				name: 'allowPeople',//input的name
				place: '证件上对应法定代表人',
				val: '',
				index: 13,
				moreFn: 'not',
			},
			{
				txt: '',//14
				types: 'text',
				name: 'allowFixed',//input的name
				place: '选择固定时间',
				val: '',
				moreFn: 'more',
				index: 14,
				moreFn: 'not',
			},
			{
				txt: '本人银行卡',//2
				types: 'text',
				name: 'bankNo',//input的name
				place: '银行卡号',
				val: '',
				index: 15,
				moreFn: 'not',
			},
			{
				txt: '银行',//2
				types: 'text',
				name: 'bankName',//input的name
				place: '银行名称',
				val: '',
				index: 16,
				moreFn: 'not',
			},

		],
		imgData: [
			{
				txt: '正面照',
				word: '请注意证件照片上的文字能够清晰可见',
				exampleImg: 'https://image.aftdc.com/images/packageA/papers1.jpg',
				exampleTxt: '证件照片上的文字需要能够清晰辨认',
				upImg: '',//上传的图片
				name: 'faceImg',//上传图片字段名
				index: 0,

			},
			{
				txt: '反面照',
				word: '请注意证件照片上的文字能够清晰可见',
				exampleImg: 'https://image.aftdc.com/images/packageA/papers2.jpg',
				exampleTxt: '证件照片上的文字需要能够清晰辨认',
				upImg: '',//上传的图片
				name: 'backImg',
				index: 1,
			},
			{
				txt: '手持正面照',
				word: '请注意证件照片上的文字能够清晰可见',
				exampleImg: 'https://image.aftdc.com/images/packageA/papers3.jpg',
				exampleTxt: '证件照片上的文字需要能够清晰辨认',
				upImg: '',//上传的图片
				name: 'handImg',
				index: 2,
			},
			{
				txt: '证件照片',
				word: '请注意证件照片上的文字能够清晰可见',
				exampleImg: 'https://image.aftdc.com/images/packageA/setTyps.jpg',
				exampleTxt: '证件照片上的文字需要能够清晰辨认',
				upImg: '',//上传的图片 餐饮许可证
				name: 'unitImg',
				index: 3,
			},
			{
				txt: '证件照片',
				word: '请注意证件照片上的文字能够清晰可见',
				exampleImg: 'https://image.aftdc.com/images/packageA/setAllow.jpg',
				exampleTxt: '证件照片上的文字需要能够清晰辨认',
				upImg: '',//上传的图片
				name: 'allowImg',
				index: 4,
			},
			{
				txt: '银行卡',
				word: '请注意证件照片上的文字能够清晰可见',
				exampleImg: 'https://image.aftdc.com/images/packageA/bank.jpg',
				exampleTxt: '证件照片上的文字需要能够清晰辨认',
				upImg: '',//上传的图片
				name: 'bankImg',
				index: 5,
			},
		],
		//身份证证件类型选择的index
		cardData: ['身份证', '港澳居民内地居住证', '台胞证', '护照',],
		cardIndex: 0,//选择的index

		//营业执照证件类型选择
		typeData: ['营业执照', '灵活就业（营业）辅导证/意见', '事业单位法人证书', '民办非企业单位登记证书', '社会团体法人登记证书'],
		typeIndex: 0,//选择的index
		typeRadio: '长期有效',
		dateRadio: '长期有效',
		typeFixed: '', //具体固定时间

		//行业资质类型选择
		allowData: ['餐饮服务许可证', '食品经营许可证', '食品流通许可证', '食品摊贩临时经营公示卡', '全国工业产品生产许可证',
			'小徽餐饮分级证/登记凭证', '食品生产加工作坊准许证', '食品小作坊生产许可证', '食品小作坊登记证', '',
			'食品小作坊核准证', '小作坊、小餐饮登记证/小摊点备案凭证', '食品摊贩备案证明', '小作坊卫生许可证', '食品摊贩登记卡',
			'食品经营实名备案证', '小餐饮经营许可证'

		],
		allowIndex: 0,//选择的index
		allowRadio: '长期有效',
		allowFixed: '',

		upIndex: '',//记录点击的上传图片
		exampleData: {},//示例弹出框数据,上传弹出框数据

		togle: false,//3为上传图片，4为门店照片示例弹框，
		ok: '',
		reverse: 0,//反面
		identify: 0,//手持
		phone: '',//手机
		sfz: '',//身份证
		sc: '',//手持身份证 
	},



	onLoad: function (options) {
		var phone = options.phone;//上一页填写跳转的号码
		this.setData({
			phone: phone,
			ok: options.ok,
		})
	},
	bindInput: function (e) {
		var val = e.detail.value;
		var index = e.currentTarget.dataset.index;
		var infoData = this.data.infoData
		infoData[index]['val'] = val
		this.setData({
			infoData: infoData,
		})
	},


	//身份证证件类型选择----------------
	cardChoice: function (e) {
		var index = e.detail.value;
		var infoData = this.data.infoData
		infoData[0]['val'] = this.data.cardData[index]
		this.setData({
			cardIndex: index,
			infoData: infoData,
		})
	},
	//营业执照证件类型选择--------------------------
	typeChoice: function (e) {
		var index = e.detail.value;
		var infoData = this.data.infoData
		infoData[3]['val'] = this.data.typeData[index]
		this.setData({
			typeIndex: index,
			infoData: infoData,
		})
	},
	//有效期选择
	radioChange: function (e) {
		this.setData({
			dateRadio: e.detail.value
		})
	},

	//选择固定时间
	dateChoice: function (e) {
		var val = e.detail.value
		var infoData = this.data.infoData
		infoData[8]['val'] = val
		this.setData({
			typeFixed: val,
			infoData: infoData,
		})
	},

	//-------------------------------------行业资质选填---------------------
	allowChoice: function (e) {
		var index = e.detail.value;
		var infoData = this.data.infoData
		infoData[9]['val'] = this.data.allowData[index]
		this.setData({
			allowIndex: index,
			infoData: infoData,
		})
	},
	//有效期选择
	allowRadio: function (e) {
		this.setData({
			allowRadio: e.detail.value
		})
	},

	//选择固定时间
	allowDate: function (e) {
		var val = e.detail.value
		var infoData = this.data.infoData
		infoData[14]['val'] = val
		this.setData({
			allowFixed: val,
			infoData: infoData,
		})
	},
	// ------------------------------------------ 上传图片-----------------------------------------
	uploadTogle: function (e) {
		var index = e.currentTarget.dataset.index;
		var exampleData = this.data.imgData[index]
		this.setData({
			upIndex: index,
			exampleData: exampleData,
			togle: 3,
		})
	},
	uploadFn: function () {
		var that = this
		wx.chooseImage({
			count: 1, // 默认9
			sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
			sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
			success: function (res) {
				// 返回选定照片的本地文件路径列表， res.tempFilePaths可以作为img标签的src属性显示图片
				var imgData = that.data.imgData;
				var infoData = that.data.infoData
				var upIndex = that.data.upIndex;
				var file = res.tempFilePaths[0];
				var userId = app.globalData.userId;
				var phone = that.data.phone;
				var filename = res.tempFilePaths[0];//后缀名 
				var index1 = filename.lastIndexOf(".");
				var index2 = filename.length;
				var name = filename.substring(index1, index2);//后缀名 
				console.log(upIndex)
				imgData[upIndex].upImg = res.tempFilePaths[0]
				that.setData({
					togle: false,
					imgData: imgData,
				})
				// wx.showLoading({
				//   title: '识别中',
				// })
				var timestamp = (Date.parse(new Date())) / 1000
				var sign = MD5Util.sign(timestamp)
				wx.request({
					url: 'https://www.aftdc.com/wxapp/Service/oneself_imgname',
					method: 'POST',
					data: {
						sign: sign,
						timestamp: timestamp,
						token: app.globalData.usersInfo.token,
						phone: phone,
						name: name,
						type: upIndex,
					},
					header: { "Content-Type": "application/x-www-form-urlencoded" },
					success: function (res) {
						var imgurl = 'https://image.aftdc.com/' + res.data.name;//图片的路径
						console.log(imgurl)
						wx.uploadFile({
							url: res.data.oss.host,
							filePath: file,
							name: 'file',
							formData: {
								"key": res.data.name,//图片的路径
								"policy": res.data.oss.policy,
								"OSSAccessKeyId": res.data.oss.accessid,
								'success_action_status': '200',
								'signature': res.data.oss.signature
							},
							header: { "Content-Type": "multipart/form-data" },
							success: function (res) {
								console.log(res)
								//成功返回{statusCode: 200, data: "", errMsg: "uploadFile:ok"}
								if (res.statusCode == 200) {
									if (upIndex == 0) {
										sfz = imgurl;//身份证
										that.setData({
											sfz: sfz,
										})
									}
									if (upIndex == 2) {
										sc = imgurl;//手持
										var identify = 0
										that.setData({
											identify: identify,
										})
										that.setData({
											sc: sc,
										})
									}
									var sfz = that.data.sfz;//身份证
									var sc = that.data.sc;//手持
									var identify = that.data.identify;//手持对比额
									if (identify != 1 && sfz && sc) {
										var timestamp = (Date.parse(new Date())) / 1000
										var sign = MD5Util.sign(timestamp)
										wx.request({
											url: 'https://www.aftdc.com/wxapp/Service/oneself_handheld',
											method: 'POST',
											data: {
												sign: sign,
												timestamp: timestamp,
												token: app.globalData.usersInfo.token,
												sfz: sfz,
												sc: sc,
											},
											header: { "Content-Type": "application/x-www-form-urlencoded" },
											success: function (ai) {
												console.log(ai)
												//手持错误
												if (ai.data[0] > 30) {
													var identify = 1
													that.setData({
														identify: identify,
													})
												}
											}
										})
									}
									console.log(identify)
									var timestamp = (Date.parse(new Date())) / 1000
									var sign = MD5Util.sign(timestamp)
									wx.request({
										url: 'https://www.aftdc.com/wxapp/Service/oneself_upload',
										method: 'POST',
										data: {
											sign: sign,
											timestamp: timestamp,
											token: app.globalData.usersInfo.token,
											phone: phone,
											file: imgurl,
											type: upIndex,
										},
										header: { "Content-Type": "application/x-www-form-urlencoded" },
										success: function (res) {
											// var json = res.data;
											var all = res.data;
											console.log(all)
											// var json = JSON.parse(all)
											// console.log(json)
											//反面错误
											if (all[1] == '反') {
												var reverse = 1
												that.setData({
													reverse: reverse,
												})
											}
											console.log(that.data.reverse)
											if (all[0] == false) {
												wx.showToast({
													title: all.info,
													icon: 'loading',
													duration: 1000
												});
												return false;
											}
											if (upIndex == 0) {
												infoData[1]['val'] = '';//身份证证件信息
												infoData[2]['val'] = '';
												that.setData({
													infoData: infoData,
												})
											}
											if (all[6] == "正") {
												infoData[1]['val'] = all[2];//身份证证件信息
												infoData[2]['val'] = all[5];
												that.setData({
													infoData: infoData,
												})
											}
											if (upIndex == 5) {
												infoData[15]['val'] = '';//银行卡
												that.setData({
													infoData: infoData,
												})
											}
											if (upIndex == 5 && all[5] == '银') {
												infoData[15]['val'] = all[0];
												infoData[16]['val'] = all[3];
												that.setData({
													infoData: infoData,
												})
											}
											if (upIndex == 3) {
												infoData[4]['val'] = '';//营业执照
												infoData[5]['val'] = '';
												infoData[6]['val'] = '';
												infoData[7]['val'] = '';
												infoData[8]['val'] = '';
												that.setData({
													infoData: infoData,
												})
											}
											if (upIndex == 3 && all[5] == '营') {
												infoData[4]['val'] = all[2];//必填证件内容
												infoData[5]['val'] = all[0];
												// if (json[4] == "无") {
												//   json[4] = json['shopAddress'];
												// }
												infoData[6]['val'] = all[3];
												infoData[7]['val'] = all[1];
												var time = all[4];
												if (time == "长期") {
													var dateRadio = '长期有效';
												} else {
													infoData[8]['val'] = all[4];
													var dateRadio = '固定日期';
												}
												that.setData({
													infoData: infoData,
													dateRadio: dateRadio,
												})
											}
											if (upIndex == 4) {
												infoData[10]['val'] = '';
												infoData[11]['val'] = '';
												infoData[12]['val'] = '';
												infoData[13]['val'] = '';
												infoData[14]['val'] = '';
												that.setData({
													infoData: infoData,
												})
											}
											if (upIndex == 4 && all[5] == '营') {
												infoData[10]['val'] = all[2];//必填证件内容
												infoData[11]['val'] = all[0];
												// if (json[4] == "无") {
												//   json[4] = json['shopAddress'];
												// }
												infoData[12]['val'] = all[3];
												infoData[13]['val'] = all[1];
												var time = all[4];
												if (time == "长期") {
													var allowRadio = '长期有效';
												} else {
													infoData[14]['val'] = all[4];
													var allowRadio = '固定日期';
												}
												that.setData({
													infoData: infoData,
													allowRadio: allowRadio,
												})
											}
										}
									})
								}
							}
						})
					}
				})
			}
		})
	},

	// ------------------------------------------ 示例图片-----------------------------------------
	exampleFn: function (e) {
		var index = e.currentTarget.dataset.index;
		var val = this.data.imgData[index];
		this.setData({
			exampleData: val,
			togle: 4,
		})
	},

	//-------------- 关闭弹框 -----------
	togleFn: function () {
		this.setData({
			togle: false,
		})
	},
	//----------------------  提交 下一步 -----------------
	formSubmit: function (e) {
		var infoData = this.data.infoData;//页面数据
		var formData = e.detail.value;//-------------------提交表单数据

		if (formData.bankNo == '' && formData.bankUserName == '') {
			wx.showToast({
				title: '身份证未识别',
				icon: 'loading',
				duration: 1200
			})
			return false;
		}
		if (formData.bankNo == '') {
			wx.showToast({
				title: '银行卡错误',
				icon: 'loading',
				duration: 1200
			})
			return false;
		}
		if (formData.unitName == '' || formData.unitNumb == '' || formData.unitAdres == '' || formData.unitPeople == '') {
			wx.showToast({
				title: '营业执照未识别',
				icon: 'loading',
				duration: 1200
			})
			return false;
		}
		console.log(formData.bankUserName)
		console.log(formData.unitPeople)
		// if (formData.unitPeople != formData.bankUserName){
		//   wx.showToast({
		//     title: '持证人要一致',
		//     icon: 'loading',
		//     duration: 1200
		//   })
		//   return false;
		// }
		//检测图片
		var imgData = this.data.imgData;
		var imgs = {};//----------------------------  提交图片
		var postf = {};//----------------------------  后缀名
		for (var k in imgData) {
			var img = imgData[k].upImg
			var name = imgData[k].name
			if (img.length == 0 && name != 'allowImg') {//allowImg为选填图片
				var tsimg = imgData[k].txt
				wx.showToast({
					title: '请填写' + tsimg,
					icon: 'loading',
					duration: 1200
				})
				return false
			}
			imgs[name] = img
			var filename = img;
			var index1 = filename.lastIndexOf(".");
			var index2 = filename.length;
			postf[name] = filename.substring(index1, index2);//后缀名  
			formData['one'] = postf.faceImg;//正面
			formData['two'] = postf.backImg;//反面
			formData['three'] = postf.handImg;//手持
			formData['four'] = postf.unitImg;//必填营业
			formData['five'] = postf.allowImg;//不必填营业
			formData['six'] = postf.bankImg//银行
		}
		console.log(formData)
		var reverse = this.data.reverse;
		var identify = this.data.identify;
		if (this.data.reverse == 0) {
			wx.showToast({
				title: '反面照出错',
				icon: 'loading',
				duration: 1200
			})
			return false;
		}
		if (this.data.identify == 0) {
			wx.showToast({
				title: '手持正面出错',
				icon: 'loading',
				duration: 1200
			})
			return false;
		}
		var that = this
		formData['phone'] = this.data.phone;
		formData['createTime'] = Date.parse(new Date());

		// wx.showLoading({
		//   title: '提交中',
		// })
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		formData['sign'] = sign;
		formData['timestamp'] = timestamp;
		formData['token'] = app.globalData.usersInfo.token;

		wx.request({
			url: 'https://www.aftdc.com/wxapp/Service/enrol_oneself_message',
			method: 'POST',
			data: formData,
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
				var ok = that.data.ok;
				if (res.data.res == 1) {
					wx.showToast({
						title: '请进行下一步',
						mask: true,
						success: setTimeout(function () {
							if (ok == 1) {
								wx.navigateTo({
									url: '../wait/wait?phone=' + res.data.phone,
								})
							} else {
								wx.navigateTo({
									url: '../scheme/scheme?phone=' + res.data.phone,
								})
							}
						}, 2000)
					})
				} else if (res.data.res == 0) {
					wx.showToast({
						title: res.data.info,
						icon: 'loading',
						duration: 1100
					});
				}
			}
		})
	},
})