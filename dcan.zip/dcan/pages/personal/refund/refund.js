var app = getApp()
var MD5Util = require('../../../utils/md5.js');
Page({

	data: {
		show_box1: false,
		show_box2: false,
		box2: false,
		refundRemark: '',
		mode: [{ name: "仅退款", circle: true }, { name: "退货并退款", circle: false }],
		mode_display: '仅退款',
		reason: [
			{ name: "买/卖双方协商一致", circle: true },
			{ name: "买错/不想要", circle: false },
			{ name: "商品质量有问题", circle: false },
			{ name: "未收到货", circle: false },
			{ name: "其他", circle: false },
		],
		reason_display: '买/卖双方协商一致',
	},
	onLoad: function (options) {
		var orderId = options.orderId
		var that = this
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		that.setData({
			orderId: orderId,
			shopId: options.shopId,
			orderStatus: options.orderStatus
		})
		wx.request({
			url: 'https://www.aftdc.com/wxapp/order/refundOrder',
			method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			data:
			{
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
				orderId: orderId
			},
			success: function (res) {
				that.setData({
					order: res.data
				})
			}
		})
	},
	box1: function (e) {
		var status = e.currentTarget.dataset.status;
		if (status == 1) {
			this.setData({
				show_box1: true
			})
		} else {
			this.setData({
				show_box1: false
			})
		}
	},
	box2: function (e) {
		var rea = e.currentTarget.dataset.rea;
		if (rea == 1) {
			this.setData({
				show_box2: true,
			})
		} else {
			this.setData({
				show_box2: false,
			})
		}
	},
	//退款售后选中框
	mode: function (e) {
		var mode = this.data.mode
		var circle = e.currentTarget.dataset.circle;
		for (var i in mode) {
			if (i == circle) {
				mode[i].circle = true;
				this.setData({
					mode_display: mode[i].name,
				})
			} else {
				mode[i].circle = false;
			}
		}
		this.setData({
			mode: mode,
			show_box1: false,
			show_box2: false
		})

	},
	//退款原因选中框
	reason: function (e) {
		var reason = this.data.reason
		var circle = e.currentTarget.dataset.circle;
		for (var i in reason) {
			if (i == circle) {
				reason[i].circle = true;
				this.setData({
					reason_display: reason[i].name,
				})
			} else {
				reason[i].circle = false;
			}
		}
		this.setData({
			reason: reason,
			show_box1: false,
			show_box2: false
		})

	},
	refund_sm: function (e) {
		var refundRemark = e.detail.value
		var that = this
		that.setData({
			refundRemark: refundRemark
		})
	},
	but: function () {
		wx.showLoading()
		var that = this
		var reason = that.data.reason_display
		var refundRemark = reason + '。' + that.data.refundRemark
		var userId = app.globalData.userId
		var orderId = that.data.orderId
		var shopId = that.data.shopId
		var orderStatus = that.data.orderStatus
		var backMoney = that.data.order.realTotalMoney
    var timestamp = (Date.parse(new Date())) / 1000
    var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/order/orderCancel',
			method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			data:
			{
				orderId: orderId,
				shopId: shopId,
				orderStatus: orderStatus,
				userId: userId,
				refundRemark: refundRemark,
				backMoney: backMoney,
        sign: sign,
        timestamp: timestamp,
        token: app.globalData.usersInfo.token,
			},
			success: function (res) {
				wx.hideLoading()
				if (res.data.status == -1) {
					wx.showModal({
						title: '提示',
						content: res.data.msg,
						showCancel:false
					})
				}
				else {
					wx.showModal({
						title: '提示',
						content: '操作成功',
						showCancel: false,
						success: setTimeout(function () {
							wx.switchTab({
								url: "/pages/purchase/purchase"
							})
						}, 1000)
					})
				}
			}
		})
	}
})
