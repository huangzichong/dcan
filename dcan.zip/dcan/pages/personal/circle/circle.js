var util = require('../../../utils/util.js')
var MD5Util = require('../../../utils/md5.js');
var app = getApp();
Page({
  data: {
    src:'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJrXzp40cuBgZgPf1LVbm12OwMoqP7eNecktvOlSIUJ98LTTTOCjdANFcBDLTxuzcT2cAOgMMVeOA/0',
    opacity:0,
    left:0,
    num:'',
    page:0,
    article:[],
    releaseFocus: false,//提问
    release:false,//回复
    text:'',
    noteMaxLen: 70,//备注最多字数
    noteNowLen: 0,//备注当前字数
    option:[
      ['复制','删除','翻译'],
      ['复制', '翻译'],
    ],
    lock:false,
    userName:'',
    fc:'',
    gz:'',
  },
  //
  onLoad: function (options) {
    var userId = app.globalData.userId;
    if (options.userId){
      userId = options.userId;
    }
    var that = this
    that.article()
    that.user(userId);
  },
  //拿到经纬度
  onReady: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        that.setData({
          latitude: latitude,
          longitude: longitude,
        })
      },
      fail: function (res) {

      },
    })
  },
  //下拉  
  onPullDownRefresh: function () {
    var that = this
    that.setData({
      page:0,
    })
    this.article();
  }, 
  //上拉  
  onReachBottom: function () {
    this.article();
  },
  //跳转
  Jump:function(e){
    var user_id = e.currentTarget.dataset.userid;
    var userId = app.globalData.userId;
    wx.navigateTo({
      url: '../../../pages/personal/circle/circle?userId=' + user_id
    })
  },
  //用户
  user: function (userId){
    var that = this
    wx.request({
      url: 'https://www.aftdc.com/wxapp/Service/user',
      method: 'post',
      data: {
        userId: userId,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success:function(res){
        that.setData({
          fc:res.data.fc,
          gz: res.data.gz,
          userName: res.data.userName,
        })
      }
    })
  },
  //数据
  article:function(){
    var that = this
    var userId = app.globalData.userId;
    var page = that.data.page
    console.log(page)
    wx.request({
      url: 'https://www.aftdc.com/wxapp/Service/circle',
      method:'post',
      data:{
        userId: userId,
        page: page,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success:function(res){
        if(res.data.res == 1){
          var article = that.data.article.concat(res.data.Visible);
          that.setData({
            article: article,
            page: page + res.data.Visible.length,
          })
        }
      }
    })
  },
  //页面
  home:function(e){
    var that = this;
    //检查锁
    if (that.data.lock) {
      that.setData({
        lock: false,
      })
      return;
    }
    var article = that.data.article;
    for (var i = 0; i < article.length; i++) {
      if (article[i]['interflow']) {
        for (var p = 0; p < article[i]['interflow'].length; p++) {
            article[i]['interflow'][p]['option'] = 0
        }
      }
    }
    that.setData({
      article: article,
    })
  },
  //长按
  longtap: function (e) {
    var that = this
    var id = e.currentTarget.dataset.id;
    var user_id = e.currentTarget.dataset.userid;
    var dongtai_id = e.currentTarget.dataset.dongtai;
    var userId = app.globalData.userId
    var article = that.data.article;
    for (var i = 0; i < article.length; i++) {
      if (article[i]['interflow']){
        for (var p = 0; p < article[i]['interflow'].length; p++) {
          if (article[i]['interflow'][p]['id'] == id) {
            if (userId == user_id) {
              article[i]['interflow'][p]['option'] = 1
            } else {
              article[i]['interflow'][p]['option'] = 2
            }
          }
        }
      }
    }
    that.setData({
      article: article,
      lock: true,
      id: id,
      dongtai_id: dongtai_id,
    })
  },
  //删除
  del: function (e){
    var that = this
    var name = e.currentTarget.dataset.name;
    if (name !='删除'){
      return false
    }
    var id = that.data.id;
    var dongtai_id = that.data.dongtai_id;
    var article = that.data.article;
    wx.request({
      url: 'https://www.aftdc.com/wxapp/Service/flow_del',
      method:'post',
      data:{
        id: id,
        dongtai_id: dongtai_id,
      },
      success:function(res){
        if (res.data.res == 1) {
          if (res.data.interflow) {
            for (var i = 0; i < article.length; i++) {
              if (article[i]['id'] == dongtai_id) {
                article[i]['interflow'] = res.data.interflow
              }
            }
          } else {
            for (var i = 0; i < article.length; i++) {
              if (article[i]['id'] == dongtai_id) {
                delete (article[i]['interflow'])
              }
            }
          }
          that.setData({
            article: article,
          })
        }
      }
    })
  },
  //交流
  interflow:function(e){
    var that = this
    var id = e.currentTarget.dataset.id;
    var user_id = e.currentTarget.dataset.userid;
    var userId = 22
    if (userId == user_id){
      return false
    }
    that.setData({
      release:true,
      id: id,
      user_id: user_id,
    })
  },
  //回复
  message_B:function(){
    var that = this;
    var id = that.data.id;
    var user_id = that.data.user_id;
    var text = that.data.text;
    var userId = 22
    if (!text) {
      return false
    }
    var article = that.data.article;
    wx.request({
      url: 'https://www.aftdc.com/wxapp/Service/flow_message',
      method:'post',
      data: {
        userId: userId,
        id: id,
        text: text,
        user_id: user_id,
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        if (res.data.res == 1) {
          for (var i = 0; i < article.length; i++) {
            if (article[i]['id'] == id) {
              console.log(1)
              article[i]['interflow'].push(res.data.interflow)
            }
          }
          var setMessage = {
            text: that.data.userMessage
          }
          that.setData(setMessage)
          that.setData({
            article: article,
            text: '',
            release: false,
            noteNowLen: 0,
          })
        }
      }
    })
  },
  //留言
  message: function () {
    var that = this;
    var id = that.data.id;
    var text = that.data.text;
    if(!text){
      return false
    }
    var userId = app.globalData.userId;
    var article = that.data.article;
    wx.request({
      url: 'https://www.aftdc.com/wxapp/Service/flow_message',
      method:'post',
      data:{
        userId: userId,
        id: id,
        text: text,
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success:function(res){
        if(res.data.res == 1){
          for (var i = 0; i < article.length; i++) {
            if (article[i]['id'] == id) {
              if (article[i]['interflow']){
                article[i]['interflow'].push(res.data.interflow)
              } else {
                var interflow = [];
                interflow.push(res.data.interflow)
                article[i]['interflow'] = interflow
              }
            }
          }
          var setMessage = {
            text: that.data.userMessage
          }
          that.setData(setMessage)
          that.setData({
            article: article,
            text:'',
            releaseFocus:false,
            noteNowLen: 0,
          })
        }
      }
    })
  },
  //字数改变触发事件
  bindTextAreaChange: function (e) {
    var that=this; 
    var value = e.detail.value, len = parseInt(value.length);
    if (len > that.data.noteMaxLen){
      return;
    }
    that.setData({
      text: value, noteNowLen: len
    })
  },
  //点赞
  praise:function(e){
    var that = this
    var id = e.currentTarget.dataset.id;
    var userId = app.globalData.userId
    var article = that.data.article;
    wx.request({
      url: 'https://www.aftdc.com/wxapp/Service/praise',
      method:'post',
      data:{
        userId: userId,
        id:id,
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success:function(res){
        if(res.data.res == 1){
          var like = res.data.like;
          if (like == 0){
            for (var i = 0; i < article.length; i++) {
              if (article[i]['id'] == id) {
                delete (article[i]['userlike'])
              }
            }
          } else {
            for (var i = 0; i < article.length; i++) {
              if (article[i]['id'] == id) {
                article[i]['userlike'] = res.data.userlike;
              }
            }
          }
          that.setData({
            article: article,
          })
        }
      }
    })
  },
  //点击回复
  bindReply: function (e) {
    var id = e.currentTarget.dataset.id;
    this.setData({
      releaseFocus: true,
      id: id
    })
  },
  //点击放大图片
  enlargeImg: function (e) {
    console.log(e)
    var src = e.currentTarget.dataset.src;
    var index = e.currentTarget.dataset.index;
    var txt = e.currentTarget.dataset.txt;
    // if (txt != 'img') {
    var srcs = []
    for (var i in src) {
      var img = src[i][txt]
      var obj = { img: img }
      srcs.push(obj)
    }
    src = srcs
    // }
    this.setData({
      enlargeSrc: src,
      enlargeBox: true,
      enlargeNumb: index,
    })
  },
  //关闭图片
  enlargeClose: function (e) {
    this.setData({
      enlargeBox: false,
    })
  },
  //发布动态
  comeOn:function(){
    wx.showModal({
        title: '提示',
        content: '请下载阿凡提点餐APP',
        showCancel:false
    })
  },
  focus: function () {
      this.setData({
          releaseFocus: !this.data.releaseFocus
      })
  },
})