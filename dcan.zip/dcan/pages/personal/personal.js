var app = getApp()
var MD5Util = require('../../utils/md5.js');
Page({
	data: {
	},
	onShow: function () {
		var vip_grade = this.data.vip_grade
		var userInfo = app.globalData.usersInfo
		if (vip_grade && userInfo) {
			for (var i in vip_grade) {
				if (userInfo.spend >= vip_grade[i].val) {
					var grade = vip_grade[i].grade
					this.setData({
						userName: userInfo.userName,
						userPhoto: userInfo.userPhoto,
						userPhone: userInfo.userPhone,
						grade: grade
					})
					break;
				}
			}
			//红点
			var usersInfo = wx.getStorageSync('usersInfo')
			if (usersInfo.notReadMessage.activity + usersInfo.notReadMessage.article + usersInfo.notReadMessage.system > 0) {
				this.setData({
					redDot: true
				})
			} else {
				this.setData({
					redDot: false
				})
				wx.hideTabBarRedDot({
					index: 3,
				})
			}
		}
	},
	onReady: function () {
		var that = this
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Adduser/vip_grade',
			header: {
				'content-type': 'application/x-www-form-urlencoded'
			},
			success: function (res) {
				that.data.vip_grade = res.data.data
				that.onShow()
			}
		})
	},
	block: function (e) {
		var usersInfo = wx.getStorageSync('usersInfo')
		var route = e.currentTarget.dataset.url;
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			return false
		} else {
			if (route == 'goSet') {
				var url = '../packageA/pages/phone/phone?type=1'
			} else if (route == 'fapiao') {
				var url = './invoice/invoice'
			} else if (route == 'cooperation') {
				var url = '../packageA/pages/phone/phone?type=2'
			} else if (route == 'coupon') {
				var url = 'coupon/coupon'
			} else if (route == 'integral') {
				var url = 'integral/integral'
			} else if (route == 'recharge') {
				var url = 'recharge/recharge'
			} else if (route == 'myvip') {
				var url = 'myvip/myvip'
			} else if (route == 'attention') {
				var url = 'attention/attention'
			} else if (route == 'collect') {
				var url = 'collect/collect'
			} else if (route == 'shield') {
				var url = 'shield/shield'
			} else if (route == 'history') {
				var url = 'history/history'
			} else if (route == 'wallet') {
				var url = 'wallet/wallet'
			} else if (route == 'news') {
				var url = 'news/news'
            } else if (route == 'friend'){
                var url = 'circle/circle'
            }
			wx.navigateTo({
				url: url
			})
		}
	},
	info: function (e) {
		var nickName = this.data.userInfo.userName
		var imagesrc = this.data.userInfo.userPhoto
		wx.navigateTo({
			url: 'info/info?nickName=' + nickName + '&&imagesrc=' + imagesrc,
		})
	},
	//login
	login: function () {
		wx.navigateTo({
			url: '/pages/author/author',
		})
	},
	app: function () {
		wx.navigateTo({
			url: 'download/download'
		})
	},
	//扫码点餐
	sys: function () {
		wx.scanCode({
			success: (res) => {
				wx.navigateTo({
					url: '../../' + res.path,
				})
			}
		})
	}
})
