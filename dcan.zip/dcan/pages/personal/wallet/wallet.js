var app = getApp();
var MD5Util = require('../../../utils/md5.js');
Page({

	data: {
		bullet: [],
		choose:0,
		currentTab:0
	},

	onLoad: function (options) {

		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		var that = this
		wx.getSystemInfo({
			success: function (res) {
				that.setData({
					windowHeight: res.windowHeight
				})
			}
		});
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Asset/bullet',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: "POST",
			success: function (res) {
				if (res.data.res==1)
					that.setData({ 'bullet': res.data.data })
				else {
					wx.showToast({
						title: '出错了',
						icon: 'loading',
						duration: 1000,
						mask: true
					})
				}
			}
		})
	},

	//领券中心
	coupon: function () {
		wx.navigateTo({
			url: '/pages/personal/coupon/coupon',
		})
	},
	//打开隐藏款
	openHid: function (e) {
		var hid = e.currentTarget.dataset.hid;
		if (hid == 1) {
			this.setData({
				hid1: true
			})
		} else if (hid == 2) {
			this.setData({
				hid2: true
			})
		} else if (hid == 3) {
			this.setData({
				hid3: true
			})
		}
	},
	//隐藏
	hid: function () {
		this.setData({
			hid1: false,
			hid2: false,
			hid3: false
		})
	},
	//去店铺
	toShop:function(e){
		var shopId = e.currentTarget.dataset.id;
		wx.navigateTo({
			url: '/pages/introduce/introduce?shopId='+shopId,
		})
	},
	// 滚动切换标签样式
	switchTab: function (e) {
		this.setData({
			currentTab: e.detail.current,
			choose: e.detail.current
		});
	},
	// 点击标题切换当前页时改变样式
	swichNav: function (e) {
		var cur = e.currentTarget.dataset.choose;
		if (this.data.currentTab == cur) { return false; }
		else {
			this.setData({
				currentTab: cur,
				choose: cur
			})
		}
	},
	
})