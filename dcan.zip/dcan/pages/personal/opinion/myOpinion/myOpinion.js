var app = getApp()
var MD5Util = require('../../../../utils/md5.js');
Page({

	data: {
		clasData: ["配送问题", "投诉业务经理", "功能改善建议", "其他问题"],
		userId: app.globalData.userId,
		feedback: 0,
		feedbackList: ''
	},


	onLoad: function () {
		var that = this

		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
      url: 'https://www.aftdc.com/wxapp/Service/me_list',
			data: {
				userId: app.globalData.userId,
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token
			},
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
			method: "POST",
			success: function (res) {
				if (res.data.res == 1) {
					that.setData({ feedback: 1 });
					that.setData({ feedbackList: res.data.data });
				}
			}
		})
	},
})