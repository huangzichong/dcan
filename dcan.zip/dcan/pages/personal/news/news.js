var MD5Util = require('../../../utils/md5.js')
var app = getApp();
var util = require('../../../utils/util.js')

Page({

    data: {
        currentTab: 0, //预设当前项的值
        scrollLeft: 0, //tab标题的滚动条位置
        onreachBottom: true,
        cur: 0,
        activityPage: 0,
        articlePage: 0,
        sysPage: 0,
        box: 0,
        boxDetail: [],
        num: '',//上一个状态
    },
    onLoad: function () {
        var that = this

        wx.getSystemInfo({
            success: function (res) {
                that.setData({
                    windowHeight: res.windowHeight
                })
            }
        });


        var timestamp = (Date.parse(new Date())) / 1000
        var sign = MD5Util.sign(timestamp)
        wx.request({
            url: 'https://www.aftdc.com/wxapp/Mine/MessageBegin',
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            data: {
                sign: sign,
                timestamp: timestamp,
                token: app.globalData.usersInfo.token,
                currentTab: that.data.currentTab
            },
            success: function (res) {
                that.setData({
                    activity: res.data.data.activity,
                    article: res.data.data.article,
                    sys: res.data.data.sys,
                    activityPage: res.data.data.activity.length,
                    articlePage: res.data.data.article.length,
                    sysPage: res.data.data.sys.length,
                })
            }
        })

        //显示红点
        var usersInfo = wx.getStorageSync('usersInfo')
        if (usersInfo.notReadMessage.activity > 0) {
            that.setData({ hdredDot: true })
            //that.hidRed(0)			
        }
        if (usersInfo.notReadMessage.article > 0) {
            that.setData({ wzredDot: true })
        }
        if (usersInfo.notReadMessage.system > 0) {
            that.setData({ xtredDot: true })
        }
    },

    onReady: function () {
        var that = this
        wx.getSystemInfo({
            success: function (res) {
                that.setData({
                    windowHeight: res.windowHeight
                })
            }
        });
    },
    // 滚动切换标签样式
    switchTab: function (e) {
        this.setData({
            currentTab: e.detail.current
        });
        //	this.hidRed(e.detail.current)
    },
    // 点击标题切换当前页时改变样式
    swichNav: function (e) {
        var cur = e.target.dataset.current;
        if (this.data.currentTaB == cur) { return false; }
        else {
            this.setData({
                currentTab: cur
            })
            //this.hidRed(e.target.dataset.current)					
        }
    },
    //隐藏红点
    hidRed: function (index) {
        var usersInfo = wx.getStorageSync('usersInfo')
        if (index == 0) {
            if (usersInfo.notReadMessage.activity > 0) {
                usersInfo.notReadMessage.activity = 0
                wx.setStorageSync('usersInfo', usersInfo)
                this.setData({ hdredDot: false })
                var types = 'activity'
                this.markRedDot(types)
            }
        } else if (index == 1) {
            if (usersInfo.notReadMessage.article > 0) {
                usersInfo.notReadMessage.article = 0
                wx.setStorageSync('usersInfo', usersInfo)
                this.setData({ wzredDot: false })
                var types = 'article'
                this.markRedDot(types)
            }
        } else if (index == 2) {
            if (usersInfo.notReadMessage.system > 0) {
                usersInfo.notReadMessage.system = 0
                wx.setStorageSync('usersInfo', usersInfo)
                this.setData({ xtredDot: false })
                var types = 'system'
                this.markRedDot(types)
            }
        }
    },
    //记录已查看
    markRedDot: function (e) {
        var timestamp = (Date.parse(new Date())) / 1000
        var sign = MD5Util.sign(timestamp)
        wx.request({
            url: 'https://www.aftdc.com/wxapp/Mine/read_tuisong',
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            data: {
                type: e,
                sign: sign,
                timestamp: timestamp,
                token: app.globalData.usersInfo.token,
            },
            success: function (res) {

            }
        })
    },

    onreachBottom: function () {
        var num = this.data.num;//上一个状态
        if (num != this.data.currentTab) {
            this.data.onreachBottom = true
        }
        if (this.data.onreachBottom) {
            this.setData({
                more: true,
                num: this.data.currentTab,
            })
            this.data.onreachBottom = false
            var that = this
            var timestamp = (Date.parse(new Date())) / 1000
            var sign = MD5Util.sign(timestamp)
            var page = 0

            if (that.data.currentTab == 0)
                page = that.data.activityPage
            if (that.data.currentTab == 1)
                page = that.data.articlePage
            if (that.data.currentTab == 2)
                page = that.data.sysPage
                
            wx.request({
                url: 'https://www.aftdc.com/wxapp/Mine/Message',
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                data: {
                    sign: sign,
                    timestamp: timestamp,
                    token: app.globalData.usersInfo.token,
                    currentTab: that.data.currentTab,
                    page: page
                },
                success: function (res) {
                    if (res.data.res) {
                        if (that.data.currentTab == 0) {
                            that.setData({
                                activity: that.data.activity.concat(res.data.data),
                                activityPage: that.data.activityPage + res.data.data.length
                            })
                        }
                        if (that.data.currentTab == 1) {
                            that.setData({
                                article: that.data.article.concat(res.data.data),
                                articlePage: that.data.articlePage + res.data.data.length
                            })
                        }
                        if (that.data.currentTab == 2) {
                            that.setData({
                                sys: that.data.sys.concat(res.data.data),
                                sysPage: that.data.sysPage + res.data.data.length
                            })
                        }
                        that.data.onreachBottom = true
                    }
                }

            })

        }
    },
    jump: function (e) {
        var shopId = e.currentTarget.dataset.shopid
        var typess = e.currentTarget.dataset.type
        var messageId = e.currentTarget.dataset.messageid
        var type = 1
        var timestamp = (Date.parse(new Date())) / 1000
        var sign = MD5Util.sign(timestamp)
        var index = e.currentTarget.dataset.index
        var usersInfo = wx.getStorageSync('usersInfo')
        if (usersInfo.notReadMessage.activity + usersInfo.notReadMessage.article + usersInfo.notReadMessage.system > 0) 
        var that = this
        if ((typess == 'activity' && this.data.activity[index].readed == 0) || (typess == 'article' && this.data.article[index].readed == 0)) {
            wx.request({
                url: 'https://www.aftdc.com/wxapp/Mine/read_tuisong',
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                data: {
                    sign: sign,
                    timestamp: timestamp,
                    token: app.globalData.usersInfo.token,
                    messageId: messageId,
                    type: type
                },
                success: function (res) {
                    if (typess == 'activity') {
                        that.data.activity[index].readed = 1;
                        that.setData({ activity: that.data.activity })
                        usersInfo.notReadMessage.activity = usersInfo.notReadMessage.activity - 1
                        wx.setStorageSync('usersInfo', usersInfo)
                    }
                    if (typess == 'article') {
                        that.data.article[index].readed = 1;
                        that.setData({ article: that.data.article })
                        usersInfo.notReadMessage.article = usersInfo.notReadMessage.article - 1
                        wx.setStorageSync('usersInfo', usersInfo)
                    }
                }
            })
        }
        wx.navigateTo({
            url: '/pages/order/order?shopId=' + shopId,
        })

    },
    box: function (e) {
        var that = this
        var messageId = e.currentTarget.dataset.messageid
        var index = e.currentTarget.dataset.index
        var list = this.data.sys;
        var detail = this.data.sys[index]
        var type = 2

        if (that.data.sys[index].readed == 0) {
            var timestamp = (Date.parse(new Date())) / 1000
            var sign = MD5Util.sign(timestamp)
            wx.request({
                url: 'https://www.aftdc.com/wxapp/Mine/read_tuisong',
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                data: {
                    sign: sign,
                    timestamp: timestamp,
                    token: app.globalData.usersInfo.token,
                    messageId: messageId,
                    type: type
                },
                success: function (res) {
                    that.data.sys[index].readed = 1;
                    that.setData({ sys: that.data.sys })
                    usersInfo.notReadMessage.system = usersInfo.notReadMessage.system - 1
                    wx.setStorageSync('usersInfo', usersInfo)
                }
            })
        }
        this.setData({ boxDetail: detail, box: 1 })

    },
    cancelbox: function () {
        this.setData({ box: 0 })
    },

    delMessage: function (e) {
        var index = e.currentTarget.dataset.index
        var type = e.currentTarget.dataset.type
        var messageId = e.currentTarget.dataset.messageid
        var y = ''
        var that = this
        wx.showModal({
            title: '提示',
            content: '删除该消息',
            success: function (res) {
                if (res.confirm) {
                    if (type == 'article' || type == 'activity') {
                        y = 1
                    }
                    else {
                        y = 2
                    }
                    var timestamp = (Date.parse(new Date())) / 1000
                    var sign = MD5Util.sign(timestamp)
                    wx.request({
                        url: 'https://www.aftdc.com/wxapp/Mine/delMessage',
                        header: {
                            "Content-Type": "application/x-www-form-urlencoded"
                        },
                        method: "POST",
                        data: {
                            sign: sign,
                            timestamp: timestamp,
                            token: app.globalData.usersInfo.token,
                            messageId: messageId,
                            type: y
                        },
                        success: function (res) {
                            if (type == 'article') {
                                that.data.article.splice(index, 1);
                                that.setData({ article: that.data.article })
                            }
                            if (type == 'activity') {
                                that.data.activity.splice(index, 1);
                                that.setData({ activity: that.data.activity })
                            }
                            if (type == 'sys') {
                                that.data.sys.splice(index, 1);
                                that.setData({ sys: that.data.sys })
                            }
                        }
                    })

                }
            }
        })
    }
})