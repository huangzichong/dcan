var app = getApp()
var util = require('../../utils/util.js')
var MD5Util = require('../../utils/md5.js');
var authorization = require('../../utils/authorization.js')
Page({
	data: {
		userInfo: {},
		longitude: "",
		latitude: "",
		searchw: '',
		price: '',
		time: '',
		nothing: true,
		shops: true,
		commercial: true,
		allChoice: false,//综合排序和筛选选择框是否显示
		cuisineId: 0,
		chooseHobby1: [
			{ name: '配送时间长', sel: false, id: 1 },
			{ name: '包装差', sel: false, id: 5 },
			{ name: '价格偏高', sel: false, id: 2 },
			{ name: '分量不足', sel: false, id: 6 },
			// { name: '不想看·', sel: false, id: 3 },
			{ name: '关注商家', sel: false, id: 10 },
			// { name: '屏蔽商家', sel: false, id: 4 }
		],
		chooseHobby2: [
			{ name: '吃过了', sel: false, id: 7 },
			{ name: '环境不好', sel: false, id: 8 },
			{ name: '价格偏高', sel: false, id: 2 },
			{ name: '服务态度不好', sel: false, id: 9 },
			// { name: '不想看·', sel: false, id: 3 },
			{ name: '关注商家', sel: false, id: 10 },
			// { name: '屏蔽商家', sel: false, id: 4 }
		],
		sortChoice: [
			{ name: '评分最高', ok: false, id: 3 },
			{ name: '起送价最低', ok: false, id: 4 },
			{ name: '配送费最低', ok: false, id: 5 }
		],
		sortChoiceId: '',
		choiceId: -1,
		query: {},//查询的内容
		termActivity: [
			{ title: '减', titleColor: 'ff4040', name: '满减优惠', ok: false, shopType: 22 },
			{ title: '领', titleColor: 'aa135f', name: '进店领券', ok: false, shopType: 24 },
			{ title: '折', titleColor: 'F4A460', name: '折扣商品', ok: false, shopType: 25 },
			{ title: '新', titleColor: '06c1ae', name: '新客立减', ok: false, shopType: 23 },
			{ title: '团', titleColor: '1988f9', name: '团购活动', ok: false, shopType: 21 },
			{ title: '砍', titleColor: 'ADFF2F', name: '砍价活动', ok: false, shopType: 28 },
			{ title: '秒', titleColor: '029900', name: '秒杀商品', ok: false, shopType: 27 },
			{ title: '红', titleColor: 'ff4040', name: '商家红包', ok: false, shopType: 30 },
		],
		history: true,
		search: false,//商品页和搜索页显示隐藏
		query: {},//综合排序，销量，距离，筛选 所需要查询的数据存储的名称
		loading: false,
		addclass: "正在定位...",
		positionAllow: false,
		code: 100,//天气图标
		recommendState: true,//推荐商品隐藏
		shopType: 0,
		orderbyarr: "",
		conditionArr: []
	},
	//事件处理函数
	bindViewTap: function () {
		wx.navigateTo({
			url: '../logs/logs'
		})
	},
	onMessage: function (res) {
		this.setData({ data: res.data });
	},
	//点击首页时刷新数据
	// onTabItemTap(item) {
	// 	wx.startPullDownRefresh()
	// },
	onReady: function () {
		wx.showNavigationBarLoading()
		var that = this
		wx.getLocation({
			type: 'gcj02',
			success: function (res) {
				var latitude = res.latitude
				var longitude = res.longitude
				var location = {}
				location.longitude = longitude
				location.latitude = latitude
				that.setData({
					latitude: latitude,
					longitude: longitude,
					location: location,
					backcolor: 1,
					nothing: true
				})
				wx.setStorageSync('shopType', '1')
				wx.setStorageSync('orderType', '0')
				that.getShop(latitude, longitude)
				// that.webs()
				app.globalData.location = location
			},
		})
	},
	//根据经纬度和用户id获取首页信息
	getShop: function (latitude, longitude) {

		var userId = app.globalData.userId
		if (!userId) userId = -1
		var that = this
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Index/index',
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			data: {
				userId: userId,
				longitude: longitude,
				latitude: latitude,
				page: 0
			},
			method: "POST",
			success: function (res) {
				wx.hideNavigationBarLoading()
				if (userId != -1) {
					var usersInfo = wx.getStorageSync('usersInfo')
					if (usersInfo.notReadMessage.activity + usersInfo.notReadMessage.article + usersInfo.notReadMessage.system > 0) {
						// wx.showTabBarRedDot({
						// 	index: 3,
						// })
					}
				}
                var shops = res.data.shops
                for (var i in shops) { //单位换算
                    if (parseFloat(shops[i].distance) > 0 && parseFloat(shops[i].distance) < 1000) {
                        shops[i].distances = shops[i].distance + 'm'
                    } else if (parseFloat(shops[i].distance) == 0) {
                        shops[i].distances = '1m'
                    } else {
                        shops[i].distances = parseFloat(shops[i].distance / 1000).toFixed(1) + 'km'
                    }
                }


				if (res.data.openCity == 0) {
					that.setData({
						openCity: 0,
                        shops: res.data.shops,
						loading: true,
						nothing: false,
						weather: res.data.weather,
						addclass: res.data.addclass,//详细地址
                        orders:[]
					})
				} else {
					if (res.data.orders) {
						var orders = util.shijian(new Date, res.data.orders)
					}
					var len = res.data.shops.length;
					var commercial = res.data.commercial;//广告
					if (commercial != 0) {
						for (var i in commercial) { //单位换算
							if (parseFloat(commercial[i].distance) > 0 && parseFloat(commercial[i].distance) < 1000) {
								commercial[i].distances = commercial[i].distance + 'm'
							} else if (parseFloat(commercial[i].distance) == 0) {
								commercial[i].distances = '1m'
							} else {
								commercial[i].distances = parseFloat(commercial[i].distance / 1000).toFixed(1) + 'km'
							}
						}
						var one = commercial[0];
						commercial.splice(0, 1)

						if (len == 4) {
							shops.push(one)
						}
					}
					that.setData({
                        openCity: 1,
						shopType: 1,//默认外卖
						shops: shops,
						page: len,
						loading: true,
						cat: res.data.cat,
						city: res.data.city,
						catChild: res.data.cat[0]['child'],
                        orders: orders,
						weather: res.data.weather,
						addclass: res.data.addclass,//详细地址
						sort: null,
						commercial: commercial,
					})
					app.globalData.addclass = that.data.addclass
				}
			}
		})
	},
	onLoad: function () {
		var that = this
		wx.getSetting({
			success(res) {
				if (!res.authSetting['scope.userLocation']) {
					that.setData({
						positionAllow: true,
					})
				}
			}
		})
	},

	/*上拉加载*/
	onReachBottom: function () {
		if (this.data.nothing) {
			this.setData({
				more: true
			})
			wx.showNavigationBarLoading()
			var conditionArr = JSON.stringify(this.data.conditionArr)
			var that = this;
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/index/getShops',
				data: {
					userId: app.globalData.userId,
					longitude: that.data.longitude,
					latitude: that.data.latitude,
					page: that.data.page,
					city: that.data.city,
					conditionArr: conditionArr
				},
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				method: "POST",
				success: function (res) {
					wx.hideNavigationBarLoading()
					if (res.data.res == 1) {
						var shops = res.data.shops
						for (var i in shops) { //单位换算
							if (parseFloat(shops[i].distance) > 0 && parseFloat(shops[i].distance) < 1000) {
								shops[i].distances = shops[i].distance + 'm'
							} else if (parseFloat(shops[i].distance) == 0) {
								shops[i].distances = '1m'
							} else {
								shops[i].distances = parseFloat(shops[i].distance / 1000).toFixed(1) + 'km'
							}
						}
						var len = res.data.shops.length;
						var commercial = that.data.commercial;//广告
						if (commercial != 0) {
							for (var i in commercial) { //单位换算
								if (parseFloat(commercial[i].distance) > 0 && parseFloat(commercial[i].distance) < 1000) {
									commercial[i].distances = commercial[i].distance + 'm'
								} else if (parseFloat(commercial[i].distance) == 0) {
									commercial[i].distances = '1m'
								} else {
									commercial[i].distances = parseFloat(commercial[i].distance / 1000).toFixed(1) + 'km'
								}
							}
							var one = commercial[0];
							commercial.splice(0, 1)

							if (len == 4) {
								shops.push(one)
							}
						}
						that.setData({
							shops: that.data.shops.concat(shops),
							page: that.data.shops.concat(shops).length,
							more: false
						})
					} else {
						that.setData({
							nothing: false,
							more: false
						})
					}
				}
			})
		}
	},
	// 下拉加载
	onPullDownRefresh: function (e) {
	  //this.onReady()
        wx.setStorageSync('shopType', '1')
        wx.setStorageSync('orderType', '0')
        this.getShop(this.data.latitude, this.data.longitude)
		this.data.conditionArr = []
		this.setData({
			searchw: ''
		})
		wx.hideNavigationBarLoading() //完成停止加载
		wx.stopPullDownRefresh() //停止下拉刷新
	},

	//搜索页面
	focus_search: function () {
		var current = { shopType: this.data.shopType, city: this.data.city, conditionArr: this.data.conditionArr, searchHistory: this.data.searchHistory }
		wx.navigateTo({
			url: '../search/search?current=' + JSON.stringify(current),
		})
	},

	back: function () {
		this.setData({
			search: false,
			searchw: '',
		})
	},
	recommendClose: function () {
		this.setData({
			recommendState: true
		})
	},
	//选择坐标查看
	choose: function () {
		var that = this
		that.again()
		wx.chooseLocation({
			success: function (res) {
				that.setData({
					addclass: res.address,
                    longitude: res.longitude,
                    latitude: res.latitude
				})
				var location = {}
				location.longitude = res.longitude
				location.latitude = res.latitude
				app.globalData.location = location
				that.getShop(res.latitude, res.longitude)
			}
		})
	},
	//如果没有授权重新获取授权
	again: function () {
		var that = this
		wx.getSetting({
			success(res) {
				if (!res.authSetting['scope.userLocation']) {
					wx.openSetting({
						success: (res) => {
							that.onLoad()
							res.authSetting = {
								"scope.userLocation": true,
								positionAllow: false,
							}
						}
					})
					return false
				}
			}
		})
	},
	onShareAppMessage: function () {
		return {
			title: '阿凡提智慧点餐',
			path: '/pages/Index/index',
			success: function (res) {
				// 分享成功
			}
		}
	},
	//弹出活动标签
	project: function (e) {
		var index = e.currentTarget.dataset.index;
		var shops = this.data.shops
		var projectLay = shops[index].projectLay
		if (Boolean(projectLay)) {
			shops[index].projectNum = projectLay
			shops[index].projectLay = false
		} else {
			shops[index].projectLay = shops[index].projectNum
			shops[index].projectNum = 100
		}
		this.setData({
			shops: shops,
		})
	},

	gator: function (e) {
		//1外卖 2堂食 3到店 4免配送 5优质商家 21团购 26代金券 28砍价 27秒杀   30商家红包
		var shopId = e.currentTarget.dataset.shopid;
		var distance = e.currentTarget.dataset.distance;
		var gz = e.currentTarget.dataset.gz;
		var that = this;
		var shopType = that.data.shopType
		if (gz == 1) {
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			var userId = app.globalData.userId;
			wx.request({
				url: 'https://www.aftdc.com/wxapp/index/commercial_name',
				method: 'post',
				header: {
					"Content-Type": "application/x-www-form-urlencoded"
				},
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					userId: userId,
					shopId: shopId,
				},
				success: function (res) {
					if (res.data.res != 1) {
						wx.showToast({
							title: res.data.info,
							icon: 'loading',
							duration: 1000
						});
						return false
					} else {
						wx.setStorageSync('shopType', shopType)
						if (shopType == 5 || shopType == 21 || shopType == 26) {
							wx.navigateTo({
								url: '../introduce/introduce?shopId=' + shopId + '&distance=' + distance,
							})
						} else {
							wx.navigateTo({
								url: '../order/order?shopId=' + shopId,
							})
						}
					}
				}
			})
		} else {
			wx.setStorageSync('shopType', shopType)
			if (shopType == 5 || shopType == 21 || shopType == 26) {
				wx.navigateTo({
					url: '../introduce/introduce?shopId=' + shopId + '&distance=' + distance,
				})
			} else {
				wx.navigateTo({
					url: '../order/order?shopId=' + shopId,
				})
			}
		}
	},
	//跳转到运动
	sport: function (e) {
		var backcolor = e.currentTarget.dataset.backcolor//只为该变颜色
		wx.navigateTo({
			url: '/pages/sport/sport',
		})
	},
	//城市合伙人
	partnership: function () {
		wx.navigateTo({
			url: '../packageA/pages/phone/phone?type=2',
		})
	},
	close: function () {
		this.setData({
			conpouBox: false
		})
	},
	//下拉标签
	closeHobby: function (e) {
		var index = e.currentTarget.dataset.index;
		var shops = this.data.shops
		var closeHobby = shops[index].closeHobby
		for (var i in shops) {
			shops[i].closeHobby = false
		}
		// var chooseHobby1 = this.data.chooseHobby1
		// for (var i in chooseHobby1) {
		// 	chooseHobby1[i].sel = false
		// } 
		// var chooseHobby2 = this.data.chooseHobby2
		// for (var i in chooseHobby2) {
		// 	chooseHobby2[i].sel = false
		// } 
		shops[index].closeHobby = !closeHobby
		// if (Boolean(closeHobby)) {
		// 	shops[index].closeHobby = closeHobby
		// 	shops[index].closeHobby = false
		// } else {
		// 	shops[index].closeHobby = shops[index].closeHobby
		// 	shops[index].closeHobby = true
		// }
		this.setData({
			shops: shops,
			// chooseHobby1: chooseHobby1,
			// chooseHobby2: chooseHobby2,
			// chooseH:false
		})
	},
	//选择标签
	// chooseHobby: function (e) {
	// 	//单选
	// 	if (this.data.shopType == 2 || this.data.shopType == 21) {
	// 		var chooseHobby = this.data.chooseHobby2
	// 	} else {
	// 		var chooseHobby = this.data.chooseHobby1
	// 	}

	// 	var index = e.currentTarget.dataset.index
	// 	this.data.cuisineId = e.currentTarget.dataset.id
	// 	this.data.chooseHobbyId = chooseHobby[index]['id']
	// 	for (var i in chooseHobby) {
	// 		if (this.data.chooseHobbyId == chooseHobby[i]['id'] && chooseHobby[i]['sel'] == false) {
	// 			chooseHobby[i]['sel'] = true
	// 		} else {
	// 			chooseHobby[i]['sel'] = false
	// 		}
	// 	}
	// 	for (var i in chooseHobby) {
	// 		if (chooseHobby[i]['sel']) {
	// 			var chooseH = true
	// 			break;
	// 		} else {
	// 			var chooseH = false
	// 		}
	// 	}
	// 	if (this.data.shopType == 2 || this.data.shopType == 21) {
	// 		this.setData({
	// 			chooseH: chooseH,
	// 			chooseHobby2: chooseHobby,
	// 			chooseHobbyId: this.data.chooseHobbyId
	// 		})
	// 	} else {
	// 		this.setData({
	// 			chooseH: chooseH,
	// 			chooseHobby1: chooseHobby,
	// 			chooseHobbyId: this.data.chooseHobbyId
	// 		})
	// 	}

	// },
	// sureReason: function (e) {
	// 	var that = this
	// 	wx.getSetting({
	// 		success(res) {
	// 			if (!res.authSetting['scope.userInfo']) {//如果没登录
	// 				wx.navigateTo({
	// 					url: '../author/author',
	// 				})
	// 				return false
	// 			}else{
	// 				var shopId = e.currentTarget.dataset.id
	// 				var index = e.currentTarget.dataset.index
	// 				var shops = that.data.shops
	// 				var chooseHobbyId = that.data.chooseHobbyId
	// 				var cuisineId = that.data.cuisineId

	// 				if (chooseHobbyId == 10) { //关注 和 取消关注
	// 					var shopId = shops[index]['shopId']
	// 					shops[index].closeHobby = false
	// 					if (shops[index]['attentionType'] == 1) {
	// 						that.cancelAttention()
	// 						shops[index]['attentionType'] = 0
	// 						that.setData({
	// 							hobbyTip: true,
	// 							hobbyTips: '已取消关注',
	// 							shops: shops
	// 						})
	// 						setTimeout(function () {
	// 							that.setData({
	// 								hobbyTip: false
	// 							})
	// 						}, 5000)
	// 						return false
	// 					} else {
	// 						that.attention(shopId)
	// 						shops[index]['attentionType'] = 1
	// 						that.setData({
	// 							hobbyTip: true,
	// 							hobbyTips: '你关注的商家发布新的动态时将会推送给你',
	// 							shops: shops
	// 						})
	// 						setTimeout(function () {
	// 							that.setData({
	// 								hobbyTip: false
	// 							})
	// 						}, 5000)
	// 						return false
	// 					}
	// 				}

	// 				shops.splice(index, 1)
	// 				that.setData({
	// 					shops: shops
	// 				})
	// 				var chooseHobbyId = that.data.chooseHobbyId
	// 				var cuisineId = that.data.cuisineId
	//       var timestamp = (Date.parse(new Date())) / 1000
	//       var sign = MD5Util.sign(timestamp)
	// 				wx.request({
	//         url: 'https://www.aftdc.com/wxapp/index/userHobby',
	// 					data: {
	//           sign: sign,
	//           timestamp: timestamp,
	//           token: app.globalData.usersInfo.token,
	// 						userId: app.globalData.userId,
	// 						shopId: shopId,
	// 						chooseHobbyId: chooseHobbyId,
	// 						cuisineId: cuisineId
	// 					},
	// 					header: {
	// 						"Content-Type": "application/x-www-form-urlencoded"
	// 					},
	// 					method: "POST",
	// 					success: function (res) {
	// 						if (res.data.res == 1) {
	// 							that.setData({
	// 								hobbyTip: true
	// 							})
	// 							setTimeout(function () {
	// 								that.setData({
	// 									hobbyTip: false
	// 								})
	// 							}, 5000)
	// 						}
	// 					}
	// 				})
	// 				this.setData({
	// 					hobbyTip: true
	// 				})
	// 			}
	// 		}
	// 	})
	// },
	//不感兴趣
	// notInterest: function (e) {
	// 	var that = this
	// 	wx.getSetting({
	// 		success(res) {
	// 			if (!res.authSetting['scope.userInfo']) {//如果没登录
	// 				wx.navigateTo({
	// 					url: '../author/author',
	// 				})
	// 				return false
	// 			} else {
	// 				var shopId = e.currentTarget.dataset.id
	// 				var index = e.currentTarget.dataset.index
	// 				var shops = that.data.shops
	// 				shops.splice(index, 1)
	// 				that.setData({
	// 					shops: shops
	// 				})
	//       var timestamp = (Date.parse(new Date())) / 1000
	//       var sign = MD5Util.sign(timestamp)
	// 				wx.request({
	//         url: 'https://www.aftdc.com/wxapp/index/userHobby',
	// 					data: {
	//           sign: sign,
	//           timestamp: timestamp,
	//           token: app.globalData.usersInfo.token,
	// 						userId: app.globalData.userId,
	// 						shopId: shopId
	// 					},
	// 					header: { "Content-Type": "application/x-www-form-urlencoded" },
	// 					method: "POST",
	// 					success: function (res) {
	// 						if (res.data.res == 1) {
	// 							that.setData({
	// 								notInterest: true
	// 							})
	// 							setTimeout(function () {
	// 								that.setData({
	// 									notInterest: false
	// 								})
	// 							}, 5000)
	// 						}
	// 					}
	// 				})
	// 			}
	// 		}
	// 	})
	// },
	//打开排序和筛选列表
	openSortbox: function (e) {
		var opentype = e.currentTarget.dataset.id
		//1打开综合排序 2打开筛选
		this.setData({
			opentype: opentype,
			allChoice: true
		})
	},
	//找相似
	lookfor: function (e) {
		var index = e.currentTarget.dataset.index
		var id = this.data.shops[index].cuisineId
		this.data.conditionArr = []
		var cuisineId = { 'cuisineId': id }
		this.data.conditionArr[1] = cuisineId
		this.commentGet()
	},
	//大导航的筛选
	chooseShopType: function (e) {
		var backcolor = e.currentTarget.dataset.backcolor//只为该变颜色
		this.setData({
			backcolor: backcolor
		})
		wx.showNavigationBarLoading()
		//shopType  1外卖 2堂食 3到店 4免配送 5优质商家 21团购 26代金券 28砍价 27秒杀
		var shopType = e.currentTarget.dataset.shoptype
		//orderType 订单类型 0外卖 2扫码点餐 3订座点餐 4团购单 5自取单
		if (shopType == 1) {
			wx.setStorageSync('orderType', '0')
		} else if (shopType == 2) {
			wx.setStorageSync('orderType', '3')
		} else if (shopType == 3) {
			wx.setStorageSync('orderType', '5')
		}
		this.setData({
			shopType: shopType
		})
		var shopType = { 'shopType': shopType }
		this.data.conditionArr[0] = shopType
		this.commentGet()
	},
	//选择菜系
	chooseChild: function (e) {
		var id = e.currentTarget.dataset.id
		var idx = e.currentTarget.dataset.idx
		this.setData({
			cuisineId: id,
			idx: idx
		})
		var cuisineId = { 'cuisineId': id }
		this.data.conditionArr[1] = cuisineId
		// this.commentGet()
	},
	//选择排序
	sortChoice: function (e) {
		var backcolor = e.currentTarget.dataset.backcolor//这里定义backcolor只为了该变选中后的颜色
		//排序sort 1销量最高 2距离最近 3评分最高/优质商家 4起送价最低 5配送费最低 
		var sort = e.currentTarget.dataset.id
		var id = sort
		this.setData({
			//  opentype: sort,
			sort: sort,
			backcolor: backcolor,
			sortid: id
		})
		var sort = { 'sort': sort }
		this.data.conditionArr[2] = sort
		this.paixu()
		this.hiddenChoice()
	},
	//进行排序
	paixu: function () {
		var id = this.data.sortid
		var shops = this.data.shops
		if (shops) {
			shops.sort(function (a, b) {
				if (id == 1) {
					return parseInt(b.sales) - parseInt(a.sales);
				} else if (id == 2) {
					return parseInt(a.distance) - parseInt(b.distance);
				} else if (id == 3) {
					return parseInt(b.shopAvgs) - parseInt(a.shopAvgs);
				} else if (id == 4) {
					return parseInt(a.deliveryFreeMoney) - parseInt(b.deliveryFreeMoney);
				} else if (id == 5) {
					return parseInt(a.deliveryStartMoney) - parseInt(b.deliveryStartMoney);
				}
			})
			this.setData({
				shops: shops
			})
		}
	},
	//获取店铺
	commentGet: function () {
		var conditionArr = JSON.stringify(this.data.conditionArr)
		var that = this
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/index/getShops',
			data: {
				userId: app.globalData.userId,
				longitude: that.data.longitude,
				latitude: that.data.latitude,
				page: 0,
				city: that.data.city,
				conditionArr: conditionArr
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: "POST",
			success: function (res) {
				wx.hideNavigationBarLoading()
				if (res.data) {
					if (res.data.openCity == 0 || res.data == '') {
						that.setData({
							shops: false,
							nothing: false
						})
					} else {
						if (conditionArr[2]) {
							that.paixu()
						}
						var shops = res.data.shops
						for (var i in shops) { //单位换算
							if (parseFloat(shops[i].distance) > 0 && parseFloat(shops[i].distance) < 1000) {
								shops[i].distances = shops[i].distance + 'm'
							} else if (parseFloat(shops[i].distance) == 0) {
								shops[i].distances = '1m'
							} else {
								shops[i].distances = parseFloat(shops[i].distance / 1000).toFixed(1) + 'km'
							}
						}
						var len = res.data.shops.length
						var commercial = res.data.commercial;//广告
						if (commercial != 0) {
							for (var i in commercial) { //单位换算
								if (parseFloat(commercial[i].distance) > 0 && parseFloat(commercial[i].distance) < 1000) {
									commercial[i].distances = commercial[i].distance + 'm'
								} else if (parseFloat(commercial[i].distance) == 0) {
									commercial[i].distances = '1m'
								} else {
									commercial[i].distances = parseFloat(commercial[i].distance / 1000).toFixed(1) + 'km'
								}
							}
							var one = commercial[0];
							commercial.splice(0, 1)

							if (len == 4) {
								shops.push(one)
							}
						}
						that.setData({
							shops: shops,
							page: len,
							nothing: true,
							arr: ''
						})
					}
				} else {
					that.setData({
						shops: false
					})
				}
			}
		})
	},
	//关闭排序和筛选的弹框
	hiddenChoice: function () {
		this.setData({
			allChoice: false
		})
	},
	//筛选选择
	termFeature: function (e) {
		var feindex = e.currentTarget.dataset.feindex;
		var termFeature = this.data.termFeature
		termFeature[feindex].ok = !termFeature[feindex].ok
		this.setData({
			termFeature: termFeature
		})
	},
	//营业时段
	OpenTime: function (e) {
		this.setData({ time: e.currentTarget.dataset.time })
	},
	//人均价格
	Price: function (e) {
		this.setData({ price: e.currentTarget.dataset.price })
	},
	termActivity: function (e) {
		var acindex = e.currentTarget.dataset.acindex;
		var termActivity = this.data.termActivity
		var okActivity = termActivity[acindex].shopType

		for (var i in termActivity) {
			if (acindex == i) {
				termActivity[i].ok = true
			} else {
				termActivity[i].ok = false
			}
		}
		this.setData({
			termActivity: termActivity,
			okActivity: okActivity,
		})
	},
	//组合
	termbut: function (e) {
		wx.showNavigationBarLoading()
		var termFeature = this.data.termFeature
		var price = this.data.price
		var time = this.data.time
		var okActivity = this.data.okActivity
		var query = {}
		if (okActivity) {
			query.shopType = okActivity
		}
		if (time) {
			query.time = time
		}

		if (price) {
			query.price = price
		}

		this.data.conditionArr[4] = query
		this.setData({
			query: query,
			allChoice: false,
		})
		var query = this.data.query
		this.data.conditionArr[4] = query
		this.commentGet()
	},
	//清楚筛选
	termDelete: function () {
		var termFeature = this.data.termFeature
		var termActivity = this.data.termActivity
		for (var i in termFeature) {
			termFeature[i].ok = false
		}
		for (var i in termActivity) {
			termActivity[i].ok = false
		}
		delete this.data.conditionArr[4]
		this.setData({
			termActivity: termActivity,
			termFeature: termFeature,
			okActivity: '',
			price: null,
			time: null,
			cuisineId: null,
			conditionArr: [],
			backcolor: 1
		})
	},
	attentions: function (index, type) {
		var shops = this.data.shops

		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			return false
		} else {
			var shopId = shops[index]['shopId']
			shops[index].closeHobby = false
			if (type == 1) {
				if (shops[index]['attentionType'] == 1) {
					var url = 'https://www.aftdc.com/wxapp/Shop/cancelAttention'
					that.cancelAttention(shopId, url)
					shops[index]['attentionType'] = 0
					that.setData({
						chooseHobbyId: 10,
						hobbyTip: true,
						hobbyTips: '已取消关注',
						shops: shops
					})
					setTimeout(function () {
						that.setData({
							hobbyTip: false
						})
					}, 5000)
				} else {
					var url = 'https://www.aftdc.com/wxapp/Shop/attention'
					that.attention(shopId, url)
					shops[index]['attentionType'] = 1
					that.setData({
						chooseHobbyId: 10,
						hobbyTip: true,
						hobbyTips: '你关注的商家发布新的动态时将会推送给你',
						shops: shops
					})
					setTimeout(function () {
						that.setData({
							hobbyTip: false
						})
					}, 5000)
				}
			} else {
				if (shops[index]['colType'] == 1) {
					var url = 'https://www.aftdc.com/wxapp/Shop/cancelAttention'
					that.cancelAttention(shopId, url)
					shops[index]['colType'] = 0
					that.setData({
						chooseHobbyId: 10,
						hobbyTip: true,
						hobbyTips: '已取消收藏',
						shops: shops
					})
					setTimeout(function () {
						that.setData({
							hobbyTip: false
						})
					}, 5000)
				} else {
					var url = 'https://www.aftdc.com/wxapp/Index/collect'
					that.attention(shopId, url)
					shops[index]['colType'] = 1
					that.setData({
						chooseHobbyId: 10,
						hobbyTip: true,
						hobbyTips: '收藏成功',
						shops: shops
					})
					setTimeout(function () {
						that.setData({
							hobbyTip: false
						})
					}, 5000)
				}
			}
		}
	},
	//关注
	attention: function (shopId, url) {
		var that = this
		// var userId = app.globalData.userId
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: url,
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				// userId: userId,
				shopId: shopId
			},
			method: "POST",
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {

			}
		})
	},
	//取消关注
	cancelAttention: function (shopId, url) {
		var that = this
		// var userId = app.usersInfo.userId
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: url,
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				// userId: userId,
				shopId: shopId
			},
			method: "POST",
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			success: function (res) {
			}
		})
	},
	closeOpen: function (e) {
		var index = e.currentTarget.dataset.index;
		var shops = this.data.shops
		var projectLay = shops[index].projectLay
		var closeHobby = shops[index].closeHobby
		if (Boolean(projectLay)) {
			shops[index].projectNum = projectLay
			shops[index].projectLay = false
		}
		if (Boolean(closeHobby)) {
			shops[index].closeHobby = closeHobby
			shops[index].closeHobby = false
		}
		this.setData({
			shops: shops,
		})
	},
	formnextBut: function (e) {
		var that = this;
		var shops = this.data.shops
		var formId = e.detail.formId;
		var index = e.currentTarget.dataset.index
		var type = e.currentTarget.dataset.type
		this.attentions(index, type)
		if (type == 1) {//关注
			var attentionType = shops[index]['attentionType'];
			if (attentionType == 0) {
				that.formId(formId, index)
			}
		} else {
			var colType = shops[index]['colType'];
			if (colType == 0) {
				that.formId(formId, index)
			}
		}
	},
	formId: function (formId, index) {
		var that = this;
		var shops = this.data.shops
		var shopId = shops[index]['shopId']
		var userId = app.globalData.userId;
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Index/formId',
			method: 'post',
			header: { "Content-Type": "application/x-www-form-urlencoded" },
			data: {
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				sign: sign,
				formId: formId,
				userId: userId,
				shopId: shopId,
			},
			success: function (res) {
			}
		})
	},
	not: function (e) { },//空白区域关闭抽屉
})
