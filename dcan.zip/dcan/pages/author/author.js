var authorization = require('../../utils/authorization.js')
var app = getApp()
Page({

	data: {

	},
	onLoad:function(){
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo){
			this.setData({
				openType:1
			})
		} else if (usersInfo&&!usersInfo.userPhone){
			this.setData({
				openType: 2
			})
		}
	},
	cancel: function () {
		wx.navigateBack()
	},
	getUserInfo: function (e) {
		var that = this
		wx.getSystemInfo({
			success: function (res) {
				that.data.model = res.model
			}
		})
		app.globalData.userInfo = e.detail.userInfo
		wx.login({
			success: function (r) {
				wx.request({
					url: 'https://www.aftdc.com/wxapp/addUser/index',
					method: "POST",
					header: { "Content-Type": "application/x-www-form-urlencoded" },
					data: {
						code: r.code,
                        longitude: app.globalData.location.longitude,
                        latitude: app.globalData.location.latitude,
						nickName: e.detail.userInfo.nickName,
						model: that.data.model,
						avatarUrl: e.detail.userInfo.avatarUrl,
						encryptedData: e.detail.encryptedData,
						iv: e.detail.iv
					},
					success: function (user) {
						app.globalData.usersInfo = user.data
						app.globalData.userId = user.data.userId
						wx.setStorageSync('usersInfo', user.data)
						if (!user.data.userPhone){
							that.setData({
								openType: 2
							})
						}else{
							wx.navigateBack()
						}
					}
				})
			}
		})
	},
	//获取手机号
	getPhoneNumber: function (e) {
		var that = this
		wx.login({
			success: function (r) {
				var code = r.code
				setTimeout(function () {
					var encryptedData = e.detail.encryptedData
					var iv = e.detail.iv
					wx.request({
						url: 'https://www.aftdc.com/wxapp/Adduser/getUserPhone',
						method: "POST",
						header: { "Content-Type": "application/x-www-form-urlencoded" },
						data: {
							code: code,
							encryptedData: encryptedData,
							iv: iv,
							userId: app.globalData.userId,
						},
						success: function (res) {
							var usersInfo = app.globalData.usersInfo
							usersInfo.userPhone = res.data.phoneNumber
							app.globalData.userInfo = usersInfo					
							wx.setStorageSync('usersInfo', usersInfo)
							wx.navigateBack()
						}
					})
				}, 200)
			}
		})
	}
})