var app = getApp()
var MD5Util = require('../../utils/md5.js');
Page({

	data: {
		noDesk: 0,
		imgBox: false,
		classifyId: 3,
		nops: '',
        tsyd:0,
        wm:0,
        djq:0,
        tg:0
	},
	getTagPl: function (e) {
		var shopId = this.data.shopId
		wx.navigateTo({
			url: '../order/shopdetail/allpj/allpj?shopId=' + shopId,
		})
	},

	onLoad: function (options) {
		var shopId = options.shopId
		var distance = options.distance
		var nearbyShop = options.nearbyShop
		var location = app.globalData.location


		if (nearbyShop != undefined) {
			nearbyShop = nearbyShop.split(",");// 
		}
		else {
			nearbyShop = ''
		}
		this.setData({
			shopId: shopId,
			distance: distance,
			nearbyShop: nearbyShop
		})
		var that = this
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Grouporder/getShopInfo',
			data: {
				shopId: shopId,
				chooseId: 1,
				nearbyShop: JSON.stringify(nearbyShop),
				lat: location.latitude,
				lng: location.longitude
			},
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			method: "POST",
			success: function (res) {
				wx.setNavigationBarTitle({
					title: res.data.shop.shopName
				})
				that.setData({
					arr: res.data,
                    tysd: res.data.shop.tsyd,
                    wm: res.data.shop.wm,
                    djq: res.data.shop.djq,
                    tg: res.data.shop.tg
				})		
     

				if (res.data.shop.range < that.data.distance) {
					that.setData({
						nops: '不在配送范围'
					})
				}
			}
		})
	},
	//切换评价
	choiceYes: function (e) {
		var index = e.target.dataset.id
		var classifyId = index
		var that = this
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)

		wx.request({
			url: 'https://www.aftdc.com/wxapp/Grouporder/getPingLun',
			data: {
				sign: sign,
				timestamp: timestamp,
				token: app.globalData.usersInfo.token,
				classifyId: classifyId,
				shopId: that.data.shopId
			},
			method: 'POST',
			header: {
				"Content-Type": "application/x-www-form-urlencoded"
			},
			success: function (res) {
				var pinglun = res.data
				var arr = that.data.arr
				arr.pinglun = pinglun
				that.setData({
					classifyId: classifyId,
					arr: arr
				})
			}
		})
	},
	goshop: function () {
		var nops = this.data.nops
		var shopId = this.data.shopId
		var distance = this.data.distance
		if (nops != '不在配送范围') {
			wx.setStorageSync('orderType', '0')
			wx.navigateTo({
				url: '../order/order?shopId=' + shopId + '&distance=' + distance,
			})
		}
	},
	godesk: function () {
		wx.setStorageSync('orderType', '3')
		var shopId = this.data.shopId
		wx.navigateTo({
			url: '../order/order?shopId=' + shopId,
		})
		// var shopName=this.data.arr.shop.shopName
		// wx.navigateTo({
		//   url: '../order/desk/desk?shopId=' + shopId + '&shopName=' + shopName,
		// })
	},
	//商家店铺图片
	imgsShow: function () {
		var shopId = this.data.shopId
		wx.navigateTo({
			url: './imgDetail/imgDetail?shopId=' + shopId,
		})
	},
	//拨打商家电话
	markPhone: function (e) {
		var phone = e.currentTarget.dataset.phone
		wx.makePhoneCall({
			phoneNumber: phone //仅为示例，并非真实的电话号码 })
		})
	},
	//查看地址
	address: function (e) {
		var jd = Number(e.currentTarget.dataset.jd)
		var wd = Number(e.currentTarget.dataset.wd)
		wx.openLocation({
			latitude: wd,
			longitude: jd,
			fail: function (err) {
			}
		})
	},
	//点击放大图片
	enlargeImg: function (e) {
		var src = e.currentTarget.dataset.src;
		var index = e.currentTarget.dataset.index;
		this.setData({
			enlargeSrc: src,
			enlargeBox: true,
			enlargeNumb: index,
		})
	},
	enlargeClose: function (e) {
		this.setData({
			enlargeBox: false,
		})
	},
	goto: function (e) {
		var shopId = e.currentTarget.dataset.shopid
		var groupId = e.currentTarget.dataset.groupid
		wx.navigateTo({
			url: './foodDetail/foodDetail?shopId=' + shopId + '&groupId=' + groupId,
		})
	},
	shopdetail: function () {
		wx.navigateTo({
			url: '../order/shopdetail/shopdetail?shopId=' + this.data.shopId,
		})
	},
	index: function () {
		wx.switchTab({
			url: '/pages/index/index',
		})
	},
})

