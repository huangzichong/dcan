 var app = getApp()
var MD5Util = require('../../utils/md5.js');
Page({

	data: {
		winHeight: "",//窗口高度
		currentTab: 0, //预设当前项的值
		onreachBottom: true,
		cur: 0,
		cat: "",
		mFirst: 0,
		recede: 0,
		length: 0,
        action: 0
	},
	// 下拉刷新
	onPullDownRefresh: function (e) {
        this.cutArticle(this.data.currentTab)
		wx.hideNavigationBarLoading() //完成停止加载
		wx.stopPullDownRefresh() //停止下拉刷新
	},
	// 滚动切换标签样式
	// switchTab: function (e) {
	// 	if (e.detail.source =='touch'){
	// 		this.setData({
	// 			article:[],
	// 			currentTab: e.detail.current,
	// 			toView: 'id' + e.detail.current
	// 		});
	// 		this.cutArticle(e.detail.current);
	// 	}
	// },
	// 点击标题切换当前页时改变样式
	swichNav: function (e) {
		var cur = e.target.dataset.current;
		if (this.data.currentTab == cur) {
            if (cur == 0)
            {
                wx.startPullDownRefresh()
            }
            else
             return false; 
        }
		else {
			this.setData({
				currentTab: cur
			})
			this.cutArticle(cur);
		}
	},
    onTabItemTap(item) {
        if(this.data.action)
        {
            console.log('onTabItemTap')
	    	wx.startPullDownRefresh()
        }
        this.setData({action:1})
	},
	//切换文章
	cutArticle: function (cur) {
		this.setData({
			article: [],
			cur: cur,
			page: 0,
			onreachBottom: true,
			articleRes: 1
		});
		if (cur != 0)
			var cur = this.data.cat[cur].id
		var userId = ''
		if (app.globalData.usersInfo) {
			userId = app.globalData.userId
		}

		var that = this;
		var timestamp = (Date.parse(new Date())) / 1000
		var sign = MD5Util.sign(timestamp)
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Article/NewsTo',
			header: {
				'content-type': 'application/x-www-form-urlencoded'
			},
			data: {
                latitude: that.data.latitude,
                longitude: that.data.longitude,
				userId: userId,
				cur: cur,
				page: that.data.page,
			},
			method: "POST",
			success: function (res) {
				that.setData({
					article: res.data.data,
					page: res.data.data.length,
					articleRes: res.data.res,
					cur: cur
				})
			}
		})
	},
	//点击时隐藏红点
	// onTabItemTap(item) {
	// 	wx.hideTabBarRedDot({
	// 		index: 2,
	// 	})
	// },
    onReady: function (options) {
        this.setData({
            cur: 0,
            page: 0,
            onreachBottom: true,
            articleRes: 1
        });
    },
    onLoad: function () {
        if(!this.data.action){
        var that = this
        console.log('onload')
        wx.getLocation({
            type: 'gcj02',
            success: function (res) {
                var latitude = res.latitude
                var longitude = res.longitude
                that.setData({
                    latitude: latitude,
                    longitude: longitude,
                })
                that.article(latitude, longitude)
            },
            fail: function (res) {
                that.article('', '')
            },
        })      
      }
    },
    article: function (latitude, longitude) {
        console.log(2)
        var userId = ''
        if (app.globalData.usersInfo) {
            userId = app.globalData.userId
        }
        var cur = 0;
        var that = this;
        var timestamp = (Date.parse(new Date())) / 1000
        var sign = MD5Util.sign(timestamp)
        wx.request({
            url: 'https://www.aftdc.com/wxapp/Article/News',
            header: {
                'content-type': 'application/x-www-form-urlencoded'
            },
            data: {
                userId: userId,
                cur: cur,
                page: that.data.page,
                latitude: latitude,
                longitude: longitude
            },
            method: "POST",
            success: function (res) {
                that.setData({
                    article: res.data.data,
                    page: that.data.page + res.data.data.length,
                    articleRes: res.data.res,
                    length: res.data.data.length,
                    cat: res.data.cat,
                    length: res.data.cat.length,
                })
            }
        })
    },

	onReachBottom: function () {
		if (this.data.onreachBottom) {
			this.setData({
				more: true
			})
			this.data.onreachBottom = false
			var userId = ''
			if (app.globalData.usersInfo)
				var userId = app.globalData.userId
			var that = this;
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Article/NewsTo',
				header: {
					'content-type': 'application/x-www-form-urlencoded'
				},
				data: {
                    latitude: that.data.latitude,
                    longitude: that.data.longitude,
					userId: userId,
					cur: that.data.cur,
					page: that.data.page
				},
				method: "POST",
				success: function (res) {
					if (res.data.res == 1) {
						that.setData({
							article: that.data.article.concat(res.data.data),
							page: that.data.page + res.data.data.length,
							onreachBottom: true,

						})
					}
					that.setData({
						more: false
					})
				}
			})
		}
	},

	seeDetail: function (e) {
		var id = e.currentTarget.dataset.id
		wx.request({
			url: 'https://www.aftdc.com/wxapp/Article/article_click',
			method: 'post',
			data: {
				id: id,
			},
			header: {
				'content-type': 'application/x-www-form-urlencoded'
			},
			success: function (res) {
				console.log(res)
			}
		})
		wx.navigateTo({
			url: './article/article?article_id=' + id,
		})
	},
	//点击X
	noInterest: function (e) {
		var index = e.currentTarget.dataset.index
		var article = this.data.article[index]
		var chooseHobby = [{ name: '看过了', sel: false, id: 1 }, { name: '内容太水', sel: false, id: 2 }]
		if (article.key_word != '') {
			for (var i in article.key_word) {
				var a = { name: '不想看·' + article.key_word[i], sel: false, id: 3 + i }
				chooseHobby.push(a)
			}
		}
		this.setData({
			noInterest: true,
			index: index,
			chooseHobby: chooseHobby
		})
	},

	closeBox: function () {
		var chooseHobby = this.data.chooseHobby
		for (var i in chooseHobby) {
			chooseHobby[i]['sel'] = false
		}
		this.setData({
			noInterest: false,
			chooseHobbyId: null,
			chooseHobby: chooseHobby,
			chooseH: false
		})
	},
	//选择标签
	chooseHobby: function (e) {
		//单选
		var chooseHobby = this.data.chooseHobby

		var index = e.currentTarget.dataset.index
		this.data.cuisineId = e.currentTarget.dataset.id
		this.data.chooseHobbyId = chooseHobby[index]['id']
		for (var i in chooseHobby) {
			if (this.data.chooseHobbyId == chooseHobby[i]['id'] && chooseHobby[i]['sel'] == false) {
				chooseHobby[i]['sel'] = true
			} else {
				chooseHobby[i]['sel'] = false
			}
		}
		for (var i in chooseHobby) {
			if (chooseHobby[i]['sel']) {
				var chooseH = true
				break;
			} else {
				var chooseH = false
			}
		}
		this.setData({
			chooseH: chooseH,
			chooseHobby: chooseHobby,
			chooseHobbyId: this.data.chooseHobbyId
		})
	},
	sureReason: function () {
		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			return false
		} else {
			var index = that.data.index
			var article = that.data.article
			var chooseHobbyId = that.data.chooseHobbyId
			var cuisineId = that.data.cuisineId
			for (var j = 0; j < that.data.chooseHobby.length; j++) {
				if (that.data.chooseHobby[j].id == that.data.chooseHobbyId)
					var chooseHobby = that.data.chooseHobby[j]
			}
			var reason = chooseHobby.name

			var shopId = article[index].shopId
			var business_id = article[index].business_id
			var article_id = article[index].id
			article.splice(index, 1)
			that.setData({
				article: article,
				hobbyTip: true,
				hobbyTips: '将减少此类文章推荐',
			})
			setTimeout(function () {
				that.setData({
					hobbyTip: false
				})
			}, 5000)
			that.closeBox()
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Article/article_shield',
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					userId: app.globalData.userId,
					shopId: shopId,
					business_id: business_id,
					article_id: article_id,
					reason: reason,
					tagName: ""
				},
				header: { "Content-Type": "application/x-www-form-urlencoded" },
				method: "POST",
				success: function (res) {
					if (res.data.res == 1) {

					}
				}
			})
		}
	},
	//不感兴趣
	notInterestfun: function (e) {
		var that = this
		var usersInfo = wx.getStorageSync('usersInfo')
		if (!usersInfo || !usersInfo.userPhone) {//如果没登录
			wx.navigateTo({
				url: '/pages/author/author',
			})
			return false
		} else {
			var index = that.data.index
			var article = that.data.article
			var shopId = article[index].shopId
			var business_id = article[index].business_id
			var article_id = article[index].id
			article.splice(index, 1)
			that.setData({
				article: article,
				hobbyTip: true,
				hobbyTips: '将减少此类文章推荐',
			})
			setTimeout(function () {
				that.setData({
					hobbyTip: false
				})
			}, 5000)
			that.closeBox()
			var timestamp = (Date.parse(new Date())) / 1000
			var sign = MD5Util.sign(timestamp)
			wx.request({
				url: 'https://www.aftdc.com/wxapp/Article/article_shield',
				data: {
					sign: sign,
					timestamp: timestamp,
					token: app.globalData.usersInfo.token,
					userId: app.globalData.userId,
					shopId: shopId,
					business_id: business_id,
					article_id: article_id,
					reason: '不感兴趣',
					tagName: ""
				},
				header: { "Content-Type": "application/x-www-form-urlencoded" },
				method: "POST",
				success: function (res) {
					if (res.data.res == 1) {

					}
				}
			})
		}
	},
	onShareAppMessage: function () {
		return {
			title: '餐头条',
			path: '/pages/direct/direct',
			success: function (res) {
			}
		}
	},
})